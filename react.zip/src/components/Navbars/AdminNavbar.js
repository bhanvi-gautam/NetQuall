import { React, useEffect, useState } from "react";
import Avatar from "@mui/material/Avatar";
import { useLoginMutation, useGetOneUserMutation } from "../rtk/AddSlice";
import { Link, useNavigate } from "react-router-dom";
import dummyProfile from "../../assets/img/dummyProfile.png";
import { decryptData, encryptData } from "../../assets/security/encryDecrypt";
import './AdminNavbar.css'
import IconButton from '@mui/material/IconButton';
import Tooltip from '@mui/material/Tooltip';
import HelpOutlineOutlinedIcon from '@mui/icons-material/HelpOutlineOutlined';
import castingService from "../CastService/CastService";


const AdminNavbar = () => {
  const navigate = useNavigate();
  const id = localStorage.getItem("userId");
  const roleId=localStorage.getItem("roleId");
  console.log('roleId', roleId)
  const [posts, setPosts] = useState({
    profile: "",
    first_name: "",
    last_name: "",
  });
  const [state,setState]=useState({ avatar: "" })
  const [getdata] = useGetOneUserMutation();

  const getTitle = (roleId) => {
    if (roleId === 2) {
      return "Contact Admin in case of any discrepancy or any changes required";
    }
    if (roleId === 3) {
      return "Contact respective Faculty Member in case of any discrepancy or any changes required";
    }
    return ""; // Default return value in case none of the conditions match
  };
  const abc = () => {
    getdata(id)
      .unwrap()
      .then((fetchPosts) => {
        const temp = decryptData(fetchPosts.data);
        setPosts(temp?.response?.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  };
  const logout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("roleId");
    localStorage.removeItem("userId");
    // setTimeout(() => {
      navigate("/");
    // }, 2000);
  };

  // Receive here
useEffect(() => {
  try {
      castingService.onMessage().subscribe((m) => {
          if (m.senderId === "CardSettings" && m.target === "AdminNavbar") {
              // Your logic here for handling the received message
             let img= m.text.data;
              setState({ avatar: img });

              if(m.text.cancelClicked){
                setState({avatar:""})
              }
          }
      });
  } catch (error) {
      console.error(error);
  }
}, []);


  useEffect(() => {
    abc();
  }, []);

  return (
    <nav className="absolute top-0 left-0 w-full z-10 md:flex-row md:flex-nowrap md:justify-start flex items-center p-4 drop-shadow-md card-2" style={{backgroundColor:"#135d81bf"}}>
    <div className="w-full mx-auto items-center flex justify-between md:flex-nowrap flex-wrap font-semibold">
      <Link
        className="text-white text-sm uppercase hidden lg:inline-block"
        to={"/dashboard"}
      >
        Hello, {posts?.first_name + " " + posts?.last_name}!
      </Link>
      
      <form className="md:flex hidden flex-row flex-wrap items-center lg:ml-auto mr-3">
       {roleId!=4 &&
        <Tooltip title={roleId==2? 'Contact Admin in case of any discrepancy or any changes required':'Contact respective Faculty Member in case of any discrepancy or any changes required'}>
          <IconButton color="inherit">
            <HelpOutlineOutlinedIcon style={{ color: 'white' }}/>
          </IconButton>
        </Tooltip>}
        <button
          className="text-white text-sm uppercase hidden lg:inline-block font-semibold"
          onClick={logout}
        >
          Logout
        </button>
      </form>
      
      <ul className="flex-col md:flex-row list-none items-center hidden md:flex">
       { state.avatar!=="" ? 
       <Avatar
       alt="Welcome"
       src={state.avatar}
     />
         : 
        
        <Avatar
          alt="Welcome"
          src={
            posts?.profile
              ? `http://localhost:3003/images/${posts?.profile}`
              : dummyProfile
          }
        />
        }
      </ul>
    </div>
  </nav>
  );
};

export default AdminNavbar;
