import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useGetUserSubjectMutation } from "../rtk/AddSlice";
import { decryptData, encryptData } from "../../assets/security/encryDecrypt";
import CardTable2 from "../Cards/CardTable2";
import TableShimmer from "../Effects/TableShimmer";
import { Box, Typography } from "@mui/material";
import { notifySuccess } from "../../toast";
import { ToastContainer } from "react-toastify";

const ListTeachers = () => {
  const { courseId } = useParams();
  const [getdata, { isLoading, isSuccess, post }] = useGetUserSubjectMutation();
  const [posts, setPosts] = useState(post);

  // const courseId = decryptData(course_Id);

  const abc = async (value) => {
    const payload = { roleId: "2" };
    // const encryptedData=encryptData(payload);
    const fetchPosts = await getdata(payload).unwrap();
    // const temp = decryptData(fetchPosts.data);
    console.log("fetchPosts", fetchPosts);
    // setPosts(temp);
    setPosts(fetchPosts);
    if(value){
      console.log('value', value)
      notifySuccess("Data Deleted!")
    }
  };

  useEffect(() => {
    abc();
  }, []);
  console.log("posts===", posts?.data);
  return (
    <>
      <Box className="w-full mb-12">
        <Box className= "relative md:pt-30 pb-32 pt-12"  style={{backgroundColor:'#0099CC'}}>
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
            <Typography gutterBottom variant="h4" component="div">
              List of Faculty Members
            </Typography>
          </Box>
        </Box>
        {isLoading && <TableShimmer />}

        {isSuccess && (
          <div
            className="relative pb-32"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >
            <CardTable2
              content={posts?.data}
              heading={[
                "Profile",
                "Faculty Name",
                "Email",
                "Subject",
                "Semester No",
                "Course",
                "Delete",
                "Accept/Unaccepted",
                "View More",
              ]}
              roleId={2}
              errorMessg={"No Faculty available"}
              filteredData={abc}
            />
          </div>
        )}
      </Box>
      <ToastContainer containerId="A"/>
    </>
  );
};

export default ListTeachers;
