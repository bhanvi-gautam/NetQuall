import React, { useState, useEffect } from "react";
import { useGetTeacherSubjectMutation } from "../rtk/AddSlice";
import { decryptData } from "../../assets/security/encryDecrypt";
import CardShimmer from "../Effects/CardShimmer";
import { Link } from "react-router-dom";
import NoDataFound from "../Cards/NoDataFound";
import {
  Paper,
  Typography,
  Card,
  CardContent,
  CardActions,
  IconButton,
  Alert,
  Stack,
} from "@mui/material";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";

const ListSubjectForTeacher = () => {
  const [getData, { isLoading, isSuccess, isError, post }] =
    useGetTeacherSubjectMutation();
  const [posts, setPosts] = useState(post);
  const userId = localStorage.getItem("userId");
  const [length, setLength] = useState(0);
  console.log("userId", decryptData(userId));

  const abc = async () => {
    const fetchPosts = await getData({ userId: userId }).unwrap();
    console.log("fetchPosts", fetchPosts.encryptedData);
    const subjects = decryptData(fetchPosts.encryptedData);
    console.log("subjects", subjects);
    setLength(subjects.response.data.length);
    setPosts(subjects.response.data);
  };

  useEffect(() => {
    abc();
  }, []);
  console.log("posts", posts);
  return (
    <div className="w-full mb-12">
      {isLoading && <CardShimmer />}

      {isSuccess && (
        <>
          <div
            className="relative md:pt-30 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              position: "relative", // Ensure positioning context for absolute positioning
              backgroundColor: '#0099CC'
            }}
          >
            {/* Heading */}
            <Typography
              gutterBottom
              variant="h4"
              component="div"
              color={"white"}
              style={{
                position: "absolute",
                bottom: 0,
                left: 15,
              }}
            >
              Manage Your Subjects with Ease
            </Typography>
          </div>
          <div
            className="relative md:pt-30 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "flex-start", 
              alignItems: "flex-start", 
              padding: "0 20px", 
              backgroundColor: 'white'
            }}
          >


            {/* Cards */}
            {length === 0 ? (
              <NoDataFound content="No Subjects" />
            ) : (
              <>
               <Stack sx={{ width: '100%' }} spacing={2}>
                <Alert severity="info" style={{margin:'10px'}}>This page allows you to efficiently manage your subjects. By clicking on the arrow next to each subject, you can view all students enrolled in that particular subject. Additionally, the same arrow allows you to assign homework for the subject. Navigate and manage your subjects seamlessly with just a click!</Alert>
                </Stack>
                {posts?.map((data, index) => (
                  <>

                    <Card
                      key={index}
                      elevation={2}
                      style={{
                        height: "50px",
                        width: "560px",
                        margin: "15px",
                        position: "relative"
                      }}
                    >
                      <CardContent>
                        <Typography
                          variant="p"
                          component="div"
                          style={{
                            fontWeight: "bold",
                          }}
                        >
                          {data}
                        </Typography>
                        <CardActions
                          style={{ position: "absolute", bottom: 0, right: 0 }}
                        >
                          <IconButton>
                            <Link to={`/viewStudentUnderTeacher/${data}`}>
                              <ArrowForwardIcon />
                            </Link>
                          </IconButton>
                        </CardActions>
                      </CardContent>

                    </Card>
                    <hr />
                  </>
                ))}
              </>
            )}
          </div>
        </>
      )}
    </div>
  );
};

export default ListSubjectForTeacher;