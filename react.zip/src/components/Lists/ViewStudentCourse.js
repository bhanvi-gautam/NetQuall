import React, { useState, useEffect } from 'react'
import { useGetOnePostMutation, useGetCourseIdMutation, useGetUserSubjectMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import { Paper, Typography } from '@mui/material';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Divider from '@mui/material/Divider';


const ViewStudentCourse = () => {
    const userId = localStorage.getItem('userId');
    const [getCourseId] = useGetCourseIdMutation();
    const [getData, { isLoading, isSuccess }] = useGetOnePostMutation();
    const [getTeacher, { post }] = useGetUserSubjectMutation();
    const [posts, setPosts] = useState(post);
    const [info, setInfo] = useState(null);

    console.log('userId', userId)

    const abc = async () => {
        try {
            const fetch = await getCourseId({ userId }).unwrap();
            const decryptedData = decryptData(fetch.data);
            const encryptedId = encryptData({ decryptedData });
            const fetchPt = await getData({ courseId: encryptedId }).unwrap();
            const fetchPosts = decryptData(fetchPt.data);
            console.log("hie--", fetchPosts);

            setInfo(fetchPosts);


            const payload = { courseId: fetchPosts.id, roleId: '2' }
            const fetchPosts2 = await getTeacher(payload).unwrap();
            console.log('fetchPosts', fetchPosts2)
            // setPosts(temp);
            setPosts(fetchPosts2);
        } catch (error) {
            console.error("Error:", error);
        }
    };

    console.log('posts123', posts)
    useEffect(() => {
        abc();
    }, [userId]);
    return (
        <div className="w-full mb-12">
            {isLoading && <CardShimmer />}
            {isSuccess && (
                <>
                    <div className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>

                        <Typography gutterBottom variant="h4" component="div" color={"white"} style={{ position: "absolute", bottom: 0, left: 15 }}>
                            Course Details: {info?.courseName}

                        </Typography>
                    </div>
                    <div className="relative pb-2" style={{ backgroundColor: "white" }}>
                        <List sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                            {info?.userSemesters.map((sem, index1) => (
                                <React.Fragment key={sem.id}>
                                    <Paper elevation={0} sx={{ mx: 2.0, my: 1.5 }}>
                                        <ListItem>
                                            <ListItemText primary={`Semester No: ${sem.semesterNo}`} />
                                        </ListItem>
                                        {sem.userSubjects?.map((sub, index2) => (
                                            <React.Fragment key={sub.id}>
                                                <ListItem style={{ paddingLeft: '2em' }}>
                                                    <ListItemText primary={`Subject Name: ${sub.subjectName}`} />
                                                </ListItem>
                                                {index2 < sem.userSubjects.length - 1 && <Divider variant="inset" component="li" />}
                                            </React.Fragment>
                                        ))}
                                    </Paper>
                                    {index1 < info.userSemesters.length - 1 && <Divider component="li" sx={{ mx: 2.5, my: 1.5 }} />}
                                </React.Fragment>
                            ))}

                        </List>

                    </div>
                </>
            )
            }
        </div >
    )
}

export default ViewStudentCourse;
