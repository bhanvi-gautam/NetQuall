import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useGetStudentQuizDataMutation } from '../rtk/AddSlice'
import TableShimmer from '../Effects/TableShimmer';
import CardTable11 from '../Cards/CardTable11';
import { Box, Typography } from '@mui/material';
import { ToastContainer } from 'react-toastify';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';

const ViewStudentUnderTeacherQuiz = () => {

  const { subject, studentId } = useParams();

  const [getData, { isLoading, isSuccess, post }] = useGetStudentQuizDataMutation();
  const [posts, setPosts] = useState(post);

  const getStudentData = async () => {
    const payload = { subject: subject, studentId: studentId };
    const encryptedData = encryptData(payload);
    await getData({ encryptedData }).unwrap().then((data) => {
      // console.log('data', data.encryptedData);
      const decryptedData = decryptData(data.encryptedData);
      console.log('decryptedData', decryptedData)
      setPosts(decryptedData);
    }).catch((error) => {
      console.error("Error fetching scores:", error);
    })
  }
  useEffect(() => {
    getStudentData();
  }, [])

  console.log('subject123', subject)
  console.log('studentId', studentId)

  // console.log('responseData', responseData)

  return (
    <>
      <Box className="w-full mb-12">
        <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
            <Typography gutterBottom variant="h4" component="div">
              {"Review Quiz in " + subject + " Submitted by Student"}
            </Typography>
          </Box>
        </Box>
        {isLoading && <TableShimmer />}

        {isSuccess && (
          <div
            className="relative pb-2"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >
            <CardTable11
              // content={data}
              heading={[
                "Quiz name",
                "Quiz total marks",
                "Obtained Marks"
              ]}
              roleId={3}
              content={posts}
              errorMessg={"No Student available"}
            />
          </div>
        )}
      </Box>
      <ToastContainer containerId='A' />
    </>
  )
}

export default ViewStudentUnderTeacherQuiz
