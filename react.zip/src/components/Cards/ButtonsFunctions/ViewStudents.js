import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useGetUserSubjectMutation } from "../../rtk/AddSlice";
import {decryptData,encryptData} from "../../../assets/security/encryDecrypt";
import CardTable from "../CardTable";
import CardShimmer from "../../Effects/CardShimmer";
import { Box, Typography } from "@mui/material";

const ViewStudents = () => {
  const { courseId } = useParams();
  const [getdata, { isLoading, isSuccess, post }] = useGetUserSubjectMutation();
  const [posts, setPosts] = useState(post);

  // const courseId = encryptData(course_Id);

  const abc = async () => {
    const payload={courseId:courseId, roleId:'3'}
    // const encryptedData=encryptData(payload);
    const fetchPosts = await getdata(payload).unwrap();
    // const temp = decryptData(fetchPosts.data);
    setPosts(fetchPosts);
  };
  useEffect(() => {
    abc();
  }, []);

  return (
    <>
      <Box className="w-full mb-12">
        <Box className= "relative md:pt-30 pb-32 pt-12"  style={{backgroundColor:'#0099CC'}}>
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
            <Typography gutterBottom variant="h4" component="div">
              List of Students
            </Typography>
          </Box>
        </Box>
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
          className="relative pb-2 "
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "space-around",
            backgroundColor: "white",
          }}
        >
            <CardTable
              content={posts?.data}
              heading={[
                "Profile",
                "Student Name",
                "Email",
                "Address",
                "Phone number",
              ]}
              role={3}
              
              errorMessg={"No Student enrolled under this Course yet!"}
            />
          </div>
        )}
      </Box>
    </>
  );
};

export default ViewStudents;
