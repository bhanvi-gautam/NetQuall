import React, { useEffect, useState } from 'react';
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import { useGetStudentAssignSubmissionDetailsMutation } from '../../rtk/AddSlice';
import { decryptData, encryptData } from '../../../assets/security/encryDecrypt';
import Loading from '../../../views/auth/Parts/Loading'
import { Link } from 'react-router-dom';

const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    boxShadow: 12,
    p: 4,
};

export default function AlreadySubmittedDetails({ handleShowClose, studentId, subject, assign_Id, deadlineTime, deadlineDate }) {
    const [open, setOpen] = useState(true);
    const [getData, { isLoading, isSuccess, post }] = useGetStudentAssignSubmissionDetailsMutation();
    const [posts, setPosts] = useState(post);
    const handleClose = () => {
        setOpen(false);
        handleShowClose();
    };
    const abc = async () => {
        const payload = { subject: subject, user_Id: studentId, assign_Id: assign_Id };
        console.log('assign_Id', assign_Id)
        const encryptedData = encryptData(payload);
        getData({ encryptedData }).unwrap().then((fetchPosts)=>{
            const students = decryptData(fetchPosts.encryptedData);
            console.log('students', students.response.data)
            setPosts(students.response.data);
        }).catch((error)=>{
            console.log('error', error)
        });
    }

    useEffect(() => {
        abc();
    }, [])
    console.log('posts', posts)
    console.log('isLoading', isLoading)
    console.log('isSuccess', isSuccess)

    const checkDeadline = () => {
        console.log("hie")
        if (isSuccess) {
            const submissionDate = new Date(posts?.deadlineDate).toISOString().split("T")[0];
            const submissionTime = posts?.deadlineTime;
            const submission = new Date(`${submissionDate} ${submissionTime}`)
            const deadline = new Date(`${deadlineDate} ${deadlineTime}`)
            if (submission > deadline) {
                // return "The submission was late";
                return false;
            }
            else {
                // return "The submission was on time"
                return true;
            }
        }
    }

    const value = checkDeadline();
    // console.log('value', value)
    return (
        <div>
            {isLoading && <Loading />}
            {isSuccess &&
                <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                >

                    <Box sx={style}>
                        <Typography id="modal-modal-title" variant="h6" component="h2">
                            About your Submission
                        </Typography>

                        <Typography id="modal-modal-file" sx={{ mt: 2 }}>
                            File Name:  <Link
                                to={`http://localhost:3003/download/${posts?.assignment}`}
                                style={{ color: 'blue' }}
                            >
                                {posts.assignment}
                            </Link>
                        </Typography>
                        <Typography id="modal-modal-submission-time" sx={{ mt: 2 }}>
                            Submitted At:<p style={{backgroundColor:`${value ? '#14c1145c' : '#f611119c'}` }}>{new Date(posts?.deadlineDate).toISOString().split("T")[0]} at {posts.deadlineTime}</p>
                        </Typography>
                    </Box>
                </Modal>
            }
        </div>
    );
}
