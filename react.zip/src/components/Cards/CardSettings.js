import React, { useEffect, useState, useRef } from "react";
import { useDeleteProfileMutation, useGetOneUserMutation, useUploadImageMutation, useUpdateUserMutation } from "../rtk/AddSlice";
import { decryptData, encryptData } from "../../assets/security/encryDecrypt";
import dummyProfile from '../../assets/img/dummyProfile.png'
import ButtonGroup from '@mui/material/ButtonGroup';
import CardShimmer from '../Effects/CardShimmer'
import Box from '@mui/material/Box';
import Modal from '@mui/material/Modal';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import { styled } from '@mui/material/styles';
import { Badge } from "@mui/material";
import { Stack } from "@mui/material";
import { notifyError, notifySuccess } from "../../toast";
import { ToastContainer } from "react-toastify";
import SendIcon from '@mui/icons-material/Send';
import castingService from "../CastService/CastService";

export default function CardSettings() {
  const userId = localStorage.getItem('userId');
  const [getData, { isLoading, isSuccess, post }] = useGetOneUserMutation();
  const [posts, setPosts] = useState(post);
  const [formData, setFormData] = useState(post);
  const [show, setShow] = useState(false);
  const [changed, setChanged] = useState(false);
  const [state, setState] = useState({ avatar: "" })
  const fileInput = useRef(null);
  const [fileSize, setFileSize] = useState(5242880044);
  const [fileName, setFileName] = useState("");
  const [file, setFile] = useState(null);
  const [imageError, setImageError] = useState(false);
  const [showError, setShowError] = useState('');
  const [extension, setExtension] = useState('');
  const [removeProfile, setRemoveProfile] = useState(false);
  const [cancel, setCancel] = useState(false);
  const [deletePhoto] = useDeleteProfileMutation();
  const [uploadImage] = useUploadImageMutation();
  const [updateData] = useUpdateUserMutation();


  const handleClose = async (value) => {
    // setShow(!show);
    if (value === 1000) {
      setShow(false)
      console.log('value', value)
      notifySuccess("New Profile Selected")
    }
  }

  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 400,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    alignItems: 'center',
    height: 450,
  };


  const handleOpen = () => {
    setShow(!show);
  }

  const abc = () => {
    getData(userId).unwrap().then((fetchPost) => {
      const temp = decryptData(fetchPost.data);
      console.log('temp', temp.response.data)
      setPosts(temp.response.data);
      setFormData(temp.response.data);
    })
  }

  useEffect(() => {
    abc();
  }, [])

  useEffect(() => {

  }, [changed], [removeProfile]);

  const StyledBadge = styled(Badge)(({ theme }) => ({
    '& .MuiBadge-badge': {
      right: 80,
      top: 19,
      border: `2px solid ${theme.palette.background.paper}`,
      padding: '0 4px',
    },
  }));

  const handleRemoveProfile = () => {
    setRemoveProfile(true);
    setChanged(false);
    setExtension('');
  }

  const handleCancel = (e) => {
    setCancel(true);
    setShow(false);
    setRemoveProfile(false);
    setChanged(false);
    setExtension('');
    castingService.sendMessage("CardSettings", { cancelClicked: true}, "AdminNavbar");
  }

  const handleChange = (e) => {
    const file = e.target.files[0];
    if (!file) return;
    console.log('e.target.files[0].name', file?.name)
    let extension = file.name.split(".");
    let temp = extension[1];
    setExtension(temp);
    console.log('extension', temp)
    const size = file.size;
    setFile(file);
    setFileName(file.name);
    setFileSize(size);
    if (size > 5242880) { // Check if the file size is more than 5MB
      setShowError('File must be less than 5MB');
      return;
    }
    if (temp != "jpeg" && temp != "png" && temp != ".jpg") {
      console.log('extension1233', extension)
      setImageError(true);
      setShowError('Choose a valid file');
      return;
    }



    setImageError(false);
    let reader = new FileReader();
    reader.readAsDataURL(e.target.files[0]);
    reader.onload = (e) => {
      let img = e.target.result;
      setState({ avatar: img });

      // Send here
      

      setChanged(true);
      setRemoveProfile(false)
    };
  };


  const handleSubmit = async () => {
    if (removeProfile || changed) {

      await deletePhoto({ fileToBeRemoved: posts.profile }).then(async (data) => {
        if (extension) {
          const start = 0;
          const end = fileSize;

          const fileData = new FormData();
          fileData.append("file", file);
          await uploadImage({
            y: extension,
            x: fileData,
            z: `bytes=${start}-${end}/${fileSize}`,
          }).then(async (result) => {
            console.log('result', result.data.data)
            // setFormData({ ...formData, profile: result.data.data })
            const updatedFormData = { ...formData, profile: result.data.data };
            console.log('updatedFormData', updatedFormData)
            const temp = encryptData(updatedFormData);
            await updateData({ updatedFormData: temp }).unwrap().then((data) => {
              notifySuccess("Data Updated Successfully");
              castingService.sendMessage("CardSettings", { data: state.avatar}, "AdminNavbar");
              abc();
            }).catch((error) => {
              notifyError("There is some issue in server. Please try again later");
              console.error("Error in update operations", error);
            })
          }).catch((err) => {
            console.log('err', err)
          });
        }
        else {
          // setFormData({ ...formData, profile: '' })
          const updatedFormData = { ...formData, profile: '' };
          console.log('updatedFormData', updatedFormData)
          const temp = encryptData(updatedFormData);
          await updateData({ updatedFormData: temp }).unwrap().then((data) => {
            notifySuccess("Data Updated Successfully");
            abc();
          }).catch((error) => {
            notifyError("There is some issue in server. Please try again later");
            console.error("Error in update operations", error);
          })
        }
      });
    }
    else {
      const updatedFormData = formData;
      console.log('updatedFormData', updatedFormData)
      const temp = encryptData(updatedFormData);
      await updateData({ updatedFormData: temp }).unwrap().then((data) => {
        notifySuccess("Data Updated Successfully");
        abc();
      }).catch((error) => {
        notifyError("There is some issue in server. Please try again later");
        console.error("Error in update operations", error);
      })
    }
  }


  return (
    <>
      {isLoading && <CardShimmer />}

      {isSuccess && (
        <>
          <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-100 border-0">
            <div className="rounded-t bg-white mb-0 px-6 py-6">
              <div className="text-center flex justify-between">
                <div style={{ display: 'flex', justifyContent: 'space-between', width: '100%' }}>
                  <h6 className="text-blueGray-700 text-xl font-bold">My account</h6>

                  <div >
                    <StyledBadge badgeContent={'?'} color="primary" onClick={handleOpen} style={{ cursor: 'pointer' }}>
                      {removeProfile ?
                        <img
                          alt="..."
                          src={dummyProfile}
                          className="rounded-full h-auto align-middle border-none absolute -m-24 max-w-120-px"
                        />
                        :
                        (changed ?
                          <img
                            src={state.avatar}
                            className="rounded-full h-auto align-middle border-none absolute -m-24 max-w-120-px"
                            alt="..."
                            accept=".png,.jpg,.jpeg"
                          />
                          :
                          <img
                            alt="..."
                            src={posts?.profile ? `http://localhost:3003/images/${posts?.profile}` : dummyProfile}
                            className="rounded-full h-auto align-middle border-none absolute -m-24 max-w-120-px"
                          />
                        )
                      }
                    </StyledBadge>


                    {show &&
                      <Modal
                        open={show}
                        onClose={handleClose}
                        disableBackdropClick={true}
                        aria-labelledby="modal-modal-title"
                        aria-describedby="modal-modal-description"
                      >


                        <Box sx={style}>
                          <Box >
                            {removeProfile ?
                              <img
                                alt="..."
                                src={dummyProfile}
                                className="rounded-full h-auto align-middle border-none absolute -m-16 -ml-20 lg:-ml-16 max-w-150-px"
                              />
                              :
                              (changed ?
                                <img
                                  src={state.avatar}
                                  className="rounded-full h-auto align-middle border-none absolute -m-16 -ml-20 lg:-ml-16 max-w-150-px"
                                  alt="..."
                                  accept=".png,.jpg,.jpeg"
                                />
                                :
                                <img
                                  alt="..."
                                  src={posts?.profile ? `http://localhost:3003/images/${posts?.profile}` : dummyProfile}
                                  className="rounded-full h-auto align-middle border-none absolute -m-16 -ml-20 lg:-ml-16 max-w-150-px"
                                />
                              )
                            }

                          </Box>
                          {imageError &&
                            <Box ><p style={{ color: 'red', marginTop: '110px' }}>{showError}</p></Box>
                          }
                          <Box
                            sx={{
                              display: 'flex',
                              flexDirection: 'column',
                              alignItems: 'center',
                              '& > *': {
                                m: 1,
                              },
                            }}

                            style={{ marginTop: '40px' }}
                          >

                            <ButtonGroup variant="text" aria-label="Basic button group">
                              <Button onClick={() => fileInput.current.click()}>Change Profile
                                <input
                                  type="file"
                                  onChange={handleChange}
                                  style={{ display: 'none' }}
                                  ref={fileInput}
                                />
                              </Button>
                              <Button onClick={handleRemoveProfile}>Remove Profile</Button>


                            </ButtonGroup>
                          </Box>

                          <Stack direction="row" spacing={2}>
                            <Button variant="outlined" color="error" onClick={handleCancel}>
                              Cancel
                            </Button>
                            <Button variant="contained" color="success" onClick={(e) => { handleClose(1000); }}>
                              Apply Changes
                            </Button>
                          </Stack>
                        </Box>
                      </Modal>
                    }
                  </div>
                </div>
              </div>

            </div>
            <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
              <form>
                <h6 className="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
                  User Information
                </h6>
                <div className="flex flex-wrap">
                  <div className="w-full lg:w-12 px-4">
                    <div className="relative w-full mb-3">
                      <label
                        className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                        htmlFor="grid-password"
                      >
                        Email address
                      </label>
                      <input
                        type="email"
                        className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        defaultValue={posts?.email}
                        onChange={(e) =>
                          setFormData({ ...formData, email: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div className="w-full lg:w-6/12 px-4">
                    <div className="relative w-full mb-3">
                      <label
                        className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                        htmlFor="grid-password"
                      >
                        First Name
                      </label>
                      <input
                        type="text"
                        style={{ textTransform: 'capitalize' }}
                        className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        defaultValue={posts?.first_name}
                        onChange={(e) =>
                          setFormData({ ...formData, first_name: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div className="w-full lg:w-6/12 px-4">
                    <div className="relative w-full mb-3">
                      <label
                        className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                        htmlFor="grid-password"
                      >
                        Last Name
                      </label>
                      <input
                        type="text"
                        style={{ textTransform: 'capitalize' }}
                        className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        defaultValue={posts?.last_name}
                        onChange={(e) =>
                          setFormData({ ...formData, last_name: e.target.value })
                        }
                      />
                    </div>
                  </div>
                </div>

                <hr className="mt-6 border-b-1 border-blueGray-300" />

                <h6 className="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
                  Contact Information
                </h6>
                <div className="flex flex-wrap">
                  <div className="w-full lg:w-12/12 px-4">
                    <div className="relative w-full mb-3">
                      <label
                        className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                        htmlFor="grid-password"
                      >
                        Address
                      </label>
                      <input
                        type="text"
                        className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        defaultValue={posts?.address}
                        onChange={(e) =>
                          setFormData({ ...formData, address: e.target.value })
                        }
                      />
                    </div>
                  </div>
                  <div className="w-full lg:w-4/12 px-4">
                    <div className="relative w-full mb-3">
                      <label
                        className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                        htmlFor="grid-password"
                      >
                        Contact Number
                      </label>
                      <input
                        type="tel"
                        pattern="[0-9]*"
                        className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        defaultValue={posts?.phone_number}
                        onChange={(e) =>
                          setFormData({ ...formData, phone_number: e.target.value })
                        }
                      />
                    </div>
                  </div>
                </div>

                <hr className="mt-6 border-b-1 border-blueGray-300" />

                <h6 className="text-blueGray-400 text-sm mt-3 mb-6 font-bold uppercase">
                  About Me
                </h6>
                <div className="flex flex-wrap">
                  <div className="w-full lg:w-12/12 px-4">
                    <div className="relative w-full mb-3">
                      <label
                        className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                        htmlFor="grid-password"
                      >
                        About me
                      </label>
                      <textarea
                        type="text"
                        className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        defaultValue={posts?.about}
                        rows="4"

                        onChange={(e) =>
                          setFormData({ ...formData, about: e.target.value })
                        }
                      ></textarea>
                    </div>
                  </div>
                </div>

                <Stack direction="row" spacing={2}>
                  <Button variant="contained" endIcon={<SendIcon />} onClick={handleSubmit}>
                    Update
                  </Button>
                </Stack>
              </form>
            </div>
          </div>
        </>
      )}
      <ToastContainer containerId="A" />
      <ToastContainer containerId="B" />
    </>
  );
}
