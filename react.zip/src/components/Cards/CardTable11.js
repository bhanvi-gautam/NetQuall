import React from "react";
import NoDataFound from "./NoDataFound";

export default function CardTable11({ heading, content,errorMessg }) {
  
    let flag=0;
    return (
        <>
            <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded bg-white">
                <div className="block w-full overflow-x-auto">

                    <table className="items-center w-full bg-transparent border-collapse">
                        <thead>
                            <tr>
                                {heading?.map((data,index) => (
                                    <th key={index}
                                        className={
                                            "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                                        }
                                    >
                                        {data}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {content?.map((data1,index)=>{
                                flag++;
                                return(
                            <tr key={index} >
                                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                   { data1?.quizName}
                                </td>
                                <td className="border-t-0 px-6 align-right border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                {data1?.quiz_marks}
                                </td>
                                <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                {data1?.userQuizDetails[0].score}
                                </td>
                            </tr>
                                )
                            })}
                        </tbody>
                    </table>

                    {flag === 0 && <NoDataFound content={errorMessg} />}
                </div>
            </div>
        </>
    );
}