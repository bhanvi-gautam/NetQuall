import { Box, Button, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { useGetOneQuizMutation, useUpdateQuizMutation } from "../rtk/AddSlice";
import { decryptData, encryptData } from "../../assets/security/encryDecrypt";
import PostDetailsShimmer from "../Effects/PostDetailsShimmer";
import { notifyError } from "../../toast";
import { ToastContainer } from "react-toastify";
import DeleteIcon from '@mui/icons-material/Delete';
import IconButton from '@mui/material/IconButton';
import { v4 as uuidv4 } from 'uuid';

const EditQuiz = () => {
  const quizId = useParams();
  const [getData, { isLoading, isSuccess, post }] = useGetOneQuizMutation();
  const [updateData]=useUpdateQuizMutation();
  const [posts, setPosts] = useState(post);
  const [quizData, setQuizData] = useState(post);
  const [error, setError] = useState(0);
  const navigate=useNavigate();
  const getQuiz = async () => {
    const encryptedId = encryptData(quizId);
    await getData({ id: encryptedId }).then((data) => {
      const temp = decryptData(data.data.encryptedData);
      setPosts(temp);
      setQuizData(temp);
    });
  };
  useEffect(() => {
    getQuiz();
  }, []);

  const addQuestion = () => {
    setQuizData({
      ...quizData,
      quizQuestions: [...quizData.quizQuestions, { id: uuidv4(), question: "", question_marks: 0, question_type: false, quizOptions: [{ id: uuidv4(), option_text: "", is_correct: 0 }, { id: uuidv4(), option_text: "", is_correct: 0 }] }]
    });
  };

  useEffect(() => {
    setQuizData(quizData)
  }, [quizData]);


  const deleteQuestion = (id) => {
    if (quizData.quizQuestions.length <= 1) {
      notifyError("At least one question should be in the quiz");
      return;
    }
    setQuizData({
      ...quizData,
      quizQuestions: quizData.quizQuestions.filter((question) => question.id !== id)
    });
  };

  const deleteOption = (qIndex, id) => {
    if (quizData?.quizQuestions[qIndex]?.quizOptions?.length === 2) {
      notifyError("Each question should have at least two options");
      return;
    }
    console.log('qIndex', qIndex)
    console.log('id', id)
    const updatedQuizData = { ...quizData };
    updatedQuizData.quizQuestions[qIndex].quizOptions = updatedQuizData?.quizQuestions[qIndex]?.quizOptions?.filter((option) => { 
      console.log('option.id', option.id); 
      return option.id !== id 
    });
    setQuizData(updatedQuizData);
  };

  const addOption = (qIndex) => {
    const updatedQuizData = { ...quizData };
    updatedQuizData.quizQuestions[qIndex].quizOptions.push({ id: uuidv4(), option_text: "", is_correct: 0 });
    setQuizData(updatedQuizData);
  };

  // const deleteOption = (qIndex, oIndex) => {
  //   console.log('qIndex', qIndex)
  //   console.log('oIndex', oIndex)
  //   // if (quizData.quizQuestions[qIndex].quizOptions.length === 2) {
  //   //   notifyError("Each question should have at least two options");
  //   //   return;
  //   // }
  //   // const updatedQuizData = { ...quizData };
  //   // updatedQuizData.quizQuestions[qIndex].quizOptions = updatedQuizData.quizQuestions[qIndex].quizOptions.filter((_, index) => index !== oIndex);
  //   // setQuizData(updatedQuizData);
  // };

  const getTotalMarksChange = (value, qIndex) => {
    if (quizData) {
      const updatedQuizData = { ...quizData };
      if (value < 1) {
        notifyError("Minimum marks must be 1")
        return;
      }
      updatedQuizData.quizQuestions[qIndex].question_marks = value;
      updatedQuizData.quiz_marks = updatedQuizData.quizQuestions.reduce((total, question) => total + Number(question.question_marks), 0);

      setQuizData(updatedQuizData);
    }
  }

  const handleQuestionTypeChange = (value, qIndex) => {
    if (quizData) {
      const updatedQuizData = { ...quizData };
      updatedQuizData.quizQuestions[qIndex].question_type = value;
      setQuizData(updatedQuizData);
    }
  };
  const handleCorrectAnswerChange = (qIndex, oIndex) => {
    if (quizData) {
      const updatedQuizData = { ...quizData }
      console.log('updatedQuizData.quizQuestions[qIndex].question_type', updatedQuizData.quizQuestions[qIndex].question_type)
      if (!updatedQuizData.quizQuestions[qIndex].question_type) {
        // Radio
        updatedQuizData.quizQuestions[qIndex].quizOptions =
          updatedQuizData.quizQuestions[qIndex].quizOptions.map(
            (option, index) => {
              console.log("index :>> ", index);
              console.log("oIndex :>> ", oIndex);
              if (index === oIndex) {
                option.is_correct = 1;
              }
              else {
                option.is_correct = 0;
              }
              return option;
            }
          );
      } else {
        // Checkbox
        let flag = 0; // Reset flag
        updatedQuizData.quizQuestions[qIndex].quizOptions =
          updatedQuizData.quizQuestions[qIndex].quizOptions.map(
            (option, index) => {
              if (index === oIndex) {
                option.is_correct = !option.is_correct;
              }
              console.log('option.is_correct', option.is_correct)
              if (option.is_correct === true) {
                flag++;
                // console.log('flag', flag)
              }
              return option;
            }
          );
        if (flag == 0) {
          setError(1); // If no option is selected, set error
        } else {
          setError(0); // Otherwise, clear error
        }
      }
      console.log("updatedQuizData", updatedQuizData);
      setQuizData(updatedQuizData);
    }
  }

  const handleInputChange = (value, qIndex, oIndex) => {
    if (quizData) {
      if (value.trim() === "") {
        notifyError("Input cannot be empty");
        return;
      }
      console.log("value :>> ", value);
      const updatedQuizData = { ...quizData };
      if (oIndex === undefined) {
        updatedQuizData.quizQuestions[qIndex].question = value;
      } else {
        updatedQuizData.quizQuestions[qIndex].quizOptions[
          oIndex
        ].option_text = value;
      }
      console.log("updatedQuizData", updatedQuizData);
      setQuizData(updatedQuizData);
    }
  };

  const handleSubmit =async (e) => {
    e.preventDefault();
    console.log('error', error)
    if (error) {
      notifyError("Fill all the details");
      return;
    }
    // if (flag !== 0) {
    console.log("Edited quiz:", quizData);
    const encryptedData=encryptData(quizData);
    await updateData({encryptedData}).unwrap().then((data)=>{
      console.log('data', data)
      navigate('/viewAllQuizzes')
    }).catch((error)=>{
      console.log('error', error);
    })
    // }
  };


  return (
    <Box className="w-full mb-12">
      <Box
        className="relative md:pt-30 pb-32 pt-12"
        style={{ backgroundColor: "#0099CC" }}
      >
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
          }}
        >
          <Typography gutterBottom variant="h4" component="div">
            Edit Quiz
          </Typography>
        </Box>
      </Box>
      {isLoading && <PostDetailsShimmer />}

      {quizData && <div className="flex-auto px-4 lg:px-10 py-10 pt-10">
        <form onSubmit={handleSubmit}>
          <div className="flex flex-wrap">
            <div className="w-full lg:w-12 px-4">
              <div className="relative w-full mb-3">
                <label className="block uppercase text-blueGray-600 text-s font-bold mb-2or SAP Deployment activities.">
                  Quiz Name:
                </label>
                <input
                  type="text"
                  defaultValue={quizData?.quizName}
                  onChange={(e) => setQuizData({
                    ...quizData,
                    quizName: e.target.value !== '' ? e.target.value : posts.quizName
                  })}
                  className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                  required
                />
              </div>
            </div>
          </div>
          {quizData?.quizQuestions?.map((question, qIndex) => (
            <div className="flex flex-wrap" key={question.id}>
              <div className="w-full lg:w-12 px-4">
                <div className="relative w-full mb-3">
                  <label className="block uppercase text-blueGray-600 text-s font-bold mb-2">
                    Question {qIndex + 1}:
                    <Button color="success" variant="contained" onClick={() => addOption(qIndex)}>Add Option</Button>
                    <Button color="error" variant="outlined" onClick={() => deleteQuestion(question.id)}>Delete Question</Button>
                    <input
                      type="text"
                      name={`question_${qIndex}`}
                      defaultValue={question.question}
                      onChange={(e) =>
                        handleInputChange(e.target.value, qIndex)
                      }
                      className="border-0 px-3 py-3 mt-1 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    // required
                    />
                  </label>
                  {question?.quizOptions?.map((option, oIndex) => (
                    <div
                      style={{ display: "flex", alignItems: "center" }}
                      key={option.id}
                    >
                      <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                        Option {oIndex + 1}:
                        <IconButton aria-label="delete"  >
                          <DeleteIcon onClick={() => deleteOption(qIndex, option.id)} size="small" />
                        </IconButton>
                        <input
                          type="text"
                          name={`option_${qIndex}_${oIndex}`}
                          defaultValue={option.option_text}
                          onChange={(e) =>
                            handleInputChange(e.target.value, qIndex, oIndex)
                          }
                          className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        // required
                        />
                      </label>
                      <input
                        type={question.question_type ? "checkbox" : "radio"}
                        name={
                          question.question_type
                            ? `option_${qIndex}`
                            : `option_${qIndex}_${oIndex}`
                        }
                        defaultValue={option.id}
                        checked={option.is_correct}
                        onChange={() =>
                          handleCorrectAnswerChange(qIndex, oIndex)
                        }
                        style={{ marginLeft: "20px" }}
                      />

                    </div>
                  ))}

                  <label className="block uppercase text-blueGray-600 text-xs font-bold m-4">
                    Multiple Answers:
                    <input
                      type="checkbox"
                      checked={question.question_type}
                      onChange={(e) =>
                        handleQuestionTypeChange(e.target.checked, qIndex)
                      }
                    />
                  </label>
                  <label className="block uppercase text-blueGray-600 text-xs font-bold mb-6 mt-5">
                    Marks:
                    <input
                      type="number"
                      name={`marks_${qIndex}`}
                      defaultValue={question.question_marks}
                      onChange={(e) =>
                        getTotalMarksChange(e.target.value, qIndex)
                      }
                      className="border-0 px-3 py-3 mt-1 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                      required
                    />
                  </label>
                </div>
              </div>
            </div>
          ))}
          <Button variant="contained" color="success" onClick={addQuestion}>Add Question</Button>
          <p>Total Marks: {quizData?.quiz_marks}</p>
          <Button variant="contained" color="primary" type="submit">Submit Quiz</Button>
        </form>
      </div>}

      <ToastContainer containerId="B" />
    </Box>
  );
};

export default EditQuiz;


