import { Box, Button, FormControl, Input, MenuItem, Paper, Select, Stack, Typography } from '@mui/material'
import SendIcon from '@mui/icons-material/Send';
import AddIcon from '@mui/icons-material/Add';
import DeleteIcon from '@mui/icons-material/Delete';
import React, { useState, useEffect } from "react";
import { useCreateQuizMutation, useGetTeacherSubjectMutation } from "../rtk/AddSlice";
import { notifyError, notifySuccess } from '../../toast';
import { ToastContainer } from 'react-toastify';
import NoDataFound from "../Cards/NoDataFound";
import CardShimmer from "../Effects/CardShimmer";
import DoneIcon from '@mui/icons-material/Done';
import { Switch } from "@material-tailwind/react";
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
// import QuestionBank from './Parts/QuestionBank'

import styled, { createGlobalStyle } from "styled-components";
import { useNavigate } from 'react-router-dom';


const CreateQuiz = () => {
    const [on, toggle] = useState(false);
    const navigate=useNavigate();
    const [getData, { isLoading, isSuccess, post }] = useGetTeacherSubjectMutation();
    const [subject, setSubject] = useState('');
    const [posts, setPosts] = useState(post);
    const userId = localStorage.getItem("userId");
    const [length, setLength] = useState(0);
    const [quiz, setQuiz] = useState({
        quizName: '',
        questions: [
            { text: '', options: ['', ''], correctAnswer: [], marks: '0', multiAnswer: false }
        ],
        subject: ''
    });

    const [sendData] = useCreateQuizMutation();


    const abc = async () => {
        const fetchPosts = await getData({ userId: userId }).unwrap();
        const subjects = decryptData(fetchPosts.encryptedData);
        setLength(subjects.response.data.length);
        setPosts(subjects.response.data);
    };

    useEffect(() => {
        abc();
    }, []);

    const handleQuizNameChange = (e) => {
        setQuiz({ ...quiz, quizName: e.target.value });
    };

    const handleQuestionChange = (index, e) => {
        const newQuestions = [...quiz.questions];
        newQuestions[index].text = e.target.value;
        setQuiz({ ...quiz, questions: newQuestions });
    };

    const handleOptionChange = (questionIndex, optionIndex, e) => {
        const newQuestions = [...quiz.questions];
        newQuestions[questionIndex].options[optionIndex] = e.target.value;
        setQuiz({ ...quiz, questions: newQuestions });
    };

    const handleCorrectAnswerChange = (questionIndex, optionIndex) => {
        const newQuestions = [...quiz.questions];
        if (newQuestions[questionIndex].multiAnswer) {
            const correctAnswerIndex = newQuestions[questionIndex].correctAnswer.indexOf(optionIndex);
            if (correctAnswerIndex === -1) {
                // Ensure correctAnswer is an array before pushing
                if (!Array.isArray(newQuestions[questionIndex].correctAnswer)) {
                    newQuestions[questionIndex].correctAnswer = [];
                }
                newQuestions[questionIndex].correctAnswer.push(optionIndex);
            } else {
                newQuestions[questionIndex].correctAnswer.splice(correctAnswerIndex, 1);
            }
        } else {
            newQuestions[questionIndex].correctAnswer = [optionIndex];
        }
        setQuiz({ ...quiz, questions: newQuestions });
    };



    const handleMultiAnswerToggle = (questionIndex) => {
        const newQuestions = [...quiz.questions];
        newQuestions[questionIndex].multiAnswer = !newQuestions[questionIndex].multiAnswer;
        setQuiz({ ...quiz, questions: newQuestions });
    };




    const handleMarksChange = (qIndex, e) => {
        console.log('object', e.target.value)
        const updatedQuestions = quiz.questions.map((question, index) => {
            if (index === qIndex) {
                return { ...question, marks: e.target.value };
            }
            return question;
        });
        setQuiz({ ...quiz, questions: updatedQuestions });
    };


    const addOption = (questionIndex) => {
        const newQuestions = [...quiz.questions];
        newQuestions[questionIndex].options.push('');
        setQuiz({ ...quiz, questions: newQuestions });

    };


    const addQuestion = () => {
        setQuiz({
            ...quiz,
            questions: [
                ...quiz.questions,
                { text: '', options: ['', ''], correctAnswer: '', marks: '', multiAnswer: false }
            ]
        });
    };

    const getTotalMarks = () => {
        return quiz.questions.reduce((total, question) => total + Number(question.marks || 0), 0);
    };

    const deleteOption = (questionIndex, optionIndex) => {
        const newQuestions = [...quiz.questions];
        if (newQuestions[questionIndex].options.length > 2) {
            newQuestions[questionIndex].options.splice(optionIndex, 1);
            setQuiz({ ...quiz, questions: newQuestions });
        } else {
            notifyError('Each question must have at least 2 options.')
        }
    };

    const deleteQuestion = (questionIndex) => {
        const newQuestions = [...quiz.questions];
        if (newQuestions.length > 5) {
            newQuestions.splice(questionIndex, 1);
            setQuiz({ ...quiz, questions: newQuestions });
        } else {
            notifyError('The quiz must have at least 5 questions.')
        }
    };

    const handleSubject = (event) => {
        setSubject(event.target.value);
        setQuiz(prevQuiz => ({ ...prevQuiz, subject: event.target.value }));
    };

    const checkBeforeSubmit = (e) => {
        e.preventDefault();
        // Check if there are at least 5 questions
        // if (quiz.questions.length < 5) {
        //     notifyError('The quiz must have at least 5 questions.')
        //     return;
        // }

        // Check for any empty question texts or options
        for (let question of quiz.questions) {
            if (question.text.trim() === '' || question.options.some(option => option.trim() === '') || question.marks.trim() === '') {
                notifyError('Please fill out all fields before submitting.')
                return;
            }
        }

        for (let question of quiz.questions) {
            if (question.correctAnswer.length === 0) {
                notifyError('Please fill out correct answers before submitting.')
                return;
            }
        }

        handleSubmit();

    }

    const handleSubmit = async () => {
        // Store the quiz data
        console.log(quiz);
        const encryptedData = encryptData(quiz);
    
        try {
            const response = await sendData({ data: encryptedData });
            console.log('response', response);
            
            if (response.data.status === true) {
                notifySuccess("Quiz saved successfully");
                navigate('/viewAllQuizzes')
            } else {
                notifyError(response.data.message || "Failed to save quiz");
            }
        } catch (error) {
            console.log('error', error);
            if (error && error.data && error.data.message) {
                notifyError(error.response.data.message);
            } else {
                notifyError("Either the quiz name already exists or there is server issue . Kindly check");
            }
        }
    };


    return (
        <Box className="w-full mb-12">
            {isLoading && <CardShimmer />}

            {isSuccess && (
                <>
                    <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
                        <Box
                            className="px-4"
                            sx={{
                                color: "white",
                                width: "100%",
                                position: "absolute",
                                bottom: 0,
                            }}
                        >
                            <Typography gutterBottom variant="h4" component="div">
                                {"Create Quiz"}
                            </Typography>
                        </Box>
                    </Box>
                    {length === 0 ? (<NoDataFound content="No Subjects" />
                    ) : (
                        <>
                            <div className="flex-auto px-4 lg:px-10 py-10 pt-10">
                                <form onSubmit={checkBeforeSubmit}>
                                    <div className="flex flex-wrap">
                                        <div className="w-full lg:w-12 px-4">
                                            <div className="relative w-full mb-3">
                                                <label
                                                    className="block uppercase text-blueGray-600 text-s font-bold mb-2"
                                                >
                                                    Subject Name:
                                                    <Select
                                                        value={subject}
                                                        onChange={handleSubject}
                                                        displayEmpty
                                                        size='small'
                                                        style={{ margin: '7px' }}
                                                        requires
                                                    >
                                                        <MenuItem value="">
                                                            Select Subject
                                                        </MenuItem>
                                                        {posts.map((data, index) => {
                                                            return (
                                                                <MenuItem value={data} key={index}>{data}</MenuItem>
                                                            )
                                                        })}


                                                    </Select>
                                                </label>

                                            </div>
                                        </div>
                                    </div>
                                    <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />
                                    <div className="flex flex-wrap">
                                        <div className="w-full lg:w-12 px-4">
                                            <div className="relative w-full mb-3">
                                                <label
                                                    className="block uppercase text-blueGray-600 text-s font-bold mb-2"
                                                >
                                                    Quiz Name:
                                                </label>
                                                <input type="text" value={quiz.quizName} onChange={handleQuizNameChange} className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                                                    required />

                                            </div>
                                        </div>
                                    </div>
                                    <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />

                                    {quiz.questions.map((question, qIndex) => (

                                        <div className="flex flex-wrap" key={qIndex}>
                                            <div className="w-full lg:w-12 px-4">
                                                <div className="relative w-full mb-3">
                                                    <label className="block uppercase text-blueGray-600 text-s font-bold mb-2">
                                                        <Stack  spacing={2} direction="row-reverse">
                                                            <Button variant="contained" endIcon={<AddIcon />} onClick={addQuestion} color="success">
                                                                Add Question
                                                            </Button>
                                                        </Stack>
                                                        Question {qIndex + 1}:

                                                        <input type="text" value={question.text} onChange={(e) => handleQuestionChange(qIndex, e)} className="border-0 px-3 py-3 mt-1 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                                                    </label>
                                                    {question.options.map((option, oIndex) => (
                                                        <div style={{ display: 'flex', justifyContent: 'space-between', marginLeft: '20px' }} key={oIndex}>
                                                            <Stack direction="row" spacing={2} sx={{mb:2}}>
                                                            <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                                                                Option {oIndex + 1}:
                                                                <input type="text" value={option} onChange={(e) => handleOptionChange(qIndex, oIndex, e)} className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                                                            </label>
                                                            <input type={question.multiAnswer ? "checkbox" : "radio"} checked={question.correctAnswer.includes(oIndex)} onChange={() => handleCorrectAnswerChange(qIndex, oIndex)} />
                                                            </Stack>
                                                            <Button variant="contained" onClick={() => deleteOption(qIndex, oIndex)} color="error" size='small' sx={{mb:2}}>
                                                            <DeleteIcon />
                                                            </Button>
                                                        </div>
                                                    ))}

                                                    <Stack direction="row" spacing={2}>
                                                        <Button variant="contained" endIcon={<AddIcon />} onClick={() => addOption(qIndex)} color="success" size='small'>
                                                            Add Option
                                                        </Button>
                                                    </Stack>

                                                    <label className="block uppercase text-blueGray-600 text-xs font-bold m-4" >
                                                        Multiple Answers:
                                                        <input type="checkbox" checked={question.multiAnswer} onChange={() => handleMultiAnswerToggle(qIndex)} />
                                                    </label>


                                                    <label className="block uppercase text-blueGray-600 text-xs mt-3 font-bold mb-2">
                                                        Marks:
                                                        <input type="number" className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" value={question.marks} onChange={(e) => handleMarksChange(qIndex, e)} min="0" required />
                                                    </label>

                                                    <Stack direction="row" spacing={2}>
                                                        <Button variant="contained" endIcon={<DeleteIcon />} onClick={() => deleteQuestion(qIndex)} color="error" size='small' style={{ margin: '7px' }}>
                                                            Delete Question
                                                        </Button>
                                                    </Stack>

                                                </div>
                                            </div>
                                        </div>
                                    ))}



                                    <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />

                                    <p>Total Marks: {getTotalMarks()}</p>
                                    <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />

                                    <Stack direction="row" spacing={2}>
                                        <Button variant="contained" endIcon={<SendIcon />} onClick={checkBeforeSubmit}>
                                            Submit Quiz
                                        </Button>
                                    </Stack>
                                </form>
                            </div>
                            <ToastContainer containerId="B" />
                            <ToastContainer containerId="A" />
                        </>
                    )}

                </>
            )}
        </Box>

    )
}

export default CreateQuiz
