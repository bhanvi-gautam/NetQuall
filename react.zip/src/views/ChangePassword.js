import { Box, Button, Grid, Input, Stack, TextField, Typography } from '@mui/material'
import { useVerifyPasswordMutation, useChangePasswordMutation } from '../components/rtk/AddSlice';
import { encryptData, decryptData } from '../assets/security/encryDecrypt';
import React, { useEffect, useState } from 'react'
import SendIcon from '@mui/icons-material/Send';
import { notifyError, notifySuccess } from '../toast';
import { ToastContainer } from 'react-toastify';
import Visibility from '@mui/icons-material/Visibility';
import VisibilityOff from '@mui/icons-material/VisibilityOff';
import OutlinedInput from '@mui/material/OutlinedInput';
import InputLabel from '@mui/material/InputLabel';
import InputAdornment from '@mui/material/InputAdornment';
import FormControl from '@mui/material/FormControl';
import IconButton from '@mui/material/IconButton';


const ChangePassword = () => {
    const userId = localStorage.getItem('userId');
    const [oldPassword, setOldPasssword] = useState('');
    const [currentPassword, setCurrentPasssword] = useState('');
    const [confirmPassword, setConfirmPasssword] = useState('');
    const [show, setShow] = useState(false);
    const [checkPassword] = useVerifyPasswordMutation();
    const [sendData] = useChangePasswordMutation();
    const [errorMessage, setErrorMessage] = useState("");
    const [showPassword, setShowPassword] = useState(false);
    const [showPassword1, setShowPassword1] = useState(false);

    const userid = decryptData(userId);

    useEffect(() => {
        console.log('show', show)
    }, [show])

    const handleOldPass = async (e) => {
        e.preventDefault();
        try {

            const data = { userId: userid, oldPassword: oldPassword };
            const encryptedData = encryptData(data);
            let check = await checkPassword({ data: encryptedData }).unwrap();
            if (check.status) {
                setShow(true);
            }
        } catch (error) {
            // window.alert('Wrong Old Password');
            notifyError('Wrong Password!!')
        }

    }
    const handleSubmit = async (e) => {
        e.preventDefault();

        console.log("hi")

        var lowerCase = /[a-z]/g;
        var upperCase = /[A-Z]/g;
        var numbers = /[0-9]/g;
        let checking = 1;
        if (!currentPassword.match(lowerCase)) {
            checking++;
            setErrorMessage("Password should contain at least one lowercase letter!");
        } else if (!currentPassword.match(upperCase)) {
            checking++;
            setErrorMessage("Password should contain at least one uppercase letter!");
        } else if (!currentPassword.match(numbers)) {
            checking++;
            setErrorMessage("Password should contain at least one number also!");
        } else if (currentPassword.length < 10) {
            checking++;
            setErrorMessage("Password length should be more than 10.");
        } 

        if (checking === 1) {


            if (currentPassword !== confirmPassword) {
                notifyError("Passwords do not match!")
            } else {
                const userId = userid;
                const password = currentPassword;
                const data = { userId, password };
                const encryptedData = encryptData(data);

                await sendData({ data: encryptedData }).unwrap().then((data) => {
                    notifySuccess("Password Updated!")
                });
            }

        }
    }

    const handleClickShowPassword = () => setShowPassword((show) => !show);

    const handleMouseDownPassword = (event) => {
        event.preventDefault();
    };
    const handleClickShowPassword1 = () => setShowPassword1((show) => !show);

    const handleMouseDownPassword1 = (event) => {
        event.preventDefault();
    };

    return (
        <Box className="w-full mb-12">
            <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
                <Box
                    className="px-4"
                    sx={{
                        color: "white",
                        width: "100%",
                        position: "absolute",
                        bottom: 0,
                        fontWeight: 700
                    }}
                >
                    <Typography gutterBottom variant="h4" component="div">
                        Change Password
                    </Typography>
                </Box>
            </Box>

            <form className="flex flex-col space-y-4" onSubmit={handleOldPass} style={{
                backgroundColor: "rgb(255 255 255)",
                padding: "16px",
                height: "100vh",
            }}>

                <div className="mb-6">
                    <label htmlFor="password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Current Password: </label>
                    <input type="password" id="password" className="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-1/2 p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" name="oldpassword" placeholder="Enter Current Password" onChange={(e) => { setOldPasssword(e.target.value) }} required />
                </div>
                {!show && <Stack direction="row" spacing={2}>
                    <Button variant="contained" endIcon={<SendIcon />} type='submit' >
                        Next
                    </Button>
                </Stack>
                }


                {show &&
                    <>
                        <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />
                        <form >

                            <FormControl sx={{ m: 1, width: '40ch' }} variant="outlined">
                                <label htmlFor="confirm_password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white" name="confirm_password">New password: </label>
                                <Input
                                    size="small"
                                    id="outlined-adornment-password"
                                    type={showPassword ? 'text' : 'password'}
                                    placeholder="Enter New Password" onChange={(e) => { setCurrentPasssword(e.target.value) }}
                                    required
                                    endAdornment={
                                        <InputAdornment position="end">
                                            <IconButton
                                                aria-label="toggle password visibility"
                                                onClick={handleClickShowPassword}
                                                onMouseDown={handleMouseDownPassword}
                                                edge="end"
                                            >
                                                {showPassword ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    }
                                    label="Password"
                                />
                            </FormControl>
                            <div className="grid gap-6 mb-6 md:grid-cols-2">
                                <div style={{ color: "red" }}> {errorMessage} </div>
                            </div>


                            <FormControl sx={{ m: 1, width: '40ch' }} variant="outlined">
                                <label htmlFor="confirm_password" className="block mb-2 text-sm font-medium text-gray-900 dark:text-white" name="confirm_password">Confirm password: </label>
                                <Input
                                    size="small"
                                    id="outlined-adornment-password"
                                    type={showPassword1 ? 'text' : 'password'}
                                    placeholder="Enter Confirm Password" onChange={(e) => { setConfirmPasssword(e.target.value) }}
                                    required
                                    endAdornment={
                                        <InputAdornment position="end">
                                            <IconButton
                                                aria-label="toggle password visibility"
                                                onClick={handleClickShowPassword1}
                                                onMouseDown={handleMouseDownPassword1}
                                                edge="end"
                                            >
                                                {showPassword1 ? <VisibilityOff /> : <Visibility />}
                                            </IconButton>
                                        </InputAdornment>
                                    }
                                    label="Password"
                                />
                            </FormControl>
                            

                            <Stack direction="row" spacing={2} sx={{ mt: 3 }}>
                                <Button variant="contained" onClick={handleSubmit}>
                                    Change Password
                                </Button>
                            </Stack>



                        </form>
                    </>
                }

            </form>
            <ToastContainer containerId="B" />
            <ToastContainer containerId="A" />

        </Box>
    )
}

export default ChangePassword
