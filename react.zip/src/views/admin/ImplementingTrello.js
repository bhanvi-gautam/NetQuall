import { Box, Button, FormControlLabel, InputAdornment, Modal, Radio, RadioGroup, Stack, TextField, Typography } from '@mui/material'
import React, { useEffect, useState } from 'react'
import { useGetPostsMutation, useGetUserSubjectMutation, useUpdateCourseIdMutation } from '../../components/rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import dummyProfile from '../../assets/img/dummyProfile.png'
import Board, { components } from 'react-trello'
import CustomCard from './Parts/CustomCard';
import Loading from '../auth/Parts/Loading'
import SearchIcon from "@mui/icons-material/Search";
import FilterAltIcon from '@mui/icons-material/FilterAlt';

const ImplementingTrello = () => {
    const [getStudentData] = useGetUserSubjectMutation();
    const [posts, setPosts] = useState([]);
    const [updateData] = useUpdateCourseIdMutation();
    const [getCourseData, { isLoading, isSuccess, data1 }] = useGetPostsMutation();
    const [courses, setCourses] = useState([]);
    const [search, setSearch] = useState("");
    const [sortBy, setSortBy] = useState([]);
    const [boardData, setBoardData] = useState({ lanes: [] });
    const [open, setOpen] = useState(false);
    const [sortOption, setSortOption] = useState('');
    const[searchText,setSearchText]=useState('');
    const [newData,setNewData]=useState([]);

    const handleOpen = () => setOpen(true);
    const handleClose = () => setOpen(false);

    const handleChange = (event) => {
        setSortOption(event.target.value);
        handleClose();
        console.log('event.target.value', event.target.value)
    };

    const handleSearchChange = (event) => {
        setSearchText(event.target.value);
        console.log('event.target.value', event.target.value)
    };

    const fetchData = async () => {
        const fetchPosts = await getCourseData({ search, sortBy }).unwrap();
        const decryptedPosts = decryptData(fetchPosts.data);
        setCourses(decryptedPosts);
    };

    useEffect(() => {

        fetchData();
    }, [getCourseData, search, sortBy]);


    const fetchStudentData = async () => {
        const payload = { roleId: "3" };
        const fetchPosts = await getStudentData(payload).unwrap();
        setPosts(fetchPosts);
    };
    useEffect(() => {

        fetchStudentData();
    }, [getStudentData]);


    console.log('posts', posts);

    // useEffect(() => {
    //     for (let i = 0; i < courses.length; i++) {
    //         if((sortBy==='courseName' || sortBy==='')){
    //             let course = courses[i];
    //             let courseData = { id: course.id, name: course.courseName, students: [] };

    //             posts.data.map((data) => {
    //                 if (data.courseName === course.courseName) {
    //                     data.users.map((user) => {

    //                         courseData.students.push({
    //                             id: user.id,
    //                             student_name: user.first_name + " " + user.last_name,
    //                             profile: user.profile ? `http://localhost:3003/images/${user.profile}` : dummyProfile,
    //                             laneId: course.id

    //                         });
    //                     })
    //                 }
    //         })
    //         newData.push(courseData);
    //         }
            
           
    //     }
    // }, [posts,search,sortBy])

    useEffect(() => {
        let filteredCourses = courses;
        let tempData = [];
    
        // Filter courses based on user's input
        if (searchText) {
            const lowerCaseSearch = searchText.toLowerCase();
            if (sortOption === 'courseName') {
                filteredCourses = courses.filter(course => course.courseName.toLowerCase().includes(lowerCaseSearch));
            } else if (sortOption === 'studentName') {
                filteredCourses = courses.filter(course => {
                    let hasStudent = false;
                    posts.data.forEach(data => {
                        if (data.courseName === course.courseName) {
                            data.users.forEach(user => {
                                const fullName = (user.first_name + " " + user.last_name).toLowerCase();
                                if (fullName.includes(lowerCaseSearch)) {
                                    hasStudent = true;
                                }
                            });
                        }
                    });
                    return hasStudent;
                });
            }
        }
        console.log('filteredCourse', filteredCourses)
    
        for (let i = 0; i < filteredCourses.length; i++) {
            let course = filteredCourses[i];
            let courseData = { id: course.id, name: course.courseName, students: [] };
    
            posts.data.map((data) => {
                if (data.courseName === course.courseName) {
                    data.users.map((user) => {
    
                        courseData.students.push({
                            id: user.id,
                            student_name: user.first_name + " " + user.last_name,
                            profile: user.profile ? `http://localhost:3003/images/${user.profile}` : dummyProfile,
                            laneId: course.id
    
                        });
                    })
                }
            })
    
            tempData.push(courseData);
        }
        setNewData(tempData);
    }, [posts, searchText, sortOption])   
       
    

console.log('newData', newData)
    const handleDragStart = (cardId, laneId) => {
        console.log('drag started')
        console.log(`cardId: ${cardId}`)
        console.log(`laneId: ${laneId}`)
    }

    const handleDragEnd = (cardId, sourceLaneId, targetLaneId) => {
        console.log('drag ended')
        console.log(`cardId: ${cardId}`)
        console.log(`sourceLaneId: ${sourceLaneId}`)
        console.log(`targetLaneId: ${targetLaneId}`)
        updateDataOnDrag(cardId, sourceLaneId, targetLaneId);
    }

    const updateDataOnDrag = async (cardId, sourceLaneId, targetLaneId) => {
        const payload = { userId: cardId, newCourseId: targetLaneId };
        console.log('payload', payload)
        const encryptedData = encryptData(payload);
        updateData({ data: encryptedData }).unwrap().then(async (data) => {
            console.log('updated')
        }).catch((error) => {
            console.log('error', error)
        })
    }

    const components = {}

    const getBoard = async () => {

        const lanes = newData.map(data => ({
            id: data.id,
            title: data.name,
            cards: data.students.map((temp) => {
                return { id: temp.id, title: <CustomCard profile={temp.profile} name={temp.student_name} laneId={temp.laneId} />, laneId: temp.laneId }
            })
        }));

        setBoardData({ lanes });
    };

    useEffect(() => {
        getBoard();
    }, [courses,newData]);

    const shouldReceiveNewData = (nextData) => {
        console.log('New card has been added', nextData);


    };

    const getPlaceholder = () => {
        switch(sortOption) {
            case 'studentName':
                return 'Search by Student Name';
            case 'facultyMembers':
                return 'Search by Faculty Name';
            default:
                return 'Search by Course Name';
        }
    }

    const handleCardAdd = (card, laneId) => {
        console.log(`New card added to lane ${laneId}`, card);
    };

    return (

        <Box className="w-full mb-12">
            {isLoading && <Loading />}
            {isSuccess &&
                <>
                    <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
                        <Box
                            className="px-4"
                            sx={{
                                color: "white",
                                width: "100%",
                                position: "absolute",
                                bottom: 0,
                                fontWeight: 700
                            }}
                        >
                            <Stack direction="row" justifyContent="space-between">
                                <Typography gutterBottom variant="h4" component="div">
                                    Trello
                                </Typography>
                                <Stack direction="row">
                                    <Button variant="text" startIcon={<FilterAltIcon />} sx={{ color: "white" }} onClick={handleOpen}>
                                        Filter
                                    </Button>
                                    <form className="flex">
                                        <TextField
                                            className="form-control mr-2"
                                            type="search"
                                            placeholder={getPlaceholder()}
                                            aria-label="Search"
                                            margin="dense"
                                            sx={{
                                                backgroundColor: 'white',
                                            }}
                                            onChange={handleSearchChange}
                                            style={{ borderRadius: '4px', margin: '4px' }}
                                            InputProps={{
                                                startAdornment: (
                                                    <InputAdornment position="start">
                                                        <SearchIcon />
                                                    </InputAdornment>
                                                ),
                                            }}
                                        />
                                        <Button
                                            type="submit"
                                            variant="contained"
                                            color="success"
                                            style={{ margin: '4px', height: '50px', width: '35px', borderRadius: '2px' }}
                                        >
                                            Search
                                        </Button>
                                    </form>
                                </Stack>
                            </Stack>
                        </Box>
                        <Modal
                            open={open}
                            onClose={handleClose}
                            aria-labelledby="modal-modal-title"
                            aria-describedby="modal-modal-description"
                        >
                            <Box sx={{ width: 400, bgcolor: 'background.paper', border: '2px solid #000', p: 2, mx: 'auto', my: '20%', borderRadius: 2 }}>
                                <Typography id="modal-modal-title" variant="h6" component="h2">
                                    Sort Options
                                </Typography>
                                <RadioGroup aria-label="sort" name="sort1" value={sortOption} onChange={handleChange}>
                                    <FormControlLabel value="courseName" control={<Radio />} label="Course Name" />
                                    <FormControlLabel value="studentName" control={<Radio />} label="Student Name" />
                                    <FormControlLabel value="facultyMembers" control={<Radio />} label="Faculty Members" />
                                </RadioGroup>
                            </Box>
                        </Modal>
                    </Box>
                    {isSuccess &&
                        <div className="w-full lg:w-full " >
                            <Box style={{ display: 'flex', flexWrap: 'wrap' }}>
                                <Board
                                    components={components}
                                    onCardAdd={handleCardAdd}
                                    data={boardData}
                                    onDataChange={shouldReceiveNewData}
                                    handleDragStart={handleDragStart}
                                    handleDragEnd={handleDragEnd}
                                />
                            </Box>
                        </div>
                    }
                </>
            }
        </Box>
    )
}

export default ImplementingTrello
