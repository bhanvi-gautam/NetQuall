import React, { useEffect, useState } from "react";
import { useLoginMutation } from "../../components/rtk/AddSlice";
import { Link, useNavigate } from "react-router-dom";
import backgroundImage from "../../assets/img/register_bg_2.png";
import { encryptData } from "../../assets/security/encryDecrypt";
import Loading from "./Parts/Loading";
import { useDispatch } from "react-redux";
import { setToken } from "../../components/rtk/app/slice";
import { Alert } from "@mui/material";

const Login = () => {
  const dispatch = useDispatch();
  const [sendData, { isLoading, isSuccess, post }] = useLoginMutation();
  const [emailError, setEmailError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [generalError, setGeneralError] = useState(false);
  const [posts, setPosts] = useState(post);

  const navigate = useNavigate();
  console.log(posts);

  useEffect(() => {
  }, [post]);


  const handleSubmit = async (e) => {
    e.preventDefault();
    // try {
    let email = e.target.elements.email.value;
    let password = e.target.elements.password.value;
    let emailRegex = /^[\w-]+(\.[\w-]+)*@([\w-]+\.)+[a-zA-Z]{2,7}$/;
    if (!emailRegex.test(email)) {
      setEmailError(true);
      setPasswordError(false)
      return;
    }

    else if (password.length < 6) {
      setPasswordError(true)
      setEmailError(false)
      return;
    }

    const data = { email, password };
    const encryptedData = encryptData(data);
    await sendData({ data: encryptedData })
      .then((data) => {

        dispatch(setToken(data.data.tokens.access.token));
        localStorage.setItem("token", data.data.tokens.access.token);
        console.log("login")
        const encryptedId = encryptData(data.data.data.id);
        localStorage.setItem("userId", encryptedId);
        localStorage.setItem("roleId", data.data.data.role_Id);

        console.log("data", data.data);
        navigate("/");
      })
      .catch((error) => {
        setGeneralError(true);
        // window.alert("Invalid Credentials");

      });
  };

  const myStyle = {
    backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.01), rgba(0, 0, 0, 0.3)), url(${backgroundImage})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    height: "100vh", // This will cover the full height of the viewport
    width: "100vw",
  };

  console.log("isLoading", isLoading);
  console.log("isSuccess", isSuccess);
  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <>
          <div className="container mx-auto px-4 h-full" style={myStyle}>
            <div className="flex content-center items-center justify-center h-full">
              <div className="w-full lg:w-4/12 px-4">
                <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0">
                  <div className="rounded-t mb-0 px-6 py-6">
                    <div className="text-center mb-3">
                      <h6 className="text-blueGray-700 text-lg font-bold">
                        Sign in with
                      </h6>
                    </div>
                  </div>
                  {emailError &&
                    <Alert style={{ width: '85%', backgroundColor: '#ffb4b4',marginLeft:'28px' }} severity="error">
                      Enter Valid Email
                    </Alert>
                  }
                  {passwordError &&
                    <Alert style={{ width: '85%', backgroundColor: '#ffb4b4',marginLeft:'28px' }} severity="error">
                      Password must be of atleast 6 length
                    </Alert>
                  }
                  {generalError &&
                    <Alert style={{ width: '85%', backgroundColor: '#ffb4b4',marginLeft:'28px' }} severity="error">
                      Invalid Credentials.
                    </Alert>
                  }

                  <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
                    <form onSubmit={handleSubmit}>
                      <div className="relative w-full mb-3">
                        <label
                          className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                          htmlFor="grid-password"
                        >
                          Email
                        </label>
                        <input
                          type="email"
                          name="email"
                          className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                          placeholder="Email"
                        />
                      </div>

                      <div className="relative w-full mb-3">
                        <label
                          className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                          htmlFor="grid-password"
                        >
                          Password
                        </label>
                        <input
                          type="password"
                          name="password"
                          className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                          placeholder="Password"
                        />
                      </div>

                      <div className="text-center mt-6">
                        <button
                          className="bg-blueGray-800 text-white active:bg-blueGray-600 text-sm font-bold uppercase px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 w-full ease-linear transition-all duration-150"
                          type="submit"
                        >
                          Sign In
                        </button>
                      </div>
                    </form>
                  </div>
                </div>
                <div className="flex flex-wrap mt-6 relative">
                  <div className="w-1/2">
                    <Link to="/forgotPassword" className="text-blueGray-200">
                      <small>Forgot password?</small>
                    </Link>
                  </div>
                  <div className="w-1/2 text-right">
                    <Link to="/register" className="text-blueGray-200">
                      <small>Create new account</small>
                    </Link>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </>
  );
};

export default Login;
