import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useGetPostsMutation, useDeletePostMutation } from "../rtk/AddSlice";
import { encryptData, decryptData } from "../../assets/security/encryDecrypt";
import CardTable3 from "../Cards/CardTable3";
import TableShimmer from "../Effects/TableShimmer";
import { Box, Typography } from "@mui/material";
import { useSelector } from "react-redux";

const Education = () => {
  const [getdata, { isLoading, isSuccess, post }] = useGetPostsMutation();
  const [posts, setPosts] = useState(post);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState([]);
  // const [count,setCount]=useState(0);
  const count=useSelector((state)=>state.token.count)
  console.log('count', count)
  const handleSortParent = (value) => {
    setSortBy(value);
  };

  const handleCountParent=(value)=>{
    console.log('hie')
    if(count%3===0){
      setSortBy("");
    }
    else if(count%3===1){
      setSortBy(["courseName", "asc"]);
    }
    else{
      setSortBy(["courseName", "desc"]);
    }
  }

  const filteredData = async () => {
    const fetchPosts = await getdata({
      search: search,
      sortBy: sortBy,
    }).unwrap();
    const temp = decryptData(fetchPosts.data);
    setPosts(temp);
  };

  useEffect(() => {
    filteredData();
  }, [sortBy, search]);

  const handleSearchParent = (value) => {
    setSearch(value);
  };
  console.log("sortBy", sortBy);
  console.log("search", search);

  console.log("posts", posts);
  return (
    <>
      <Box className="w-full mb-12">
        <Box className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12">
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
            <Typography gutterBottom variant="h4" component="div">
              List of Courses
            </Typography>
          </Box>
        </Box>
        {isLoading && <TableShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 pb-32"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >
            <CardTable3
              content={posts}
              heading={["Sno", "Course Name", "Edit", "Delete"]}
              errorMessg={"No Courses available"}
              handleSearchParent={handleSearchParent}
              handleSortParent={handleSortParent}
              handleCountParent={handleCountParent}
            />
          </div>
        )}
      </Box>
    </>
  );
};

export default Education;
