import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useGetStudentAssignDetailsMutation } from '../rtk/AddSlice'
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import TableShimmer from '../Effects/TableShimmer';
import CardTable7 from '../Cards/CardTable7';
import { Typography } from '@mui/material';
import PdfUploader from './Parts/PdfUploader';

const StudentAssignmentDetails = () => {
  const [getData, { isLoading, isSuccess, post }] = useGetStudentAssignDetailsMutation();
  const [posts, setPosts] = useState(post);
  const [show, setShow] = useState(false);
  const {subject,studentId} = useParams();

  console.log('subject123', subject)
  console.log('studentId', studentId)

  const abc = async () => {
    const payload={subject: subject, user_Id:studentId};
    const encryptedData=encryptData(payload);
    const fetchPosts = await getData({encryptedData}).unwrap();
    const students = decryptData(fetchPosts.encryptedData);
    console.log('students', students.response.data)
    setPosts(students.response.data);
  }

  useEffect(() => {
    abc();
  }, [])
  console.log('posts', posts)


  return (
    <>
      <div className="w-full mb-12 px-4">
        {isLoading && <TableShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              alignItems: "center",
              gap: "20px"
            }}
          >
            <CardTable7
              title={"Assignments Delivered By Student of subject :"+subject}
              content={posts}
              heading={[
                "Assignment",
                "Submitted On",
                "Marks",
                "Accepted/Unaccepted",
              ]}
              roleId={3}
              studentId={studentId}
              
              errorMessg={"No Student available"}
            />
          </div>
        )}
      </div>
    </>
  )
}

export default StudentAssignmentDetails
