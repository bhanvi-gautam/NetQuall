import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useGetUserSubjectMutation } from "../rtk/AddSlice";
import CardTable2 from "../Cards/CardTable2";
import TableShimmer from "../Effects/TableShimmer";
import { Box, Typography } from "@mui/material";

const ListStudents = () => {
  const { courseId } = useParams();
  const [getdata, { isLoading, isSuccess, post }] = useGetUserSubjectMutation();
  const [posts, setPosts] = useState(post);

  // const courseId = decryptData(course_Id);

  const abc = async () => {
    const payload = { roleId: "3" };
    // const encryptedData=encryptData(payload);
    const fetchPosts = await getdata(payload).unwrap();
    // const temp = decryptData(fetchPosts.data);
    console.log("fetchPosts", fetchPosts);
    // setPosts(temp);
    setPosts(fetchPosts);
  };

  useEffect(() => {
    abc();
  }, []);
  console.log("posts===", posts?.data);
  return (
    <>
      <Box className="w-full mb-12">
        <Box className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12">
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
            <Typography gutterBottom variant="h4" component="div">
              List of Students
            </Typography>
          </Box>
        </Box>
        {isLoading && <TableShimmer />}
        {isSuccess && (
          <div
            className="relative pb-2 "
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >
            <CardTable2
              title={"List of Students"}
              content={posts?.data}
              heading={[
                "Profile",
                "Student Name",
                "Email",
                "Course",
                "Delete",
                "Accept/Unaccepted",
                "View More",
              ]}
              roleId={3}
              errorMessg={"No Student available"}
            />
          </div>
        )}
      </Box>
    </>
  );
};

export default ListStudents;
