import React, { useState, useEffect } from 'react'
import { useGetOnePostMutation, useGetCourseIdMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import Paper from '@mui/material/Paper';
import { Link } from 'react-router-dom';
import { Typography } from '@mui/material';
import NoDataFound from '../Cards/NoDataFound';

const ViewAssignmentStudent = () => {
    const userId = localStorage.getItem('userId');
    const [getCourseId] = useGetCourseIdMutation();
    const [getData, { isLoading, isSuccess }] = useGetOnePostMutation();
    const [info, setInfo] = useState(null);

    console.log('userId', userId)

    const abc = async () => {
        const fetch = await getCourseId({ userId }).unwrap();
        const decryptedData = decryptData(fetch.data);
        const encryptedId = encryptData({ decryptedData });
        const fetchPt = await getData({ courseId: encryptedId }).unwrap();
        const fetchPosts = decryptData(fetchPt.data);
        console.log("hie--", fetchPosts.userSemesters);
        setInfo(fetchPosts.userSemesters);
    }
    let flag = 0;
    useEffect(() => {
        abc();
    }, [])
    return (
        <div className="w-full mb-12 px-4">
            {isLoading && <CardShimmer />}

            {isSuccess && (

                <div
                    className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
                    style={{
                        display: "flex",
                        flexWrap: "wrap",
                        justifyContent: "space-around",
                    }}
                >
                    <Typography gutterBottom variant="h5" component="div">
                        <div style={{ margin: "10px" }}>Subjects</div>
                    </Typography>
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                        {info?.map((data, index) => {
                            return data.userSubjects.map((data1, index1) => {
                                flag++;
                                return (
                                    <Paper elevation={3} key={index1} style={{ height: '100px', width: '100px', display: 'flex', justifyContent: 'center', alignItems: 'center' ,margin:'15px'}}>
                                        <Link to={"/viewSubjectAssignment/" + data1.subjectName}>{data1.subjectName}</Link>
                                    </Paper>
                                );
                            })
                            if (flag === 0) {
                                return <NoDataFound content={"No Subjects"} />
                            }
                        })}
                    </div>
                </div>

            )}
        </div>
    )
}

export default ViewAssignmentStudent
