import React, { useEffect, useState } from 'react'
import { useGetAssignmentMutation } from '../rtk/AddSlice'
import {decryptData} from "../../assets/security/encryDecrypt"
import CardShimmer from '../Effects/CardShimmer';
import CardTable5 from '../Cards/CardTable5';

const ViewAssignment = () => {

  const [getData, { isLoading, isSuccess, post }] = useGetAssignmentMutation();
  const [posts, setPosts] = useState(post);
  const userId = decryptData(localStorage.getItem('userId'));
  const abc = async () => {
    const fetchPosts = await getData({status:0,user_Id:userId}).unwrap();
    const temp = decryptData(fetchPosts.encryptedData);
    // console.log('fetchPosts', temp)
    setPosts(temp);
  };
  console.log('posts', posts)

  useEffect(() => {
    abc();
  }, []);

  return (
    <>
      <div className="w-full mb-12 px-4">
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <CardTable5
              title={"Assignments Given"}
              content={posts}
              heading={[
                "S no",
                "Assignment",
                "Subject",
                "Deadline Date",
                "Deadline Time"
              ]}
              roleId={2}
              errorMessg={"No Assignments available"}
            />
          </div>
        )}
      </div>
    </>
  )
}

export default ViewAssignment
