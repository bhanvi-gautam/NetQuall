import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Popover from '@mui/material/Popover';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import DeleteIcon from '@mui/icons-material/Delete';
import NoDataFound from "./NoDataFound";
import dummyProfile from "../../assets/img/dummyProfile.png";
import { encryptData } from '../../assets/security/encryDecrypt';
import ViewMore from "./ButtonsFunctions/ViewMore";
import { useSubmissionMutation } from "../rtk/AddSlice";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';

export default function CardTable4({
    title,
    content,
    heading,
    errorMessg,
    subject

}) {
    const [anchorEl, setAnchorEl] = useState(null);
    const [sendData] = useSubmissionMutation();
    const [clicked, setClicked] = useState(false);
    const [marks, setMarks] = useState(null);
    const [error, setError] = useState(null);
    useEffect(() => {

    }, [clicked])

    const [id, setId] = useState();
    let navigate = useNavigate();
    const handleAssignmentSubmission = async (e,id) => {

        e.preventDefault();
        if (marks !== null) {
            setClicked(true);
            const payload = { id: id, marks: marks };
            const encryptedData = encryptData(payload);
            await sendData(encryptedData).unwrap();
        } else {
            setError('Please enter marks before accepting the assignment');
        }
    }

    let flag = 0;
    console.log('content', content)
    return (
        <>
            <div
                className={
                    "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded " +
                    "bg-white"
                }
            >
                <div className="rounded-t mb-0 px-4 py-3 border-0">
                    <div className="flex flex-wrap items-center">
                        <div className="relative w-full px-4 max-w-full flex-grow flex-1">
                            <h3 className={"font-semibold text-lg text-blueGray-700"}>
                                {title}
                            </h3>
                        </div>
                    </div>
                </div>
                <div className="block w-full overflow-x-auto">
                    {/* Projects table */}
                    <table className="items-center w-full bg-transparent border-collapse">
                        <thead>
                            <tr>
                                {heading?.map((data) => (
                                    <th
                                        className={
                                            "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                                        }
                                    >
                                        {data}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {content?.map((data, index) => {
                                if (data.is_available === 1) {
                                    flag++;
                                    return (
                                        <tr key={index}>
                                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                                {data.profile ? (
                                                    <img
                                                        src={`http://localhost:3003/images/${data.profile}`}
                                                        width="100"
                                                        height="100"
                                                        style={{ borderRadius: '50%' }}
                                                    />
                                                ) : (
                                                    <img src={dummyProfile} width="100" height="100" style={{ borderRadius: '50%' }} />
                                                )}
                                            </td>
                                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                                {data.first_name + " " + data.last_name}
                                            </td>
                                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                                {data.email}
                                            </td>
                                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            <Link to={`/viewStudentUnderTeacher/${subject}/${data.id}`}><ArrowForwardIosIcon/></Link> 
                                            </td>
                                            {/* <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                               
                                                {data.userAssignments[0] ?
                                                    <>
                                                        <Link
                                                            to={`http://localhost:3003/download/${data?.userAssignments[0].assignment}`}
                                                        >
                                                            {data?.userAssignments[0].assignment}
                                                        </Link>
                                                        <br /><br />
                                                        Submitted on:{' '}{new Date(data.userAssignments[0].deadlineDate).toISOString().split("T")[0]} at {data.userAssignments[0].deadlineTime}
                                                    </>
                                                    :
                                                    <>
                                                        Not Submitted yet!
                                                    </>
                                                }
                                            </td>
                                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                                <>
                                                    {data.userAssignments[0] ?
                                                        data.userAssignments[0].submission ?
                                                            <>
                                                                <Button variant="contained" color="success">
                                                                    Accepted
                                                                </Button>
                                                                <br /><br />
                                                                Marks Given: {data.userAssignments[0].marks}
                                                            </> :
                                                            <>
                                                                <Button variant="outlined" color="error" onClick={() => setClicked(true)}>
                                                                    Unaccepted
                                                                </Button>
                                                                {clicked &&
                                                                    <form class="max-w-sm mx-auto" onSubmit={(e) => handleAssignmentSubmission(e, data.id)}>
                                                                        <label htmlFor="number-input" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Select a number:</label>
                                                                        <input type="number" id="number-input" aria-describedby="helper-text-explanation" class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500" placeholder="90210" required onChange={(e) => setMarks(e.target.value)} />
                                                                    </form>
                                                                }
                                                                {error && <p>{error}</p>}
                                                            </>
                                                        :
                                                        ""
                                                    }
                                                </>
                                            </td> */}
                                        </tr>
                                    )
                                }
                            })}


                        </tbody>
                    </table>

                    {flag === 0 && <NoDataFound content={errorMessg} />}
                </div>
            </div>
        </>
    );
}