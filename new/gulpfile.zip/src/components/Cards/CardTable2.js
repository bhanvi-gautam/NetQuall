import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Popover from "@mui/material/Popover";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import DeleteIcon from "@mui/icons-material/Delete";
import NoDataFound from "./NoDataFound";
import dummyProfile from "../../assets/img/dummyProfile.png";
import {
  useEnableDisableUserMutation,
  useDeleteProfileMutation,
  useDeleteUserMutation,
} from "../rtk/AddSlice";
import { encryptData } from "../../assets/security/encryDecrypt";
import ViewMore from "./ButtonsFunctions/ViewMore";

export default function CardTable2({ content, heading, roleId, errorMessg }) {
  const [anchorEl, setAnchorEl] = useState(null);
  const [fileToBeRemoved, setFileToBeRemoved] = useState("null");
  const [userToDelete, setUserToDelete] = useState(null);
  const [deletePhoto] = useDeleteProfileMutation();
  const [deleteData] = useDeleteUserMutation();

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };

  const openHover = Boolean(anchorEl);

  const [sendData] = useEnableDisableUserMutation();
  const secretKey = "6d090796-ecdf-11ea-adc1-0242ac112345";
  const [id, setId] = useState();
  let navigate = useNavigate();
  const [open, setOpen] = useState(false);
  // const handleOpen = () => setOpen(true);
  const handleClose = () => setOpen(false);

  const handleOpen = (id) => {
    setOpen(true);
    setId(id);
    console.log("id", id);
  };

  const whenDeleteClicked = (id, profile) => {
    console.log("id", id);
    console.log("profile", profile);
    setUserToDelete(id);
    setFileToBeRemoved(profile);
  };

  const handleDelete = async () => {
    if (userToDelete) {
      let userId = userToDelete;
      try {
        if (fileToBeRemoved) {
          await deletePhoto({ fileToBeRemoved }).unwrap();
        }
        setTimeout(async () => {
          const encryptedUserId = encryptData(userId);
          const abc = await deleteData({
            encryptedUserId: encryptedUserId,
          }).unwrap();
        }, 100);

        // navigate('/viewTeacher');
      } catch (error) {
        console.error("Error in delete operations", error);
      }
    } else {
      console.log("No course selected for deletion");
    }
  };

  const handleDisableUser = async (id) => {
    const encryptedUserId = encryptData(id);
    await sendData(encryptedUserId).unwrap();

    // navigate('/viewTeacher');
  };

  let flag = 0;
  console.log("content", content);
  return (
    <>
      <div className="block w-full overflow-x-auto">
        {/* Projects table */}
        <table className="items-center w-full bg-transparent border-collapse">
          <thead>
            <tr>
              {heading?.map((data) => (
                <th
                  className={
                    "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                  }
                >
                  {data}
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {content?.map((data, index1) => {
              flag++;
              const course = data.courseName;
              const userSemester = data.userSemesters;
              return (
                <React.Fragment key={index1}>
                  {data.users.map((user, index) => {
                    if (user.status === 1) {
                      return (
                        <tr key={index}>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            {user.profile ? (
                              <img
                                src={`http://localhost:3003/images/${user.profile}`}
                                width="100"
                                height="100"
                                style={{ borderRadius: "50%" }}
                              />
                            ) : (
                              <img
                                src={dummyProfile}
                                width="100"
                                height="100"
                                style={{ borderRadius: "50%" }}
                              />
                            )}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            {user.first_name + " " + user.last_name}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            {user.email}
                          </td>
                          {roleId === 2 && (
                            <>
                              <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                {user.teachers.length > 0
                                  ? user.teachers.map((sub) => {
                                      return (
                                        <tr key={sub.userSubject.id}>
                                          {sub.userSubject.subjectName}
                                        </tr>
                                      );
                                    })
                                  : "No Subject"}
                              </td>

                              <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                {user.teachers.length > 0
                                  ? user.teachers.map((sub) => {
                                      const id = sub.userSubject.semester_Id;
                                      // console.log('id', id)
                                      return userSemester.map((sem) => {
                                        if (sem.id === id) {
                                          return (
                                            <tr key={sem.id}>
                                              {sem.semesterNo}
                                            </tr>
                                          );
                                        }
                                      });
                                    })
                                  : "Not yet"}
                              </td>
                            </>
                          )}

                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            {course}
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            <Typography
                              aria-owns={
                                open ? "mouse-over-popover" : undefined
                              }
                              aria-haspopup="true"
                              onMouseEnter={handlePopoverOpen}
                              onMouseLeave={handlePopoverClose}
                            >
                              <DeleteIcon
                                onMouseEnter={() =>
                                  whenDeleteClicked(
                                    data.users[0].id,
                                    data.users[0].profile
                                  )
                                }
                                onClick={handleDelete}
                              />
                            </Typography>
                            <Popover
                              id="mouse-over-popover"
                              sx={{
                                pointerEvents: "none",
                              }}
                              open={openHover}
                              anchorEl={anchorEl}
                              anchorOrigin={{
                                vertical: "bottom",
                                horizontal: "left",
                              }}
                              transformOrigin={{
                                vertical: "top",
                                horizontal: "left",
                              }}
                              onClose={handlePopoverClose}
                              disableRestoreFocus
                            >
                              <Typography sx={{ p: 1 }}>
                                Data will be deleted permanently!.
                              </Typography>
                            </Popover>
                          </td>
                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            <>
                              {user.is_available === 1 ? (
                                <Button variant="contained" color="success">
                                  Accepted
                                </Button>
                              ) : (
                                <Button
                                  variant="outlined"
                                  color="error"
                                  onClick={() => handleDisableUser(user.id)}
                                >
                                  Unaccepted
                                </Button>
                              )}
                            </>
                          </td>

                          <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                            <div>
                              <Button onClick={() => handleOpen(user.id)}>
                                <MoreVertIcon />
                              </Button>
                              <ViewMore
                                handleClose={handleClose}
                                open={open}
                                data={id}
                                roleId={roleId}
                              />
                            </div>
                          </td>
                        </tr>
                      );
                    }
                  })}
                </React.Fragment>
              );
            })}
          </tbody>
        </table>

        {flag === 0 && <NoDataFound content={errorMessg} />}
      </div>
    </>
  );
}
