import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Popover from "@mui/material/Popover";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import NoDataFound from "./NoDataFound";
import { encryptData } from "../../assets/security/encryDecrypt";
import SortIcon from "@mui/icons-material/Sort";
import { useDeletePostMutation } from "../rtk/AddSlice";
import EditIcon from "@mui/icons-material/Edit";
import { Dropdown } from "react-bootstrap";
import { InputAdornment, TextField } from "@mui/material";
import SearchIcon from "@mui/icons-material/Search";
import { useDispatch } from "react-redux";
import { increment } from "../rtk/app/slice";
export default function CardTable3({
  content,
  heading,
  errorMessg,
  handleSearchParent,
  handleSortParent,
  handleCountParent
}) {
  const [open, setOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [deleteData] = useDeletePostMutation();
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState([]);
  const[count,setCount]=useState(0);
  const [courseIdToDelete, setCourseIdToDelete] = useState(null);
  const dispatch=useDispatch();

  const handlePopoverOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handlePopoverClose = () => {
    setAnchorEl(null);
  };
  const openHover = Boolean(anchorEl);

  const dropdown = (
    <Dropdown className="bg-green-600">
      <Dropdown.Toggle variant="success" id="dropdown-basic">
        <SortIcon />
        Sort By
      </Dropdown.Toggle>

      <Dropdown.Menu>
        <Dropdown.Item
          onClick={() => {
            setSortBy(["courseName", "desc"]);
            handleSortParent(["courseName", "desc"]);
          }}
        >
          Course Name (Z-A){" "}
        </Dropdown.Item>
        <Dropdown.Item
          onClick={() => {
            setSortBy(["courseName", "asc"]);
            handleSortParent(["courseName", "asc"]);
          }}
        >
          Course Name(A-Z)
        </Dropdown.Item>
        <Dropdown.Item
          onClick={() => {
            setSortBy("");
            handleSortParent("");
          }}
        >
          Remove
        </Dropdown.Item>
      </Dropdown.Menu>
    </Dropdown>
  );

  const handleCountChange = (e) => {
   e.preventDefault();
    setCount(count + 1);
    dispatch(increment())
    handleCountParent(count + 1);
  };
  

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    handleSearchParent(search);
  };

  const deleteCourse = async () => {
    if (courseIdToDelete) {
      let courseId = courseIdToDelete;
      setTimeout(async () => {
        const deleteInfo = { courseId };
        const encryptedData = encryptData(deleteInfo);
        await deleteData({ encryptedData }).unwrap();
      }, 100);
      setCourseIdToDelete(null);
      // navigate('/viewCourses');
    } else {
      console.log("No course selected for deletion");
    }
  };

  let flag = 0;
  return (
    <>
      <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded bg-white">
        <div className="rounded-t mb-0 px-4 py-3 border-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <div className=" mr-4">{dropdown}</div>
              <form className="flex">
                <TextField
                  className="form-control mr-2"
                  type="search"
                  placeholder="Search by Course"
                  aria-label="Search"
                  value={search}
                  onChange={handleSearchChange}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  }}
                />
                <button
                  className="bg-green-500 hover:bg-green-900 text-black font-bold py-2 px-4 rounded"
                  type="submit"
                  onClick={handleSearch}
                >
                  Search
                </button>
              </form>
            </div>
          </div>
        </div>
        <div className="block w-full overflow-x-auto">
          {/* Projects table */}
          <table className="items-center w-full bg-transparent border-collapse">
            <thead>
              <tr>
                {/* {heading?.map((data) => ( */}
                  <th
                    className={
                      "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                    }
                  >
                    Sno
                  </th>
                  <th
                    className="px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                    onClick={handleCountChange}
                  >
                    Course Name
                  </th>
                  <th
                    className={
                      "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                    }
                  >
                    Edit
                  </th>
                  <th
                    className={
                      "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                    }
                  >
                    Delete
                  </th>
                {/* ))} */}
              </tr>
            </thead>
            <tbody>
              {content?.map((data, index) => {
                flag++;
                return (
                  <tr key={index}>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {index + 1}
                    </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {data.courseName}
                    </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      <Link to={`/courseDetail/editCourse/${data.id}`}>
                        <EditIcon />
                      </Link>
                    {/* </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4"> */}
                      <Typography
                        aria-owns={open ? "mouse-over-popover" : undefined}
                        aria-haspopup="true"
                        onMouseEnter={handlePopoverOpen}
                        onMouseLeave={handlePopoverClose}
                      >
                        <DeleteIcon
                          onMouseEnter={() => setCourseIdToDelete(data.id)}
                          // onClick={deleteCourse}
                          onClick={deleteCourse}
                        />
                      </Typography>
                      <Popover
                        id="mouse-over-popover"
                        sx={{
                          pointerEvents: "none",
                        }}
                        open={openHover}
                        anchorEl={anchorEl}
                        anchorOrigin={{
                          vertical: "bottom",
                          horizontal: "left",
                        }}
                        transformOrigin={{
                          vertical: "top",
                          horizontal: "left",
                        }}
                        onClose={handlePopoverClose}
                        disableRestoreFocus
                      >
                        <Typography sx={{ p: 1 }}>
                          Data will be deleted permanently!.
                        </Typography>
                      </Popover>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {flag === 0 && <NoDataFound content={errorMessg} />}
        </div>
      </div>
    </>
  );
}
