import React, { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import NoDataFound from "./NoDataFound";
import { decryptData, encryptData } from "../../assets/security/encryDecrypt";
import { Box, Button, Modal, Typography } from "@mui/material";
import {
  useAddAssignmentMutation,
  useGetFileIdMutation,
  useUploadPdfMutation,
  useCheckSubmissionMutation,
  useGetMarksMutation
} from "../rtk/AddSlice";

export default function CardTable6({
  title,
  content,
  heading,
  errorMessg,
  subject,
}) {
  let flag = 0;
  console.log("content", content);
  const [sendFileName] = useGetFileIdMutation();
  const [getMarks] = useGetMarksMutation();
  const [pdfFile, setPdfFile] = useState(null);
  const [fileSize, setFileSize] = useState(1);
  const [uploadImage] = useUploadPdfMutation();
  const [addData] = useAddAssignmentMutation();
  const [pdfFileError, setPdfFileError] = useState("");
  const [deadlineDate, setDeadlineDate] = useState();
  const [fileName, setFileName] = useState("");
  const [deadlineTime, setDeadlineTime] = useState();
  const [fileId, setFileId] = useState("");
  const encryptedId = localStorage.getItem("userId");
  const [getData, post] = useCheckSubmissionMutation();
  const userId = decryptData(encryptedId);
  const [file, setFile] = useState();
  const [submissionStatuses, setSubmissionStatuses] = useState({});
  const [marks, setMarks] = useState({});

  const status = 1;
  const [open, setOpen] = useState(false);
  const [assignmentId, setAssignmentId] = useState(0);
  //const handleOpen = () => setOpen(true);
  const handleOpen = (id) => {
    setOpen(true)
    setAssignmentId(id)
  }
console.log("assignmentId==",assignmentId)
  const handleClose = () => setOpen(false);
  const style = {
    position: "absolute",
    top: "50%",
    left: "50%",
    transform: "translate(-50%, -50%)",
    width: 400,
    bgcolor: "background.paper",
    border: "2px solid #000",
    boxShadow: 24,
    p: 4,
  };

  const fileType = ["application/pdf"];
  const handlePdfFileChange = (e) => {
    let selectedFile = e.target.files[0];
    // console.log('selectedFile', selectedFile)
    if (selectedFile) {
      if (selectedFile && fileType.includes(selectedFile.type)) {
        let reader = new FileReader();
        reader.readAsDataURL(selectedFile);
        reader.onloadend = (e) => {
          setFile(selectedFile);
          setPdfFile(e.target.result);
          setPdfFileError("");
          setFileName(selectedFile.name);
          setFileSize(selectedFile.size);
          sendFileName(selectedFile.name)
            .unwrap()
            .then((fetchFileId) => {
              setFileId(fetchFileId.fileId);
            })
            .catch((error) => {
              console.error("Error fetching FileId: ", error);
            });
        };
      } else {
        setPdfFile(null);
        setPdfFileError("Please select valid pdf file");
      }
    } else {
      console.log("select your file");
    }
  };

  useEffect(() => {
    const fetchSubmissionStatuses = async () => {
      const statuses = {};
      content?.map(async (data) => {
        // for (const data of content) {
        const payload = { assign_Id: data.assign_Id, user_Id: userId, subject_Id: data.userSubject.subjectName };
        const encryptedData = encryptData(payload);
        const isSubmitted = await getData({ encryptedData }).unwrap();
        const temp = decryptData(isSubmitted.encryptedData)
        // console.log('temp', temp)
        statuses[data.assign_Id] = temp;
      });
      setSubmissionStatuses(statuses);
    };

    const fetchMarks = async () => {
      const studentMarks = {};
      content?.map(async (data) => {
        const payload = { assign_Id: data.assign_Id, user_Id: userId, subject_Id: data.userSubject.subjectName };
        const encryptedData = encryptData(payload);
        const marksAssigned = await getMarks({ encryptedData }).unwrap();
        console.log('marksAssigned', marksAssigned)
        const temp = decryptData(marksAssigned.encryptedData)
        console.log('temp', temp)
        // return;
        if (temp?.marks) {
          studentMarks[data.assign_Id] = temp.marks;
        }
        else{
          studentMarks[data.assign_Id] = null;
        }
      });
      setMarks(studentMarks);
    }

    fetchSubmissionStatuses();
    fetchMarks();

  }, [content]);
  console.log('submissionStatuses', submissionStatuses)

  // form submit
  const handlePdfFileSubmit = async (e) => {
    e.preventDefault();
    console.log("hie");
    let assignment = "";
    if (fileId) {
      assignment = `file-${fileId}-${fileName}`;
    }
    const currentDate = new Date();
    const deadlineDate = currentDate.toISOString().split("T")[0];
    const deadlineTime = currentDate.toTimeString().split(" ")[0];
    setDeadlineDate(deadlineDate);
    setDeadlineTime(deadlineTime);

    const data = {
      deadlineDate,
      deadlineTime,
      assignment,
      userId,
      status,
      subject,
      assign_Id:assignmentId
    };
    console.log("assignment", data);
    // return
    const start = 0;
    const end = fileSize;
    // return;
    try {
      const fileData = new FormData();
      fileData.append("file", file);
      console.log("fileData1", fileData);
      await uploadImage({
        x: fileData,
        y: fileId,
        z: `bytes=${start}-${end}/${fileSize}`,
      });

      const encryptedData = encryptData(data);
      await addData({ data: encryptedData });
      //checking if submitted

      console.log("fileData1", fileData);


    } catch (error) {
      console.error("Error in upload or add operations", error);
    }
  };

  return (
    <>
      <div
        className={
          "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded " +
          "bg-white"
        }
      >
        <div className="rounded-t mb-0 px-4 py-3 border-0">
          <div className="flex flex-wrap items-center">
            <div className="relative w-full px-4 max-w-full flex-grow flex-1">
              <h3 className={"font-semibold text-lg text-blueGray-700"}>
                {title}
              </h3>
            </div>
          </div>
        </div>
        <div className="block w-full overflow-x-auto">
          {/* Projects table */}
          <table className="items-center w-full bg-transparent border-collapse">
            <thead>
              <tr>
                {heading?.map((data) => (
                  <th
                    className={
                      "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                    }
                  >
                    {data}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {content?.map((data, index) => {
                flag++;
                // console.log('data.assign_Id', data.assign_Id)

                return (
                  <tr key={index}>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      <Link
                        to={`http://localhost:3003/download/${data.assignment}`}
                      >
                        {data.userAssignDetail.AssignName}
                      </Link>
                    </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {data.userSubject.subjectName}
                    </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {new Date(data.deadlineDate).toISOString().split("T")[0]}
                    </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {data.deadlineTime}
                    </td>
                    <input type="hidden" id="assignId" name="assignId" value={data.assign_Id} />


                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {/* {isSubmitted(data.assign_Id,data.user.id,data.userSubject.subjectName)===true ? "Already Submitted" :  */}
                      {submissionStatuses[data.assign_Id] ? "Already Submitted" :
                        <Button onClick={()=>handleOpen(data.assign_Id)}>
                          Do you want to submit?
                        </Button>
                      }
                      <Modal open={open} onClose={handleClose}>
                        <Box sx={style}>
                          <Typography
                            id="modal-modal-title"
                            variant="h6"
                            component="h2"
                          >
                            Upload File
                          </Typography>
                          <Typography
                            id="modal-modal-description"
                            sx={{ mt: 2 }}
                          >
                            <form
                              className="form-group"
                              onSubmit={handlePdfFileSubmit}
                            >
                              <input
                                type="file"
                                className="form-control"
                                required
                                onChange={handlePdfFileChange}
                              />
                              {pdfFileError && (
                                <div className="error-msg">{pdfFileError}</div>
                              )}
                              <br></br>
                              <button type="submit" className="upload">
                                UPLOAD
                              </button>
                            </form>
                          </Typography>
                        </Box>
                      </Modal>
                    </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {marks[data.assign_Id]}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {flag === 0 && <NoDataFound content={errorMessg} />}
        </div>
      </div>
    </>
  );
}
