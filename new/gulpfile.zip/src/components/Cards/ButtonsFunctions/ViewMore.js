import { Box, Fade, Modal, Typography } from '@mui/material'
import Backdrop from '@mui/material/Backdrop';
import Divider from '@mui/material/Divider';
import { useGetUserSubjectMutation } from "../../rtk/AddSlice";
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import { styled } from '@mui/material/styles';
import dummyProfile from "../../../assets/img/dummyProfile.png";
import React, { useState, useEffect, forwardRef } from 'react'

const ViewMore = forwardRef(({ handleClose, open = false, data = '', roleId }, ref) => {

    console.log('data1', data)
    // return;
    const [getdata, { isLoading, isSuccess, post }] = useGetUserSubjectMutation();
    const [posts, setPosts] = useState(post);

    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 400,
        bgcolor: 'background.paper',
        // border: '1px solid #000',
        boxShadow: 12,
        p: 4,
    };

    const Item = styled(Paper)(({ theme }) => ({
        backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
        ...theme.typography.body2,
        padding: theme.spacing(1),
        textAlign: 'center',
        color: theme.palette.text.secondary,
        display: 'flex',
        alignItems: 'center', // Align items vertically
        justifyContent: 'space-between',
    }));
    const abc = async (data) => {
        if (data != '') {
            const payload = { id: data }
            // const encryptedData=encryptData(payload);
            const fetchPosts = await getdata(payload).unwrap();

            // const temp = decryptData(fetchPosts.data);
            // setPosts(temp);
            setPosts(fetchPosts.data[0]);
        }

    };
    useEffect(() => {
        abc(data);
    }, [data]);
    console.log('posts', posts)
    let userSemester;
    if (roleId === 2 && posts!==post) {
        userSemester = posts?.userSemesters;
    }


    return (
        <div>
            {/* 
            {isSuccess &&
           
                <Box sx={style}>
                    <Typography id="transition-modal-title" variant="h6" component="h2">
                        <Stack direction="row" divider={<Divider orientation="vertical" flexItem />} spacing={2}>
                        <Item> {posts?.users[0]?.profile ? (
                            <img
                                src={`http://localhost:3003/images/${posts?.users[0]?.profile}`}
                                width="60"
                                height="60"
                            />
                        ) : (
                            <img src={dummyProfile} width="60" height="60" />
                        )}</Item>

                        <Item>{posts?.users[0]?.first_name + " " + posts?.users[0]?.last_name}</Item>
                        </Stack>
                    </Typography>
                    <Typography id="transition-modal-description" sx={{ mt: 2 }} variant="body1" fontWeight="bold">
                        <Stack spacing={2}>
                            <Item>Course: {posts.courseName}</Item>
                             <Item>Email:{posts?.users[0]?.email}</Item>
                            <Item>Address:{posts?.users[0]?.address}</Item>
                            <Item>Contact No:{posts?.users[0]?.phone_number}</Item>
                            <Item>Subject Name:{posts?.users[0]?.userSubject.subjectName}</Item>
                            <Item>Semester No:{posts?.users[0]?.userSubject.userSemester.semesterNo}</Item> 
                        </Stack>
                    </Typography>
                </Box>
            
 } 
        </Modal> */}

            {isSuccess &&
                <Modal
                    open={open}
                    onClose={handleClose}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                >

                    <Box sx={style}>
                        <Typography id="transition-modal-title" variant="h6" component="h2">

                            <Stack direction="row" divider={<Divider orientation="vertical" flexItem />} spacing={2}>
                                <Item> {posts?.users[0]?.profile ? (
                                    <img
                                        src={`http://localhost:3003/images/${posts?.users[0]?.profile}`}
                                        width="60"
                                        height="60"
                                    />
                                ) : (
                                    <img src={dummyProfile} width="60" height="60" />
                                )}</Item>

                                <Item>{posts?.users[0]?.first_name + " " + posts?.users[0]?.last_name}</Item>
                            </Stack>

                        </Typography>
                        <Typography id="transition-modal-description" sx={{ mt: 2 }}>
                            <Stack spacing={2}>
                                <Item>Course: {posts?.courseName}</Item>
                                <Item>Email:{posts?.users[0]?.email}</Item>
                                <Item>Address:{posts?.users[0]?.address}</Item>
                                <Item>Contact No:{posts?.users[0]?.phone_number}</Item>
                                {roleId === 2 &&
                                    <>
                                        <Item>Subject Name:{posts?.users[0]?.teachers.map((sub, index) => {
                                            return <Item key={index}>{sub.userSubject.subjectName}</Item>
                                        })}</Item>
                                        <Item>Semester No: {posts?.users[0]?.teachers.length > 0 ? posts?.users[0]?.teachers?.map((sub) => {
                                            const id = sub.userSubject.semester_Id;
                                            // console.log('id', id)
                                            return (
                                                userSemester?.map((sem) => {
                                                    if (sem.id === id) {
                                                        return <tr key={sem.id}>{sem.semesterNo}</tr>
                                                    }
                                                }))
                                        }) : 'Not yet'}</Item>
                                    </>
                                }
                            </Stack>
                        </Typography>
                    </Box>

                </Modal>
            }
        </div>
    )
}
)
export default ViewMore
