const {v4:uuidv4}=require("uuid");

module.exports={
    generateUniqueId:()=>{
        return uuidv4();
    },

    getFilePath:(fileName,fileId)=>{
        return `c:/Users/Bhanvi/Desktop/react/node-express-mysql-boilerplate-master/node-express-mysql-boilerplate-master/src/utils/images/file-${fileId}-${fileName}`;
    },

    getPdfPath:(fileName,fileId)=>{
        return `c:/Users/Bhanvi/Desktop/react/node-express-mysql-boilerplate-master/node-express-mysql-boilerplate-master/src/utils/assignments/file-${fileId}-${fileName}`;
    }
}