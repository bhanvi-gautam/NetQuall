
const UserAssignmentDao = require("../dao/userAssignmentDao");
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { response } = require('express');
const logger = require('../config/logger');
const httpStatus = require('http-status');

class UserAssignment {
    constructor() {
        this.userAssignmentDao = new UserAssignmentDao();
    }
    getAssignment = async (req) => {
        try {
            const assignment=await this.userAssignmentDao.findAssignment(req);
            console.log('assignment', assignment)
            if(assignment){
                return responseHandler.returnSuccess(
                    httpStatus.OK,
                    "Assignments fetched successfully",
                    assignment
                );
            }
            else{
                return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR,"No assignments")
            }
            
        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    };
 
}



module.exports = UserAssignment;