let fs=require('fs')

const asyncWrapper = (fn) => {
    return async (req, res, next) => {
      try {
        await fn(req, res, next);
       
      } catch (error) {
        console.log("temp===",error);
        let writer = fs.createWriteStream('errorLog.txt', { 
          flags: 'a' 
        }); 

        writer.write(`\n${new Date().toISOString()} - ${error.toString()}`);
        
        next(error)
      }
    }
  }
  
  module.exports = asyncWrapper

 
        
        
       
        
        
     