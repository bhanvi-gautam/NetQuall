const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userAssignment extends Model {
        static associate(models) {
            userAssignment.belongsTo(models.user, { foreignKey: 'user_Id', targetKey: 'id' });
            userAssignment.belongsTo(models.userSubject, { foreignKey: 'userSubject_Id', targetKey: 'id' });
        }
    }
    userAssignment.init(
        {
            uuid: DataTypes.UUID,
            assignment: { type: DataTypes.STRING, defaultValue: null },
            deadlineDate: DataTypes.DATE,
            deadlineTime: DataTypes.TIME,
            status: {
                type: DataTypes.INTEGER,
                comment: 'status: 0 = By Teacher, 1 = By Student',
            },
            user_Id: DataTypes.INTEGER,
            
        },
        {
            sequelize,
            modelName: 'userAssignment',
            underscored: false,
        },
    );
       
    return userAssignment;
};