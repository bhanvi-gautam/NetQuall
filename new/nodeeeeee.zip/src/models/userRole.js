const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userRole extends Model {
        
        static associate(models) {
            // define association here
            userRole.hasMany(models.user,{foreignKey: 'role_Id' })
        }
    }

    userRole.init(
        {
            uuid: DataTypes.UUID,
            role_name: DataTypes.STRING,

        },
        {
            sequelize,
            modelName: 'userRole',
            underscored: false,
        },
    );
    return userRole;
};