const express = require('express');
const authRoute = require('./authRoute');
const userRoute = require('./userRoute');
const lmsroute=require('./lmsRoute');

const router = express.Router();

const defaultRoutes = [
    {
        path: '/auth',
        route: authRoute,
    },
    {
        path: '/user',
        route: userRoute,
    },
    {
        path:'/lms',
        route: lmsroute,
    }
];

defaultRoutes.forEach((route) => {
    router.use(route.path, route.route);
});

module.exports = router;
