const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userSemester extends Model {
        
        static associate(models) {
            // define association here
            userSemester.belongsTo(models.userCourse, { foreignKey: 'course_Id', targetKey: 'id' });
            userSemester.hasMany(models.userSubject,{ foreignKey: 'semester_Id'});
        }
    }

    userSemester.init(
        {
            uuid: DataTypes.UUID,
            semesterNo: DataTypes.INTEGER,
            is_available: { type: DataTypes.INTEGER, defaultValue: '0' },

        },
        {
            sequelize,
            modelName: 'userSemester',
            underscored: false,
        },
    );
    return userSemester;
};