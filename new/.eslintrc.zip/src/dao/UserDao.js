const SuperDao = require('./SuperDao');
const models = require('../models');

const User = models.user;

class UserDao extends SuperDao {
    constructor() {
        super(User);
    }

    async findByEmail(email) {
        return User.findOne({ where: { email } });
    }

    async isEmailExists(email) {
        return User.count({ where: { email } }).then((count) => {
            if (count != 0) {
                return true;
            }
            return false;
        });
    }

    async createWithTransaction(user, transaction) {
        return User.create(user, { transaction });
    }

    async findUsers(requestWhere){
        // let {where}=requestWhere;
        return User.findAll({
            where:{

            },
            attributes:['id','first_name','last_name','email','address','phone_number','profile','occupation']
        })
        .then((result)=>{
            return result;
        })
        .catch((e)=>{
            logger.error(e);
            console.log(e);
        });
    } 

    
}

module.exports = UserDao;
