const SuperDao = require('./SuperDao');
const models = require('../models');

const userSubject = models.userSubject;

class userSubjectDao extends SuperDao {
    constructor() {
        super(userSubject);
    }

    
 
}

module.exports = userSubjectDao;
