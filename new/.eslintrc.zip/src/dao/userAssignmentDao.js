const SuperDao = require('./SuperDao');
const models = require('../models');
const logger = require('../config/logger');

const userAssignment = models.userAssignment;
const userSubject = models.userSubject;
const user = models.user;

class UserAssignmentDao extends SuperDao {
    constructor() {
        super(userAssignment);
    }
    async findAssignment(req) {
        try {
            console.log('req', req)
            const result = await userAssignment.findAll({

                where: req.status ?
                    {
                        status: req.status
                    } : {},
                attributes: ['id', 'assignment', 'deadlineDate', 'deadlineTime', 'status'],
                include: [{
                    model: user,
                    where: req.user_Id ?
                        {
                            id: req.user_Id
                        } : {},
                    attributes: ['id', 'first_name', 'last_name'],
                }, {
                    model: userSubject,
                    where: req.subject ?
                        {
                            subjectName: req.subject
                        } : {},
                    attributes: ['id', 'subjectName']
                },
                ]
            });
            return result;
        } catch (error) {
            logger.error(error);
            throw error;
        }

    }
}
module.exports = UserAssignmentDao;