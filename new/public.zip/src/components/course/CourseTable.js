import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
// import CardTable from '../Cards/CardTable'
import CardItem from "../Cards/CardItem";
import { useGetPostsMutation } from "../rtk/AddSlice";
import {decryptData,encryptData} from "../../assets/security/encryDecrypt";
import Typography from "@mui/material/Typography";
import LmsShimmer from "../Effects/TableShimmer";

const CourseTable = () => {
  let navigate = useNavigate();
  const [getdata, { isLoading, isSuccess, post }] = useGetPostsMutation();
  // const [deleteData] = useDeletePostMutation();
  const [posts, setPosts] = useState(post);
  // const [courseIdToDelete, setCourseIdToDelete] = useState(null);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState([]);
 
  const filteredData = async () => {
    const fetchPosts = await getdata({
      search: search,
      sortBy: sortBy,
    }).unwrap();
    const temp = decryptData(fetchPosts.data);
    setPosts(temp);
  };

  useEffect(() => {
    filteredData();
  }, [sortBy]);
  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    filteredData();
  };

  return (
    <div className="w-full mb-12 px-4">
      {isLoading && <LmsShimmer row={10} col={4} />}

      {isSuccess && (
        <>
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <div style={{ color: "white", width: "100%" }}>
              <Typography gutterBottom variant="h3" component="div">
                All Courses
              </Typography>
            </div>
            <br />

            {posts?.map((data, index) => (
              <div key={index}>
                <CardItem courseId={data.id} content={data.courseName} />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default CourseTable;
