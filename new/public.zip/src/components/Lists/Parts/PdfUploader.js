import React, { useState } from 'react'
// Import the main component
import { Viewer } from '@react-pdf-viewer/core'; // install this library
// Plugins
import { defaultLayoutPlugin } from '@react-pdf-viewer/default-layout'; // install this library
// Import the styles
import '@react-pdf-viewer/core/lib/styles/index.css';
import '@react-pdf-viewer/default-layout/lib/styles/index.css';
// Worker
import { Worker } from '@react-pdf-viewer/core'; // install this library
import './PdfUploader.css';
import { useGetFileIdMutation, useUploadPdfMutation, useAddAssignmentMutation } from '../../rtk/AddSlice';
import { decryptData, encryptData } from '../../../assets/security/encryDecrypt';

export const PdfUploader = (subject) => {

    // Create new plugin instance
    const defaultLayoutPluginInstance = defaultLayoutPlugin();

    // for onchange event
    const [sendFileName] = useGetFileIdMutation();
    const [pdfFile, setPdfFile] = useState(null);
    const [fileSize, setFileSize] = useState(1);
    const [uploadImage] = useUploadPdfMutation();
    const [addData] = useAddAssignmentMutation();
    const [pdfFileError, setPdfFileError] = useState('');
    const [deadlineDate, setDeadlineDate] = useState();
    const [fileName, setFileName] = useState('');
    const [deadlineTime, setDeadlineTime] = useState();
    const [fileId, setFileId] = useState("");
    const encryptedId=localStorage.getItem('userId');
    const userId=decryptData(encryptedId);
    const [file,setFile]=useState();
    const status=0;
    
    // for submit event
    // const [viewPdf, setViewPdf] = useState(null);

    // onchange event
    const fileType = ['application/pdf'];
    const handlePdfFileChange = (e) => {
        let selectedFile = e.target.files[0];
        // console.log('selectedFile', selectedFile)
        if (selectedFile) {
            if (selectedFile && fileType.includes(selectedFile.type)) {
                let reader = new FileReader();
                reader.readAsDataURL(selectedFile);
                reader.onloadend = (e) => {
                    setFile(selectedFile);
                    setPdfFile(e.target.result);
                    setPdfFileError('');
                    setFileName(selectedFile.name);
                    setFileSize(selectedFile.size);
                    sendFileName(selectedFile.name)
                        .unwrap()
                        .then((fetchFileId) => {
                            setFileId(fetchFileId.fileId);
                        })
                        .catch((error) => {
                            console.error("Error fetching FileId: ", error);
                        });
                }
            }
            else {
                setPdfFile(null);
                setPdfFileError('Please select valid pdf file');
            }
        }
        else {
            console.log('select your file');
        }
    }

    // form submit
    const handlePdfFileSubmit = async (e) => {
        e.preventDefault();
        console.log("hie")
        let assignment = ""
        if (fileId) {
            assignment = `file-${fileId}-${fileName}`
        }
        const data = { deadlineDate, deadlineTime, assignment ,userId,status,subject};
        console.log('assignment', assignment)
        const start = 0;
        const end = fileSize;
       
        try {
            const fileData = new FormData();
            fileData.append("file", file);
            console.log('fileData1', fileData)
            await uploadImage({
                x: fileData,
                y: fileId,
                z: `bytes=${start}-${end}/${fileSize}`,
            });

            const encryptedData = encryptData(data);
            await addData({ data: encryptedData });
            console.log('fileData1', fileData)
            // navigate('/login')
        } catch (error) {
            console.error("Error in upload or add operations", error);
        }
        // if (pdfFile !== null) {
        //     setViewPdf(pdfFile);
        // }
        // else {
        //     setViewPdf(null);
        // }
    }
    console.log('deadline', deadlineDate)
    return (
        <div className='container'>

            <br></br>

            <form className='form-group' onSubmit={handlePdfFileSubmit}>
                <input type="file" className='form-control'
                    required onChange={handlePdfFileChange}
                />
                {pdfFileError && <div className='error-msg'>{pdfFileError}</div>}
                <br></br>
                <label htmlFor="date">Deadline Date for Submission:</label>
                <input type="date" name="date"
                    className='form-control' required onChange={(e) => setDeadlineDate(e.target.value)}
                    min={new Date().toISOString().split("T")[0]}
                />
                <br></br>
                <label htmlFor="time">End Time for Submission on the Last Day:</label>

                <input type="time" name="time"
                    className='form-control' required onChange={(e) => {
                        setDeadlineTime(e.target.value);
                    }
                    }
                />
                <br></br>
                <button type="submit" className='upload' >
                    UPLOAD
                </button>
            </form>
            <br></br>
            {/* <h4>View PDF</h4>
            <div className='pdf-container'>
                {/* show pdf conditionally (if we have one)  */}
            {/*{viewPdf && <><Worker workerUrl="https://unpkg.com/pdfjs-dist@2.6.347/build/pdf.worker.min.js">
                    <Viewer fileUrl={viewPdf}
                        plugins={[defaultLayoutPluginInstance]} />
                </Worker></>}

                {/* if we dont have pdf or viewPdf state is null */}
            {/*{!viewPdf && <>No pdf file selected</>}
            </div> */}

        </div>
    )
}

export default PdfUploader