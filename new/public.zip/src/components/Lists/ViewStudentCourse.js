import React, { useState, useEffect } from 'react'
import { useGetOnePostMutation, useGetCourseIdMutation,useGetUserSubjectMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import CardTable from '../Cards/CardTable';


const ViewStudentCourse = () => {
    const userId = localStorage.getItem('userId');
    const [getCourseId] = useGetCourseIdMutation();
    const [getData, { isLoading, isSuccess }] = useGetOnePostMutation();
    const [getTeacher, { post }] = useGetUserSubjectMutation();
    const [posts, setPosts] = useState(post);
    const [info, setInfo] = useState(null);

    console.log('userId', userId)

    const abc = async () => {
        try {
            const fetch = await getCourseId({ userId }).unwrap();
            const decryptedData = decryptData(fetch.data);
            const encryptedId = encryptData({ decryptedData });
            const fetchPt = await getData({ courseId: encryptedId }).unwrap();
            const fetchPosts = decryptData(fetchPt.data);
            console.log("hie--", fetchPosts);

            setInfo(fetchPosts);


            const payload = { courseId: fetchPosts.id, roleId: '2' }
            const fetchPosts2 = await getTeacher(payload).unwrap();
            console.log('fetchPosts', fetchPosts2)
            // setPosts(temp);
            setPosts(fetchPosts2);
        } catch (error) {
            console.error("Error:", error);
        }
    };

console.log('posts123', posts)
    useEffect(() => {
        abc();
    }, [userId]);
    return (
        <div className="w-full mb-12 px-4">
            {isLoading && <CardShimmer />}
            {isSuccess && (
                <>
                    <div>
                        <div
                            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
                            style={{
                                display: "flex",
                                flexWrap: "wrap",
                                justifyContent: "space-around",
                            }}
                        >
                            <h1>Update details</h1>
                        </div>

                        <div>
                            Course: {info?.courseName}
                            <br />
                            {info?.userSemesters.map((sem, index1) => (
                                <div key={sem.id}>
                                    <span>SemesterNo {index1 + 1}: {sem.semesterNo}</span>
                                    <br />
                                    {sem.userSubjects?.map((sub, index2) => (
                                        <div key={sub.id}>
                                            <span>Subject Name: {sub.subjectName}</span>
                                        </div>
                                    ))}
                                    <hr />
                                </div>
                            ))}
                        </div>
                    </div>

                    <div
                        className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
                        style={{
                            display: "flex",
                            flexWrap: "wrap",
                            justifyContent: "space-around",
                        }}
                    >
                        <CardTable
                            title={"List of Faculty Members"}
                            content={posts?.data}
                            heading={[
                                "Profile",
                                "Faculty Name",
                                "Email",
                                "Subject",
                                "Semester No",
                            ]}
                            role={2}
                            errorMessg={"No Faculty available for this Course yet!"}
                        />
                    </div>

                </>
            )
            }
        </div >
    )
}

export default ViewStudentCourse;
