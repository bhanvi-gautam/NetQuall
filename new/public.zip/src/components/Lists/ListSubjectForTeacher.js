import React, { useState, useEffect } from 'react'
import { useGetTeacherSubjectMutation } from '../rtk/AddSlice';
import { decryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import Paper from '@mui/material/Paper';
import { Link } from 'react-router-dom';
import { Typography } from '@mui/material';
import NoDataFound from '../Cards/NoDataFound';

const ListSubjectForTeacher = () => {
    const [getData, { isLoading, isSuccess, isError, post }] = useGetTeacherSubjectMutation();
    const [posts, setPosts] = useState(post);
    const userId = localStorage.getItem('userId');
    const [length,setLength]=useState(0);
    console.log('userId', decryptData(userId))

    const abc = async () => {
        const fetchPosts = await getData({ userId: userId }).unwrap();
        console.log('fetchPosts', fetchPosts.encryptedData);
        const subjects = decryptData(fetchPosts.encryptedData);
        console.log('subjects', subjects)
        setLength(subjects.response.data.length)
        setPosts(subjects.response.data);
    }

    useEffect(() => {
        abc();
    }, [])
    console.log('posts', posts)
    return (
        <div className="w-full mb-12 px-4">
            {isLoading && <CardShimmer />}

            {isSuccess && (

                <div
                    className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
                    style={{
                        display: "flex",
                        flexWrap: "wrap",
                        justifyContent: "space-around",
                    }}

                >
                    <Typography gutterBottom variant="h5" component="div">
                        <div style={{ margin: "10px" }}>Subjects</div>
                    </Typography>
                    {length===0 ?
                        <NoDataFound content={"No Subjects"} /> :
                        <div style={{ display: "flex", justifyContent: "space-between" }}>
                            {posts?.map((data, index) => {
                                return (
                                    <Paper elevation={3} key={index} style={{ height: '100px', width: '100px', display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                        <Link to={"/viewStudentUnderTeacher/" + data}>{data}</Link>
                                    </Paper>
                                );
                            })}
                        </div>
                    }
                </div>
            )}
        </div>
    )
}

export default ListSubjectForTeacher
