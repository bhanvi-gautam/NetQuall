import { React, useState, useEffect } from "react";
import Typography from "@mui/material/Typography";
import TextField from "@mui/material/TextField";
import { useVerifyStudentMutation } from "../rtk/AddSlice";
import CourseDropDown from "./Parts/CourseDropDown";
import { Box, Grid, Button } from "@mui/material";

const MigrationForm = () => {
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [oldCourse, setOldCourse] = useState("");
  const [newCourse, setNewCourse] = useState("");
  const [sendNameAndOldCourse] = useVerifyStudentMutation();

  const handleChange = (value1) => {
    console.log("value1", value1);
    setOldCourse(value1);
  };
  const handleChangeNew = (value) => {
    console.log("value", value);
    setNewCourse(value);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const check = await sendNameAndOldCourse({
      firstName: firstName,
      lastName: lastName,
      oldCourse: oldCourse,
      newCourse: newCourse,
    });
    if (check) {
      alert("exits");
    }
  };
  return (
    // <div className="w-full mb-12 px-4">
    //   <div className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12">
    //     <div style={{ color: "white", width: "100%" }}>
    //       <Typography gutterBottom variant="h3" component="div">
    //         Student Migration Form
    //       </Typography>
    //     </div>
    //   </div>
    //   <form className="flex flex-col space-y-4" onSubmit={handleSubmit}>
    //     <div
    //       style={{
    //         display: "flex",
    //         justifyContent: "space-evenly",
    //         marginTop: "10px",
    //       }}
    //     >
    //       <TextField
    //         sx={{ width: 700 }}
    //         label="Student's First Name"
    //         variant="outlined"
    //         value={firstName}
    //         onChange={(e) => setFirstName(e.target.value)}
    //       />
    //       <TextField
    //         sx={{ width: 700 }}
    //         label="Student's Last Name"
    //         variant="outlined"
    //         value={lastName}
    //         onChange={(e) => setLastName(e.target.value)}
    //       />
    //     </div>

    //     <div>
    //       <CourseDropDown title={"Old Course"} onCourseChange={handleChange} />
    //     </div>
    //     <div>
    //       <CourseDropDown
    //         title={"New Course"}
    //         onCourseChange={handleChangeNew}
    //       />
    //     </div>

    //     <button
    //       type="submit"
    //       className="bg-blue-500 hover:bg-white-700 text-blue font-bold py-2 px-4 rounded"
    //     >
    //       Submit
    //     </button>
    //   </form>
    // </div>

    <Box className="w-full mb-12">
      <Box className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12">
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
          }}
        >
          <Typography gutterBottom variant="h3" component="div">
            Student Migration Form
          </Typography>
        </Box>
      </Box>
      <form
        className="flex flex-col space-y-4"
        onSubmit={handleSubmit}
        style={{
          backgroundColor: "rgb(255 255 255)",
          padding: "16px",
          height: "100vh",
        }}
      >
        {/* <Grid container spacing={1}> */}
        <Grid
          item
          xs={12}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
          }}
        >
          <Typography style={{ marginRight: "20px", fontSize: "20px" }}>
            Student's First Name:{" "}
          </Typography>
          <TextField
            fullWidth
            placeholder="Enter first Name"
            variant="outlined"
            value={firstName}
            onChange={(e) => setFirstName(e.target.value)}
            InputProps={{ style: { borderColor: "#666666", borderWidth: 1 } }}
            style={{ width: "40%", margin: "5px 0" }}
          />
        </Grid>
        <Grid
          item
          xs={12}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
          }}
        >
          <Typography style={{ marginRight: "20px", fontSize: "20px" }}>
            Student's Last Name:{" "}
          </Typography>
          <TextField
            fullWidth
            placeholder="Enter last Name"
            variant="outlined"
            value={lastName}
            onChange={(e) => setLastName(e.target.value)}
            InputProps={{ style: { borderColor: "#666666", borderWidth: 1 } }}
            style={{ width: "40%", margin: "5px 0" }}
          />
        </Grid>
        {/* </Grid> */}
        <Typography
          style={{
            fontSize: "18px",
            marginTop: "21px",
            marginBottom: "0px",
            fontWeight: "bold",
            color: "#919191",
            fontStyle: "italic",
          }}
        >
          Select the Course{" "}
        </Typography>

        <Grid
          item
          xs={12}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
          }}
        >
          <Typography style={{ marginRight: "105px", fontSize: "20px" }}>
            Old Course:
          </Typography>

          <CourseDropDown title={"From"} onCourseChange={handleChange} />
        </Grid>
        <Grid
          item
          md={6}
          xs={12}
          style={{
            display: "flex",
            alignItems: "center",
            justifyContent: "flex-start",
          }}
        >
          <Typography style={{ marginRight: "96px", fontSize: "20px" }}>
            New Course:
          </Typography>
          <CourseDropDown title={"To"} onCourseChange={handleChangeNew} />
        </Grid>

        <Button
          type="submit"
          variant="contained"
          color="primary"
          sx={{ mt: 2, width: "150px" }}
        >
          Submit
        </Button>
      </form>
    </Box>
  );
};

export default MigrationForm;
