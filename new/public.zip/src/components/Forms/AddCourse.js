import React, { useState } from "react";
import RemoveIcon from '@mui/icons-material/Remove';
import AddIcon from '@mui/icons-material/Add';
import { useAddNewPostMutation } from "../rtk/AddSlice";
import { useNavigate } from "react-router-dom";
import { Button, TextField, Grid, IconButton, Typography } from "@mui/material";
import { encryptData,decryptData } from "../../assets/security/encryDecrypt";


const AddCourse = () => {
  let navigate = useNavigate();
  const [formData, setFormData] = useState({ courseName: "", semester: [] });
  const [semesterField, setSemesterField] = useState([
    {
      sem: 0,
      subject: [{ subjectName: "" }],
    },
  ]);
  const [addNewPost] = useAddNewPostMutation();
  const addSemester = () => {
    const newSemesterField = {
      sem: 0,
      subject: [{ subjectName: "" }],
    };
    setSemesterField([...semesterField, newSemesterField]);
  };


  const addSubjects = (index) => {
    const newSubjectField = { subjectName: "" };
    const data = [...semesterField];
    data[index].subject = [...data[index].subject, newSubjectField];
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };

  const removeSubject = (semesterIndex, subjectIndex) => {
    if (subjectIndex > 0) {
      const data = [...semesterField];
      data[semesterIndex].subject.splice(subjectIndex, 1);
      setSemesterField(data);
    }
  };

  const removeSemester = (semesterIndex) => {
    if (semesterIndex > 0) {
      const data = [...semesterField];
      data.splice(semesterIndex, 1);
      setSemesterField(data);
    }
  }


  const handleSemesterChange = (index, e) => {
    let data = [...semesterField];
    data[index][e.target.name] = e.target.value;
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };

  const handleSubjectChange = (index1, index2, e) => {
    let data = [...semesterField];
    data[index1].subject[index2][e.target.name] = e.target.value;
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    const courseName = e.target.elements.courseName.value;
    let encryptedId= localStorage.getItem('userId');
    let id=encryptData(encryptedId)
    const updatedFormData = {
      ...formData,
      courseName,
      "userID": id,
      "user_Id": id,
    };

    const encryptedData=encryptData(updatedFormData);
    await addNewPost({updatedFormData:encryptedData}).unwrap();

    setFormData({ courseName: "", semester: [] });
    setSemesterField([
      {
        sem: 0,
        subject: [{ subjectName: "" }],
      },
    ]);
    navigate('/course');
  };



  return (
    <div className="w-full mb-12 px-4">
    <div className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12">
        <div style={{ color: "white", width: "100%" }}>
            <Typography gutterBottom variant="h3" component="div">
                Add New Course
            </Typography>

        </div>
        <br />
    </div>
      <form  className="flex flex-col space-y-4" onSubmit={handleSubmit}>
      <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                label="Course Name"
                name="courseName"
                variant="standard"
                fullWidth
                required
                onChange={(e) =>
                  setFormData({ ...formData, courseName: e.target.value })
                }
              />
            </Grid>
            {semesterField.map((semester, index1) => (
              <Grid item xs={12} sm={6} key={index1}>
                <TextField
                  label="Semester No"
                  type="number"
                  name="sem"
                  value={semester.sem}
                  onChange={(e) => handleSemesterChange(index1, e)}
                  variant="standard"
                  fullWidth
                  required
                />
                <IconButton color="primary" onClick={() => addSemester()}>
                  <AddIcon />
                </IconButton>
                {semesterField.length > 1 && (
                  <IconButton
                    color="secondary"
                    onClick={() => removeSemester(index1)}
                  >
                    <RemoveIcon />
                  </IconButton>
                )}
                {semester.subject.map((sub, index2) => (
                  <Grid container spacing={2} key={index2}>
                    <Grid item xs={12}>
                      <TextField
                        label="Subject Name"
                        name="subjectName"
                        value={sub.subjectName}
                        onChange={(e) => handleSubjectChange(index1, index2, e)}
                        variant="standard"
                        fullWidth
                        required
                      />
                      <IconButton
                        color="primary"
                        onClick={() => addSubjects(index1)}
                      >
                        <AddIcon />
                      </IconButton>
                      {semester.subject.length > 1 && (
                        <IconButton
                          color="secondary"
                          onClick={() => removeSubject(index1, index2)}
                        >
                          <RemoveIcon />
                        </IconButton>
                      )}
                    </Grid>
                  </Grid>
                ))}
              </Grid>
            ))}
            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
              >
                Submit
              </Button>
            </Grid>
          </Grid>
   
      </form>
    </div>
    


  );
};

export default AddCourse;
