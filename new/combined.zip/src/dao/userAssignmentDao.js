const SuperDao = require('./SuperDao');
const models = require('../models');
const logger = require('../config/logger');

const userAssignment = models.userAssignment;
const userAssignDetails = models.userAssignDetails;
const userSubject = models.userSubject;
const user = models.user;

class UserAssignmentDao extends SuperDao {
    constructor() {
        super(userAssignment);
    }
    async findAssignment(req) {
        try {
            console.log('req34232', req)
            console.log('object', req.status)
            const result = await userAssignment.findAll({

                where: req.status!==-1 ?
                    {
                        status: req.status
                    } : {},
                attributes: ['id', 'assignment', 'deadlineDate', 'deadlineTime', 'status','assign_Id','submission'],
                include: [{
                    model: userAssignDetails,
                    attributes: ['id', 'AssignName'],
                },{
                    model: user,
                    where: req.user_Id ?
                        {
                            id: req.user_Id
                        } : {},
                    attributes: ['id', 'first_name', 'last_name'],
                }, {
                    model: userSubject,
                    where: req.subject ?
                        {
                            subjectName: req.subject
                        } : {},
                    attributes: ['id', 'subjectName']
                },
                ]
            });
            return result;
        } catch (error) {
            logger.error(error);
            throw error;
        }

    }
}
module.exports = UserAssignmentDao;