const SuperDao = require('./SuperDao');
const models = require('../models');
const userAssignment = require('../models/userAssignment');

const User = models.user;
const UserAssignment=models.userAssignment;

class UserDao extends SuperDao {
    constructor() {
        super(User);
    }

    async findByEmail(email) {
        return User.findOne({ where: { email } });
    }

    async isEmailExists(email) {
        return User.count({ where: { email } }).then((count) => {
            if (count != 0) {
                return true;
            }
            return false;
        });
    }

    async createWithTransaction(user, transaction) {
        return User.create(user, { transaction });
    }

    async findUsers(requestWhere){
        // let {where}=requestWhere;
        return User.findAll({
            where:{

            },
            attributes:['id','first_name','last_name','email','address','phone_number','profile','occupation']
        })
        .then((result)=>{
            return result;
        })
        .catch((e)=>{
            // logger.error(e);
            console.log(e);
        });
    } 

    async getStudentSubjectAssign(req){
        console.log('req', req)
        // return
        try {
            const result=await User.findAll({
                where:{
                    course_Id:req.course_Id,
                    role_Id:req.role_Id,
                    is_available:1,
                },
                include:[{
                    model:UserAssignment,
                    attributes:['id', 'assignment', 'deadlineDate', 'deadlineTime', 'status','assign_Id','submission','marks']
                }]
            });
            return result;
        } catch (error) {
            // logger.error(error);
            throw error;
        }
    }


    
}

module.exports = UserDao;
