import { React, useState, useEffect } from 'react'
import Typography from "@mui/material/Typography";
import TextField from '@mui/material/TextField';
import { useVerifyStudentMutation } from '../rtk/AddSlice';
import CourseDropDown from './Parts/CourseDropDown';

const MigrationForm = () => {
    const [firstName, setFirstName] = useState('');
    const [lastName, setLastName] = useState('');
    const [oldCourse, setOldCourse] = useState('');
    const [newCourse, setNewCourse] = useState('');
    const [sendNameAndOldCourse] = useVerifyStudentMutation();

    const handleChange = (value1) => {
        console.log('value1', value1)
        setOldCourse(value1);
    };
    const handleChangeNew = (value) => {
        console.log('value', value)
        setNewCourse(value);
    };


    const handleSubmit = async (e) => {
        e.preventDefault();
        const check = await sendNameAndOldCourse({ firstName: firstName, lastName: lastName, oldCourse: oldCourse, newCourse: newCourse });
        if (check) {
            alert('exits');
        }
    }
    return (
        <div className="w-full mb-12 px-4">
            <div className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12">
                <div style={{ color: "white", width: "100%" }}>
                    <Typography gutterBottom variant="h3" component="div">
                        Student Migration Form
                    </Typography>

                </div>
                <br />
            </div>
            <form className="flex flex-col space-y-4" onSubmit={handleSubmit}>
                <div style={{ display: "flex", justifyContent: "space-evenly", marginTop: '10px', marginLeft: '-105px' }}>
                    <TextField
                        sx={{ width: 700 }}
                        label="Student's First Name"
                        variant="outlined"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                    />
                    <TextField
                        sx={{ width: 700 }}
                        label="Student's Last Name"
                        variant="outlined"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                    />
                </div>

                <div>
                    <CourseDropDown title={'Old Course'} onCourseChange={handleChange} />
                </div>
                <div>
                    <CourseDropDown title={'New Course'} onCourseChange={handleChangeNew} />
                </div>


                <button type="submit" className="bg-blue-500 hover:bg-white-700 text-blue font-bold py-2 px-4 rounded">
                    Submit
                </button>
            </form>
        </div>
    )
}

export default MigrationForm
