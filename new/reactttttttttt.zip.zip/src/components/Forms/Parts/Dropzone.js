// import React, { useState } from 'react';
// import { useDropzone } from 'react-dropzone';
// import { useGetFileIdMutation } from './yourMutationFile';
// const FileUpload = () => {
//   const [uploadedFiles, setUploadedFiles] = useState([]);
//   const { getRootProps, getInputProps } = useDropzone({
//     onDrop: (acceptedFiles) => {
//       setUploadedFiles(acceptedFiles);
//       // Call your backend API endpoint to upload files
//     },
//   });
//   return (
//     <div {...getRootProps()}>
//       <input {...getInputProps()} />
//       <p>Drag and drop files here or click to browse.</p>
//       <ul>
//         {uploadedFiles.map((file) => (
//           <li key={file.name}>{file.name}</li>
//         ))}
//       </ul>
//     </div>
//   );
// };
// export default FileUpload;