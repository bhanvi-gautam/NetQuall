import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useGetStudentForSubjectMutation } from '../rtk/AddSlice'
import { decryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import CardTable4 from '../Cards/CardTable4';
import { Typography } from '@mui/material';
import PdfUploader from './Parts/PdfUploader';

const ListStudentSubjectWise = () => {
  const [getData, { isLoading, isSuccess, post }] = useGetStudentForSubjectMutation();
  const [posts, setPosts] = useState(post);
  const [show, setShow] = useState(false);
  const subject = useParams();

  console.log('subject', subject)

  const abc = async () => {
    const fetchPosts = await getData({ subject }).unwrap();
    console.log('fetchPosts', fetchPosts.encryptedData);
    const students = decryptData(fetchPosts.encryptedData);
    console.log('students', students)
    setPosts(students.response.data);
  }

  useEffect(() => {
    abc();
  }, [])
  console.log('posts', posts)


  return (
    <>
      <div className="w-full mb-12 px-4">
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              alignItems: "center",
              gap: "20px"
            }}
          >
            <div style={{display:"flex", flexDirection:"column"}}>
            <button onClick={() => setShow(!show)}
              style={{
                padding: "10px 20px",
                backgroundColor: "rgb(138,172,208)",
                color: "#fff",
                border: "none",
                borderRadius: "5px",
                cursor: "pointer",
              }}
            >Click to give assignment to students of this subject</button>

            {show &&
              <div>
                {/* <Typography
                style={{
                  fontSize: "20px", // increase the font size
                  fontWeight: "bold", // make the text bold
                }}
              >Send Assignment</Typography> */}
                <div><PdfUploader subject={subject.subject}/></div>
              </div>
            }
</div>
            <CardTable4
              title={"Students under " + subject.subject}
              content={posts}
              heading={[
                "Profile",
                "Student Name",
                "Email",
                "Assignment uploaded by Student",
                "Accept/Unaccepted"
              ]}
              roleId={3}
              
              errorMessg={"No Student available"}
            />
          </div>
        )}
      </div>
    </>
  )
}

export default ListStudentSubjectWise
