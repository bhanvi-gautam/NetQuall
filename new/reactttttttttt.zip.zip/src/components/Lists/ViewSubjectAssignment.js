import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import { useGetAssignmentMutation } from '../rtk/AddSlice';
import { decryptData } from '../../assets/security/encryDecrypt';
import CardTable6 from '../Cards/CardTable6.js';
import CardShimmer from '../Effects/CardShimmer';

const ViewSubjectAssignment = () => {
    const subject=useParams();
    const [getData, { isLoading, isSuccess, post }] = useGetAssignmentMutation();
    const [posts, setPosts] = useState(post);
    const abc = async () => {
      const fetchPosts = await getData({status:0,subject:subject.subject}).unwrap();
      const temp = decryptData(fetchPosts.encryptedData);
      // console.log('fetchPosts', temp)
      setPosts(temp);
    };
    console.log('posts', posts)
  
    useEffect(() => {
      abc();
    }, []);
  
  return (
    <>
      <div className="w-full mb-12 px-4">
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <CardTable6
              title={"Assignments Given"}
              content={posts}
              heading={[
                "Assignment",
                "Subject",
                "Deadline Date",
                "Deadline Time",
                "Status",
                ""
              ]}
              roleId={2}
              errorMessg={"No Assignments available"}
            />
          </div>
        )}
      </div>
    </>
  )
}

export default ViewSubjectAssignment
