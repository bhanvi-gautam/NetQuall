import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useGetUserSubjectMutation } from "../rtk/AddSlice";
import {decryptData,encryptData} from "../../assets/security/encryDecrypt";
import CardTable2 from "../Cards/CardTable2";
import CardShimmer from "../Effects/CardShimmer";

const ListTeachers = () => {
  const { courseId } = useParams();
  const [getdata, { isLoading, isSuccess, post }] = useGetUserSubjectMutation();
  const [posts, setPosts] = useState(post);
  
  // const courseId = decryptData(course_Id);

  const abc = async () => {
    const payload={ roleId:'2'}
    // const encryptedData=encryptData(payload);
    const fetchPosts = await getdata(payload).unwrap();
    // const temp = decryptData(fetchPosts.data);
console.log('fetchPosts', fetchPosts)
    // setPosts(temp);
    setPosts(fetchPosts);
  };

  useEffect(() => {
    abc();
  }, []);
console.log("posts===",posts?.data)
  return (
    <>
      <div className="w-full mb-12 px-4">
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <CardTable2
              title={"List of Faculty Members"}
              content={posts?.data}
              heading={[
                "Profile",
                "Faculty Name",
                "Email",
                "Subject",
                "Semester No",
                "Course",
                "Delete",
                "Accept/Unaccepted",
                "View More"
              ]}
              roleId={2}
              errorMessg={"No Faculty available"}
            />
          </div>
        )}
      </div>
    </>
  );
};

export default ListTeachers;
