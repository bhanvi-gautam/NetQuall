import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import NoDataFound from "./NoDataFound";
import { encryptData } from '../../assets/security/encryDecrypt';

export default function CardTable5({
    title,
    content,
    heading,
    roleId,
    errorMessg

}) {

    let flag = 0;
    console.log('content', content)

    // const downloadFile = () => {
    //     // text content
    //     const texts = ["line 1", "line 2", "line 3"]
    
    //    // file object
    //     const file = new Blob(texts, {type: 'text/plain'});
    
    //    // anchor link
    //     const element = document.createElement("a");
    //     element.href = URL.createObjectURL(file);
    //     element.download = "100ideas-" + Date.now() + ".txt";
    
    //     // simulate link click
    //     document.body.appendChild(element); // Required for this to work in FireFox
    //     element.click();
    // }

    return (
        <>
            <div
                className={
                    "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded " +
                    "bg-white"
                }
            >
                <div className="rounded-t mb-0 px-4 py-3 border-0">
                    <div className="flex flex-wrap items-center">
                        <div className="relative w-full px-4 max-w-full flex-grow flex-1">
                            <h3 className={"font-semibold text-lg text-blueGray-700"}>
                                {title}
                            </h3>
                        </div>
                    </div>
                </div>
                <div className="block w-full overflow-x-auto">
                    {/* Projects table */}
                    <table className="items-center w-full bg-transparent border-collapse">
                        <thead>
                            <tr>
                                {heading?.map((data) => (
                                    <th
                                        className={
                                            "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                                        }
                                    >
                                        {data}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {content?.map((data, index) => {
                                flag++;
                                return (
                                    <tr key={index}>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                           {index+1}.
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {/* <button >{data.assignment}</button> */}
                                            <Link to={`http://localhost:3003/download/${data.assignment}`}>{data.assignment}</Link>
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.userSubject.subjectName}

                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {new Date(data.deadlineDate).toISOString().split('T')[0]}
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.deadlineTime}
                                        </td>

                                    </tr>
                                )

                            })}

                        </tbody>
                    </table>

                    {flag === 0 && <NoDataFound content={errorMessg} />}
                </div>
            </div>
        </>
    );
}