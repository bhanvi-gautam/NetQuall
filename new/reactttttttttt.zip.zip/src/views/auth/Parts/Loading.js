import React from 'react'
import loading from '../../../assets/img/loading.gif'

const Loading = () => {
  return (
    <div style={{display:'flex', justifyContent:'center', alignItems:'center', height:'100vh'}}>
       <img src={loading}  />
    </div>
  )
}

export default Loading
