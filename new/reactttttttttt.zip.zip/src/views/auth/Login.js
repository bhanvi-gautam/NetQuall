import React, { useEffect, useState } from "react";
import { useLoginMutation } from "../../components/rtk/AddSlice";
import { Link, useNavigate } from "react-router-dom";
import backgroundImage from "../../assets/img/register_bg_2.png";
import { encryptData } from "../../assets/security/encryDecrypt";
import Loading from './Parts/Loading'

const Login = () => {
  const [loading, setLoading] = useState(false);
  const [sendData, { isLoading, isSuccess, post }] = useLoginMutation();
  const [posts, setPosts] = useState(post)
  const [token, setToken] = useState('');

  const navigate = useNavigate();
  // let key;
  // let id;
  // let roleId;
  console.log(posts);


  useEffect(() => {
    // console.log("posts1===", posts);
    // if (posts && (posts.status === "rejected" || posts.status===false)) {
    //   window.alert(posts.error);
    // }
  }, [post]);


  const handleSubmit = async (e) => {
    e.preventDefault();
    // try {
    let email = e.target.elements.email.value;
    let password = e.target.elements.password.value;
    const data = { email, password };
    const encryptedData = encryptData(data);
    await sendData({ data: encryptedData })
      .then((data) => {
        setToken(data.data.tokens.access.token)
        localStorage.setItem("token", data.data.tokens.access.token);

        const encryptedId = encryptData(data.data.data.id);
        localStorage.setItem("userId", encryptedId);
        localStorage.setItem("roleId", data.data.data.role_Id);
        setLoading(true);
        console.log('data', data.data)
        navigate("/dashboard");

      })
      .catch((error) => {
        window.alert('Invalid Email Address');
      })
  };

  // useEffect(() => {
  //   // // setTimeout(() => {
  //   // if (token) {
  //   //   console.log('token', token)
  //   //   navigate("/dashboard");
  //   // }
  //   // // }, 3000);

  // }, [token]);


  const myStyle = {
    backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.01), rgba(0, 0, 0, 0.3)), url(${backgroundImage})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    height: "100vh", // This will cover the full height of the viewport
    width: "100vw",
  };


  // console.log('loginData', loginData)
  console.log('isLoading', isLoading)
  console.log('isSuccess', isSuccess)
  return (
    <>
      {loading ? <Loading /> :
        <div className="container mx-auto px-4 h-full" style={myStyle}>
          <div className="flex content-center items-center justify-center h-full">
            <div className="w-full lg:w-4/12 px-4">
              <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0">
                <div className="rounded-t mb-0 px-6 py-6">
                  <div className="text-center mb-3">
                    <h6 className="text-blueGray-700 text-lg font-bold">
                      Sign in with
                    </h6>
                  </div>

                </div>
                <div className="flex-auto px-4 lg:px-10 py-10 pt-0">

                  <form onSubmit={handleSubmit}>
                    <div className="relative w-full mb-3">
                      <label
                        className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                        htmlFor="grid-password"
                      >
                        Email
                      </label>
                      <input
                        type="email"
                        name="email"
                        className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        placeholder="Email"
                      />
                    </div>

                    <div className="relative w-full mb-3">
                      <label
                        className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                        htmlFor="grid-password"
                      >
                        Password
                      </label>
                      <input
                        type="password"
                        name="password"
                        className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                        placeholder="Password"
                      />
                    </div>

                    <div className="text-center mt-6">
                      <button
                        className="bg-blueGray-800 text-white active:bg-blueGray-600 text-sm font-bold uppercase px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 w-full ease-linear transition-all duration-150"
                        type="submit"
                      >
                        Sign In
                      </button>
                    </div>
                  </form>
                </div>
              </div>
              <div className="flex flex-wrap mt-6 relative">
                <div className="w-1/2">
                  <Link to="/forgotPassword" className="text-blueGray-200">
                    <small>Forgot password?</small>
                  </Link>
                </div>
                <div className="w-1/2 text-right">
                  <Link to="/register" className="text-blueGray-200">
                    <small>Create new account</small>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      }
    </>
  );
};

export default Login;