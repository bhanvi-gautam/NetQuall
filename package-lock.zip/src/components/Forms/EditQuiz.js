import { Box, Button, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import { useGetOneQuizMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import PostDetailsShimmer from '../Effects/PostDetailsShimmer';


const EditQuiz = () => {
  const quizId = useParams();
  const [getData, { isLoading, isSuccess, post }] = useGetOneQuizMutation();
  const [posts, setPosts] = useState(post);
  const [quiz, setQuiz] = useState(post);
  const getQuiz = async () => {
    const encryptedId = encryptData(quizId);
    await getData({ id: encryptedId }).then((data) => {
      console.log('data', data.data.encryptedData)
      const temp = decryptData(data.data.encryptedData);
      setPosts(temp);

    })
  }
  console.log('posts', posts)
  useEffect(() => {
    getQuiz();
  }, []);

  // Handle Option Change
  const handleOptionChange = (qIndex, oIndex) => {
    const newPosts = { ...posts };
    const selectedOption = newPosts?.quizQuestions[qIndex]?.quizOptions[oIndex];
    newPosts?.quizQuestions[qIndex]?.quizOptions?.forEach((option) => {
      option.is_correct = false;
    });
    selectedOption.is_correct = true;
    setPosts(newPosts);
  };

  const handleQuizNameChange = (e) => {
    const temp = e.target.value;
    if (temp !== '') {
      setQuiz({ ...quiz, quizName: temp });
    } else {
      setQuiz({ ...quiz, quizName: posts.quizName });
    }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Validate inputs
    const hasEmptyInputs = posts.quizQuestions.some(
      (question) =>
        !question.question ||
        question.quizOptions.some((option) => !option.option_text)
    );
    const hasCorrectAnswer = posts.quizQuestions.some((question) =>
      question.quizOptions.some((option) => option.is_correct)
    );

    if (hasEmptyInputs) {
      alert('Please fill in all fields.');
    } else if (!hasCorrectAnswer) {
      alert('Please select at least one correct answer.');
    } else {
      // Save the edited quiz (you can replace this with your backend logic)
      console.log('Edited quiz:', posts);
    }
  };

  return (
    <Box className="w-full mb-12">
      <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
          }}
        >
          <Typography gutterBottom variant="h4" component="div">Edit Quiz</Typography>
        </Box>
      </Box>
      {isLoading && <PostDetailsShimmer />}
      {isSuccess &&
        <div className="flex-auto px-4 lg:px-10 py-10 pt-10">
          <form onSubmit={handleSubmit}>
            <div className="flex flex-wrap">
              <div className="w-full lg:w-12 px-4">
                <div className="relative w-full mb-3">
                  <label
                    className="block uppercase text-blueGray-600 text-s font-bold mb-2or SAP Deployment activities."
                  >
                    Quiz Name:
                  </label>
                  <input type="text" defaultValue={posts?.quizName} onChange={handleQuizNameChange} className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    required />

                </div>
              </div>
            </div>
            {posts?.quizQuestions?.map((question, qIndex) => (
              <div className="flex flex-wrap" key={qIndex}>
                <div className="w-full lg:w-12 px-4">
                  <div className="relative w-full mb-3">
                    <label className="block uppercase text-blueGray-600 text-s font-bold mb-2">
                      Question {qIndex + 1}:
                      <input type="text" defaultValue={question.question} className="border-0 px-3 py-3 mt-1 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                    </label>
                    {question?.quizOptions?.map((option, oIndex) => (
                      <div style={{ display: 'flex',alignItems:"center" }} key={oIndex}>
                       
                        <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                          Option {oIndex + 1}:
                          <input type="text" defaultValue={option.option_text} className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                        </label>
                        <input
                          type={question.question_type ? "checkbox" : "radio"}
                          name={question.question_type ? `option_${qIndex}` : `option_${qIndex}_${oIndex}`}
                          defaultValue={option.id}
                          checked={option.is_correct}
                          onChange={()=>handleOptionChange(qIndex,oIndex)}
                          style={{marginLeft:"20px"}}
                        />
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            ))}
            <Button type="submit" >Submit Quiz</Button>
          </form>
        </div>}
    </Box>

  );
};

export default EditQuiz;

