import { Box, Button, Grid, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'

const AddAnnouncement = () => {
    const [formData,setFormData]=useState();
    const handleSubmit=()=>{

    }
  return (
    <Box className="w-full mb-12">
    <Box className= "relative md:pt-30 pb-32 pt-12"  style={{backgroundColor:'#0099CC'}}>
      <Box
        className="px-4"
        sx={{
          color: "white",
          width: "100%",
          position: "absolute",
          bottom: 0,
        }}
      >
        <Typography gutterBottom variant="h4" component="div">
          Add New Announcement
        </Typography>

      </Box>
    </Box>
    <form className="flex flex-col space-y-4" onSubmit={handleSubmit} style={{
      backgroundColor: "rgb(255 255 255)",
      padding: "16px",
      height: "100vh",
    }}>
      <Grid container spacing={2}>
        <Grid item xs={12}>
          <Typography variant="h6">Heading:</Typography>
          <TextField
            type="text"
            name="courseName"
            required
            size={"small"}
            onChange={(e) =>
              setFormData({ ...formData, heading: e.target.value })
            }
          />
        </Grid>
        
        <Grid item xs={12}>
          <Button
            type="submit"
            variant="contained"
            color="primary"
            sx={{ mt: 2, width: "150px" }}
          >
            Submit
          </Button>
        </Grid>
      </Grid>

    </form>
  </Box>
  )
}

export default AddAnnouncement
