import { createEntityAdapter } from "@reduxjs/toolkit";
import { apiSlice } from "./app/api";
const postsAdapter = createEntityAdapter();
const userToken=localStorage.getItem('token');

const initialState = postsAdapter.getInitialState()

export const extendedApiSlice = apiSlice.injectEndpoints({
    endpoints: builder => ({

        login: builder.mutation({

            query: credentials => ({
                url: '/auth/login',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: { ...credentials }
            }),
            transformErrorResponse: response => {
                response = 'Invalid Credentials'
                return response;
            },
            providesTags: (result, error, arg) => [
                { type: 'User', id: "LIST" },
                ...result.ids.map(id => ({ type: 'User', id }))
            ],


        }),

        register: builder.mutation({
            query: (credentials) => ({
                url: '/user/register',
                method: 'POST',

                body: credentials
            }),

        }),


        createQuiz: builder.mutation({
            query: (credentials) => ({
                url: '/quiz/create-quiz',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: credentials
            }),

        }),

        getQuiz: builder.mutation({
            query: (credentials) => ({
                url: '/quiz/get-quiz',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: credentials
            }), 
            transformResponse: responseData => {
                // const responseData1=decryptData(responseData);
                return responseData;
            },

        }),

        quizLive: builder.mutation({
            query: (credentials) => ({
                url: '/quiz/live-quiz',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: credentials
            }), 
            transformResponse: responseData => {
                // const responseData1=decryptData(responseData);
                return responseData;
            },

        }),

        addAssignment: builder.mutation({
            query: (credentials) => ({
                url: '/user/add-assignment',
                method: 'POST',

                body: credentials
            }),

        }),

        checkSubmission: builder.mutation({
            query: requestData => ({
                url: '/user/check-submission',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData
            }),
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        getMarks: builder.mutation({
            query: requestData => ({
                url: '/user/get-marks',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData
            }),
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        getCourseCount: builder.mutation({
            query: requestData => ({
                url: '/lms/get-course-count',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData
            }),

            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        getTeacherSubject: builder.mutation({
            query: requestData => ({
                url: '/lms/get-teacher-subject',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData
            }),

            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        getUserCount: builder.mutation({
            query: requestData => ({
                url: '/user/get-user-count',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData
            }),

            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        getUserSubject: builder.mutation({
            query: (requestData) => ({
                url: '/lms/get-user-course-subject',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData,
            }),
            transformResponse: responseData => {
                // const responseData1=decryptData(responseData);
                return responseData;
            },
            providesTags: (result, error, arg) => [
                { type: 'User', id: "LIST" },
                ...result.ids.map(id => ({ type: 'User', id }))
            ],

        }),

        getStudentForSubject: builder.mutation({
            query: (requestData) => ({
                url: '/lms/get-student-subject',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData,
            }),
            transformResponse: responseData => {
                // const responseData1=decryptData(responseData);
                return responseData;
            },
            providesTags: (result, error, arg) => [
                { type: 'User', id: "LIST" },
                ...result.ids.map(id => ({ type: 'User', id }))
            ],

        }),

        getStudentSubjectAssign: builder.mutation({
            query: (requestData) => ({
                url: '/lms/get-student-subject-assign',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData,
            }),
            transformResponse: responseData => {
                // const responseData1=decryptData(responseData);
                return responseData;
            },
            providesTags: (result, error, arg) => [
                { type: 'User', id: "LIST" },
                ...result.ids.map(id => ({ type: 'User', id }))
            ],

        }),

        getStudentAssignDetails: builder.mutation({
            query: (requestData) => ({
                url: '/lms/get-student-assign-details',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData,
            }),
            transformResponse: responseData => {
                // const responseData1=decryptData(responseData);
                return responseData;
            },
            providesTags: (result, error, arg) => [
                { type: 'User', id: "LIST" },
                ...result.ids.map(id => ({ type: 'User', id }))
            ],

        }),

        // getFilteredUsers: builder.mutation({
        //     query: (requestData) => ({
        //         url: '/user/viewFilteredDetails',
        //         headers: {
        //             'Content-Type': 'application/json',
        //             'Authorization': `Bearer ${userToken}`
        //         },
        //         method: 'POST',
        //         body:  requestData ,
        //     }),
        //     transformResponse: responseData => {
        //         // const responseData1=decryptData(responseData);
        //         return responseData;
        //     },
        //     providesTags: (result, error, arg) => [
        //         { type: 'User', id: "LIST" },
        //         ...result.ids.map(id => ({ type: 'User', id }))
        //     ],

        // }),

        verifyStudent: builder.mutation({
            query: (requestData) => ({
                url: '/user/student-exists',
                method: 'POST',
                body: requestData,
            })
        }),

        verifyEmail: builder.mutation({
            query: (requestData) => ({
                url: '/auth/email-exists',
                method: 'POST',
                body: { email: requestData },
            })
        }),

        verifyPassword: builder.mutation({
            query: (requestData) => ({
                url: '/auth/password-exists',
                method: 'POST',
                body: requestData,
            })
        }),

        verifyOTP: builder.mutation({
            query: (requestData) => ({
                url: '/auth/verify',
                method: 'POST',
                body: requestData,
            })
        }),

        changePassword: builder.mutation({
            query: (requestData) => ({
                url: '/auth/new-password',
                method: 'POST',
                body: requestData,
            })
        }),

        clearOTP: builder.mutation({
            query: (requestData) => ({
                url: '/auth/clear-otp',
                method: 'POST',
                body: requestData,
            })
        }),

        getOnePost: builder.mutation({
            query: (requestData) => ({
                url: '/lms/getonepost',

                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: requestData,
            }),
            transformResponse: responseData => {
                // console.log("response==", responseData)
                return responseData;
            },
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],

        }),

        getOneQuiz: builder.mutation({
            query: (requestData) => ({
                url: '/quiz/get-one-quiz',

                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: requestData,
            }),
            transformResponse: responseData => {
                // console.log("response==", responseData)
                return responseData;
            },
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],

        }),

        getStudentQuiz: builder.mutation({
            query: (requestData) => ({
                url: '/quiz/get-student-quiz',

                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: requestData,
            }),
            transformResponse: responseData => {
                // console.log("response==", responseData)
                return responseData;
            },
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],

        }),

        migrateUser: builder.mutation({
            query: (requestData) => ({
                url: '/user/migrate-user',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: JSON.stringify({ requestData }),
            }),

            providesTags: (result, error, arg) => [
                { type: 'User', id: "LIST" },
                ...result.ids.map(id => ({ type: 'User', id }))
            ],

        }),

        getOneUser: builder.mutation({
            query: (requestData) => ({
                url: '/user/getUser',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: JSON.stringify({ requestData }),
            }),
            transformResponse: responseData => {
                // console.log("response==", responseData)
                return responseData;
            },
            providesTags: (result, error, arg) => [
                { type: 'User', id: "LIST" },
                ...result.ids.map(id => ({ type: 'User', id }))
            ],

        }),

        getPosts: builder.mutation({
            query: requestData => ({
                url: '/lms/get-course',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData
            }),
            transformResponse: responseData => {
                // console.log("responseforgetAll==", responseData)
                return responseData;
            },
            onError: (error) => {
                // console.error("Error from useGetPostsMutation:", error);
            },
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        getStudentAssignSubmissionDetails: builder.mutation({
            query: requestData => ({
                url: '/lms/get-submitted-assignment',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData  
            }),
            transformResponse: responseData => {
                // console.log("responseforgetAll==", responseData)
                return responseData;
            },
            onError: (error) => {
                // console.error("Error from useGetPostsMutation:", error);
            },
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        getAssignment: builder.mutation({
            query: requestData => ({
                url: '/user/get-assignment',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData  
            }),
            transformResponse: responseData => {
                // console.log("responseforgetAll==", responseData)
                return responseData;
            },
            onError: (error) => {
                // console.error("Error from useGetPostsMutation:", error);
            },
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        getSubjects: builder.mutation({
            query: requestData => ({
                url: '/lms/get-subject',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData
            }),
            providesTags: (result, error, arg) => [
                { type: 'Post', id: "LIST" },
                ...result.ids.map(id => ({ type: 'Post', id }))
            ],
        }),

        addNewPost: builder.mutation({
            query: initialPost => ({
                url: '/lms/create-course',
                method: 'POST',

                body: {
                    ...initialPost,

                }
            }),
            invalidatesTags: ['Post'],
        }),

        updatePost: builder.mutation({
            query: (requestData) => ({
                url: '/lms/update-course',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: requestData,
            }),
            transformResponse: responseData => {
                // console.log('responseData', responseData);
            },
            invalidatesTags: ['Post']


        }),

        uploadImage: builder.mutation({

            query: (requestData) => ({

                url: '/user/upload',
                method: 'POST',
                headers: {
                    "Extension":requestData.y,
                    "Content-Range": requestData.z,

                },
                body:requestData.x,
            }),
            transformResponse: responseData => {
                console.log('responseData', responseData);
                return responseData;
            },
            invalidatesTags: ['User'],

        }),

        uploadPdf: builder.mutation({

            query: (requestData) => ({

                url: '/user/upload',
                method: 'POST',
                headers: {
                    'X-File-Id': requestData.y,
                    "Content-Range": requestData.z,

                },
                body: requestData.x,
            }),
            transformResponse: responseData => {
                // console.log('responseData', responseData);
            },
            invalidatesTags: ['User'],

        }),

        getFileId: builder.mutation({
            query: (requestData) => ({
                url: '/user/requestFile',
                method: 'POST',
                // headers: {
                //     'Content-Type': 'application/json',
                //     'Authorization': `Bearer ${userToken}`
                // },
                body: { fileName: requestData },
            }),
            transformResponse: responseData => {
                // console.log("response==", responseData)
                return responseData;
            }
        }),

        getCourseId: builder.mutation({
            query: (requestData) => ({
                url: '/user/course-id',
                method: 'POST',
                // headers: {
                //     'Content-Type': 'application/json',
                //     'Authorization': `Bearer ${userToken}`
                // },
                body: requestData,
            }),
            transformResponse: responseData => {
                // console.log("response==", responseData)
                return responseData;
            }
        }),

        updateUser: builder.mutation({
            query: (requestData) => ({
                url: '/user/update-user',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: requestData,
            }),
            transformResponse: responseData => {
                // console.log('responseData', responseData);
            },
            invalidatesTags: ['User'],

        }),

        enableDisableUser: builder.mutation({
            query: (requestData) => ({
                url: '/user/enable-disable-user',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: { id: requestData },
            }),
            transformResponse: responseData => {
                // console.log('responseData', responseData);
            },
            invalidatesTags: ['User'],

        }),

        submission: builder.mutation({
            query: (requestData) => ({
                url: '/user/submission',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: { id: requestData },
            }),
            transformResponse: responseData => {
                // console.log('responseData', responseData);
            },
            invalidatesTags: ['User'],

        }),

        updateSubject: builder.mutation({
            query: (requestData) => ({
                url: '/lms/update-subject',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: requestData,
            }),
            transformResponse: responseData => {
                // console.log('responseData', responseData);
            }
        }),

        updateCourse: builder.mutation({
            query: (requestData) => ({
                url: '/lms/update-course',
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                body: requestData,
            }),
            transformResponse: responseData => {
                return responseData;
                // console.log('responseData', responseData);
            }
        }),

        deletePost: builder.mutation({
            query: (requestData) => ({
                url: '/lms/delete',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData,
            }),
        }),

        deleteUser: builder.mutation({
            query: (requestData) => ({
                url: '/user/deleteUser',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData,
            }),
            // providesTags: (result, error, arg) => [
            //     { type: 'User', id: "LIST" },
            //     ...result.ids.map(id => ({ type: 'User', id }))
            // ],

        }),

        deleteQuiz: builder.mutation({
            query: (requestData) => ({
                url: '/quiz/delete-quiz',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData,
            }),

        }),

        deleteProfile: builder.mutation({
            query: (requestData) => ({
                url: '/user/deleteProfile',
                headers: {
                    'Content-Type': 'application/json',
                    'Authorization': `Bearer ${userToken}`
                },
                method: 'POST',
                body: requestData,
            }),
            // providesTags: (result, error, arg) => [
            //     { type: 'User', id: "LIST" },
            //     ...result.ids.map(id => ({ type: 'User', id }))
            // ],

        }),

    })
})

export const {
    useGetOnePostMutation,
    useDeletePostMutation,
    useUpdateSubjectMutation,
    useGetPostsMutation,
    useAddNewPostMutation,
    useUpdatePostMutation,
    useLoginMutation,
    useRegisterMutation,
    useGetUsersMutation,
    useDeleteUserMutation,
    useGetOneUserMutation,
    useUpdateUserMutation,
    useGetFileIdMutation,
    useUploadImageMutation,
    useDeleteProfileMutation,
    useVerifyEmailMutation,
    useVerifyOTPMutation,
    useChangePasswordMutation,
    useClearOTPMutation,
    useVerifyPasswordMutation,
    useEnableDisableUserMutation,
    useGetStudentAssignSubmissionDetailsMutation,
    useGetUserSubjectMutation,
    useMigrateUserMutation,
    useVerifyStudentMutation,
    useGetCourseCountMutation,
    useGetUserCountMutation,
    useGetSubjectsMutation,
    useGetTeacherSubjectMutation,
    useGetStudentForSubjectMutation,
    useAddAssignmentMutation,
    useUploadPdfMutation,
    useGetAssignmentMutation,
    useGetCourseIdMutation,
    useCheckSubmissionMutation,
    useGetStudentSubjectAssignMutation,
    useSubmissionMutation,
    useGetMarksMutation,
    useGetStudentAssignDetailsMutation,
    useUpdateCourseMutation,
    useCreateQuizMutation,
    useGetQuizMutation,
    useQuizLiveMutation,
    useDeleteQuizMutation,
    useGetOneQuizMutation,
    useGetStudentQuizMutation
} = extendedApiSlice