import React from "react";
import PropTypes from "prop-types";
import NoDataFound from "./NoDataFound";
import dummyProfile from "../../assets/img/dummyProfile.png";

export default function CardTable({
  content,
  attribute,
  heading,
  courseId,
  role,
  errorMessg,
}) {
  let flag = 0;
  console.log('content', content)
  return (
    <>
      <div
        className={
          "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded " +
          "bg-white"
        }
      >
        <div className="block w-full overflow-x-auto">
          {/* Projects table */}
          <table className="items-center w-full bg-transparent border-collapse">
             <thead>
              <tr>
                {heading?.map((data) => (
                  <th
                    className={
                      "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                    }
                  >
                    {data}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {content?.map((data1, index1) => {

                const userSemester = data1?.userSemesters;
                console.log('userSemester', userSemester)
                return (
                  <React.Fragment key={index1}>
                    {data1.users.map((data, index) => {
                     
                      if (data.is_available === 1) {
                        flag++;

                        return (
                          <tr key={index}>
                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                              {data.profile ? (
                                <img
                                  src={`http://localhost:3003/images/${data.profile}`}
                                  width="100"
                                  height="100"
                                />
                              ) : (
                                <img src={dummyProfile} width="100" height="100" />
                              )}
                            </td>
                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                              {data.first_name + " " + data.last_name}
                            </td>
                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                              {data.email}
                            </td>

                            {/* <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {user.teachers.length > 0 ? user.teachers.map((sub) => {
                        const id = sub.userSubject.semester_Id;
                        // console.log('id', id)
                        return (
                          userSemester.map((sem) => {
                            if (sem.id === id) {
                              return <tr key={sem.id}>{sem.semesterNo}</tr>
                            }
                          }))
                      }) : 'Not yet'}
                    </td> */}

                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                              <tr>
                                {data.teachers && data.teachers.length > 0 ? data.teachers.map((sub, index1) => {
                                  return <td key={index1}>{sub.userSubject.subjectName}</td>
                                }) : <td>No Subject</td>}
                              </tr>
                            </td>
                            <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">

                              {data.teachers && data.teachers.length > 0 ? data.teachers.map((sub) => {
                                const id = sub.userSubject.semester_Id;
                                return (
                                  userSemester?.map((sem) => {
                                    if (sem.id === id) {
                                      return <tr key={sem.id}>{sem.semesterNo}</tr>
                                    }
                                  })
                                )
                              }) : <td>No Subject</td>}

                            </td>
                          </tr>
                        );
                      }
                    })}

                  </React.Fragment>
                )
              })}
            </tbody>
          </table>

          {flag === 0 && <NoDataFound content={errorMessg} />}
        </div>
      </div>
    </>
  );
}

// CardTable.defaultProps = {
//   color: "light",
// };

// CardTable.propTypes = {
//   color: PropTypes.oneOf(["light", "dark"]),
// };
