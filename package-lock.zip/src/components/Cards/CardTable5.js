import React, { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import NoDataFound from "./NoDataFound";
import { encryptData } from '../../assets/security/encryDecrypt';

export default function CardTable5({
    title,
    content,
    heading,
    roleId,
    errorMessg

}) {

    let flag = 0;
    console.log('content', content)

    // const downloadFile = () => {
    //     // text content
    //     const texts = ["line 1", "line 2", "line 3"]

    //    // file object
    //     const file = new Blob(texts, {type: 'text/plain'});

    //    // anchor link
    //     const element = document.createElement("a");
    //     element.href = URL.createObjectURL(file);
    //     element.download = "100ideas-" + Date.now() + ".txt";

    //     // simulate link click
    //     document.body.appendChild(element); // Required for this to work in FireFox
    //     element.click();
    // }

    return (
        <>

            <div className="block w-full overflow-x-auto">

                
                {/* Projects table */}
                <table className="items-center w-full bg-transparent border-collapse">
                    <thead>
                        <tr>
                            {heading?.map((data) => (
                                <th
                                    className={
                                        "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                                    }
                                >
                                    {data}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {content?.map((data, index) => {
                            flag++;
                            return (
                                <tr key={index}>
                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        {index + 1}.
                                    </td>
                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4" style={{color:'blue'}}>
                                        {/* <button >{data.assignment}</button> */}
                                        <Link to={`http://localhost:3003/download/${data.assignment}`}>{data.userAssignDetail.AssignName}</Link>
                                    </td>
                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        {data.userSubject.subjectName}

                                    </td>
                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        {new Date(data.deadlineDate).toISOString().split('T')[0]}
                                    </td>
                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        {data.deadlineTime}
                                    </td>

                                </tr>
                            )

                        })}

                    </tbody>
                </table>

                {flag === 0 && <NoDataFound content={errorMessg} />}
            </div>

        </>
    );
}