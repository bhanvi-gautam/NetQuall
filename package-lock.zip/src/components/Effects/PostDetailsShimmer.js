import React from 'react'
import { ShimmerPostDetails } from "react-shimmer-effects";

const PostDetailsShimmer = () => {
  return (
    <div>
      <ShimmerPostDetails card cta variant="SIMPLE" />
      <ShimmerPostDetails card cta variant="EDITOR" />
    </div>
  )
}

export default PostDetailsShimmer
