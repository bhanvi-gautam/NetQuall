import { ShimmerTable } from "react-shimmer-effects";
import React from 'react'

const LmsShimmer = ({row,col}) => {

    return <ShimmerTable row={row} col={col} />;
}

export default LmsShimmer
