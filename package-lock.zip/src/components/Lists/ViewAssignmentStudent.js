import React, { useState, useEffect } from 'react'
import { useGetOnePostMutation, useGetCourseIdMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import { Link } from 'react-router-dom';
import NoDataFound from '../Cards/NoDataFound';
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import {
    Paper,
    Typography,
    Card,
    CardContent,
    CardActions,
    IconButton,
    Alert,
    Stack,
} from "@mui/material";


const ViewAssignmentStudent = () => {
    const userId = localStorage.getItem('userId');
    const [getCourseId] = useGetCourseIdMutation();
    const [getData, { isLoading, isSuccess }] = useGetOnePostMutation();
    const [info, setInfo] = useState(null);

    console.log('userId', userId)

    const abc = async () => {
        const fetch = await getCourseId({ userId }).unwrap();
        const decryptedData = decryptData(fetch.data);
        const encryptedId = encryptData({ decryptedData });
        const fetchPt = await getData({ courseId: encryptedId }).unwrap();
        const fetchPosts = decryptData(fetchPt.data);
        console.log("hie--", fetchPosts.userSemesters);
        setInfo(fetchPosts.userSemesters);
    }
    let flag = 0;
    useEffect(() => {
        abc();
    }, [])
    return (
        <div className="w-full mb-12">
            {isLoading && <CardShimmer />}

            {isSuccess && (
                <>
                    <div
                        className="relative md:pt-30 pb-32 pt-12"
                        style={{
                            display: "flex",
                            flexWrap: "wrap",
                            justifyContent: "space-around",
                            position: "relative", // Ensure positioning context for absolute positioning
                            backgroundColor: '#0099CC'
                        }}
                    >
                        <Typography gutterBottom
                            variant="h4"
                            component="div"
                            color={"white"}
                            style={{
                                position: "absolute",
                                bottom: 0,
                                left: 15,
                            }}>
                            Your Academic Journey Starts Here!
                        </Typography>
                    </div>
                    <div
                        className="relative md:pt-30 pb-32 pt-12"
                        style={{
                            display: "flex",
                            flexWrap: "wrap",
                            justifyContent: "flex-start",
                            alignItems: "flex-start",
                            padding: "0 20px",
                            backgroundColor: 'white'
                        }}
                    >
                        <Stack sx={{ width: '100%' }} spacing={2}>
                            <Alert severity="info" style={{ margin: '10px' }}>
                                This page is your gateway to academic success! Here, you can easily view all the subjects you're enrolled in. Want to see your assignments? Just click on the arrow next to each subject, and you'll be taken to a page with all the assignments your teachers have posted. Stay on top of your studies by accessing everything you need with a simple click!
                            </Alert>
                        </Stack>

                        {info?.map((data, index1) => {
                            return data.userSubjects.map((data1, index) => {
                                flag++;
                                return (
                                    <Card
                                        key={index}
                                        elevation={2}
                                        style={{
                                            height: "50px",
                                            width: "780px",
                                            margin: "15px",
                                            position: "relative"
                                        }}
                                    >
                                        <CardContent>
                                            <Typography
                                                variant="p"
                                                component="div"
                                                style={{
                                                    fontWeight: "bold",
                                                }}
                                            >
                                                <Link to={"/viewSubjectAssignment/" + data1.subjectName}>{data1.subjectName}</Link>
                                            </Typography>
                                            <CardActions
                                                style={{ position: "absolute", bottom: 0, right: 0 }}
                                            >
                                                <IconButton>
                                                    <Link to={"/viewSubjectAssignment/" + data1.subjectName}>
                                                        <ArrowForwardIcon />
                                                    </Link>
                                                </IconButton>
                                            </CardActions>
                                        </CardContent>

                                    </Card>
                                );
                            })
                            if (flag === 0) {
                                return <NoDataFound content={"No Subjects"} />
                            }
                        })}

                    </div>
                </>
            )}
        </div>
    )
}

export default ViewAssignmentStudent
