import React, { useEffect, useState } from 'react'
import { useGetAssignmentMutation } from '../rtk/AddSlice'
import {decryptData} from "../../assets/security/encryDecrypt"
import TableShimmer from '../Effects/CardShimmer';
import CardTable5 from '../Cards/CardTable5';
import { Box, Typography } from '@mui/material';

const ViewAssignment = () => {

  const [getData, { isLoading, isSuccess, post }] = useGetAssignmentMutation();
  const [posts, setPosts] = useState(post);
  const userId = decryptData(localStorage.getItem('userId'));
  const abc = async () => {
    const fetchPosts = await getData({status:0,user_Id:userId}).unwrap();
    const temp = decryptData(fetchPosts.encryptedData);
    // console.log('fetchPosts', temp)
    setPosts(temp);
  };
  console.log('posts', posts)

  useEffect(() => {
    abc();
  }, []);

  return (
    <>
      <Box className="w-full mb-12">
        <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
              <Typography gutterBottom variant="h4" component="div">
              {"Assignments Given"}
              </Typography>
              </Box>
        </Box>
        {isLoading && <TableShimmer />}

        {isSuccess && (
            <div
            className="relative pb-2"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >
            <CardTable5
              title={"Assignments Given"}
              content={posts}
              heading={[
                "S no",
                "Assignment",
                "Subject",
                "Deadline Date",
                "Deadline Time"
              ]}
              roleId={2}
              errorMessg={"No Assignments available"}
            />
          </div>
        )}
      </Box>
    </>
  )
}

export default ViewAssignment
