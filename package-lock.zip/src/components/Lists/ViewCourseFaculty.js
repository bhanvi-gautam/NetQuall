import React, { useState, useEffect } from 'react'
import { useGetOnePostMutation, useGetCourseIdMutation, useGetUserSubjectMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import CardTable from '../Cards/CardTable';
import { Alert, Typography } from '@mui/material';


const ViewCourseFaculty = () => {
    const userId = localStorage.getItem('userId');
    const [getCourseId] = useGetCourseIdMutation();
    const [getData, { isLoading, isSuccess }] = useGetOnePostMutation();
    const [getTeacher, { post }] = useGetUserSubjectMutation();
    const [posts, setPosts] = useState(post);

    console.log('userId', userId)

    const abc = async () => {
        try {
            const fetch = await getCourseId({ userId }).unwrap();
            const decryptedData = decryptData(fetch.data);
            const encryptedId = encryptData({ decryptedData });
            const fetchPt = await getData({ courseId: encryptedId }).unwrap();
            const fetchPosts = decryptData(fetchPt.data);
            console.log("hie--", fetchPosts);
            const payload = { courseId: fetchPosts.id, roleId: '2' }
            const fetchPosts2 = await getTeacher(payload).unwrap();
            console.log('fetchPosts', fetchPosts2)
            // setPosts(temp);
            setPosts(fetchPosts2);
        } catch (error) {
            console.error("Error:", error);
        }
    };

    console.log('posts123', posts)
    useEffect(() => {
        abc();
    }, [userId]);
    return (
        <div className="w-full mb-12">
            {isLoading && <CardShimmer />}
            {isSuccess && (
                <>
                    <div className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
                      
                        <Typography gutterBottom variant="h4" component="div" color={"white"} style={{ position: "absolute", bottom: 0, left: 15 }}>
                             Meet Your Educators
                        </Typography>
                    </div>

                  
                        <div
                            className="relative pb-2"
                            style={{
                                display: "flex",
                                flexWrap: "wrap",
                                justifyContent: "space-around",
                                backgroundColor: "white",
                            }}
                        >
                            <CardTable
                                content={posts?.data}
                                heading={[
                                    "Profile",
                                    "Faculty Name",
                                    "Email",
                                    "Subject",
                                    "Semester No",
                                ]}
                                role={2}
                                errorMessg={"No Faculty available for this Course yet!"}
                            />
                        </div>
                   
                </>
            )
            }
        </div >
    )
}

export default ViewCourseFaculty;
