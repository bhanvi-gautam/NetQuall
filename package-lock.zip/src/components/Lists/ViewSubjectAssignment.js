import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useGetAssignmentMutation } from "../rtk/AddSlice";
import { decryptData } from "../../assets/security/encryDecrypt";
import CardTable6 from "../Cards/CardTable6.js";
import TableShimmer from "../Effects/TableShimmer";
import { Box, Typography } from "@mui/material";
import { notifySuccess } from "../../toast";
import { ToastContainer } from "react-toastify";

const ViewSubjectAssignment = () => {
  const subject = useParams();
  const [getData, { isLoading, isSuccess, post }] = useGetAssignmentMutation();
  const [posts, setPosts] = useState(post);
  const abc = async () => {
    const fetchPosts = await getData({
      status: 0,
      subject: subject.subject,
    }).unwrap();
    const temp = decryptData(fetchPosts.encryptedData);
    // console.log('fetchPosts', temp)
    setPosts(temp);
  };
  console.log("posts", posts);
  
  const handleParent=()=>{
    notifySuccess("File Submitted!")
    abc();
  }

  useEffect(() => {
    abc();
  }, []);

  return (
    <>
      <Box className="w-full mb-12">
        <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
              <Typography gutterBottom variant="h4" component="div">
              {"Explore Your Assignments"}
              </Typography> 
              </Box>
        </Box>
        {isLoading && <TableShimmer />}

        {isSuccess && (
          <div
          className="relative pb-2"
          style={{
            display: "flex",
            flexWrap: "wrap",
            justifyContent: "space-around",
            backgroundColor: "white",
          }}
        >
            <CardTable6
              content={posts}
              heading={[
                "Sno",
                "Assignment",
                "Subject",
                "Deadline Date",
                "Deadline Time",
                "Status",
                "Marks",
              ]}
              subject={subject.subject}
              roleId={2}
              errorMessg={"No Assignments available"}
              handleParent={handleParent}
            />
          </div>
        )}
      </Box>
      <ToastContainer containerId="A" />
    </>
  );
};

export default ViewSubjectAssignment;
