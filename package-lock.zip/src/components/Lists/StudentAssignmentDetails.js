import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useGetStudentAssignDetailsMutation } from '../rtk/AddSlice'
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import TableShimmer from '../Effects/TableShimmer';
import CardTable7 from '../Cards/CardTable7';
import { Box, Typography } from '@mui/material';
import PdfUploader from './Parts/PdfUploader';
import { notifySuccess } from '../../toast';
import { ToastContainer } from 'react-toastify';

const StudentAssignmentDetails = () => {
  const [getData, { isLoading, isSuccess, post }] = useGetStudentAssignDetailsMutation();
  const [posts, setPosts] = useState(post);
  const [show, setShow] = useState(false);
  const { subject, studentId } = useParams();

  console.log('subject123', subject)
  console.log('studentId', studentId)

  const abc = async () => {
    const payload = { subject: subject, user_Id: studentId };
    const encryptedData = encryptData(payload);
    const fetchPosts = await getData({ encryptedData }).unwrap();
    const students = decryptData(fetchPosts.encryptedData);
    console.log('students', students.response.data)
    setPosts(students.response.data);
  }

  const handleParent=(value)=>{
    notifySuccess("Marks Updated!");
    abc();
  }
  useEffect(() => {
    abc();
  }, [])
  console.log('posts', posts)


  return (
    <>
      <Box className="w-full mb-12">
        <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
            <Typography gutterBottom variant="h4" component="div">
              {"Review Assignments in \"" + subject + "\" Submitted by Students"}
            </Typography>
          </Box>
        </Box>
        {isLoading && <TableShimmer />}

        {isSuccess && (
          <div
            className="relative pb-2"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >
            <CardTable7
              title={"Review Assignments in " + subject + " Submitted by Students"}
              content={posts}
              heading={[
                "Assignment",
                "Submitted On",
                "Marks",
                "Accepted/Unaccepted",
              ]}
              roleId={3}
              studentId={studentId}

              errorMessg={"No Student available"}
              handleParent={handleParent}
            />
          </div>
        )}
      </Box>
      <ToastContainer containerId='A'/>
    </>
  )
}

export default StudentAssignmentDetails
