import { Box, Typography } from '@mui/material'
import TableShimmer from '../Effects/TableShimmer'
import React, { useEffect, useState } from 'react'
import { useGetStudentQuizMutation } from '../rtk/AddSlice';

const QuizForStudent = () => {
  const userId = localStorage.getItem('userId');
  const [getData, { isLoading, isSuccess, post }] = useGetStudentQuizMutation();
  const [posts, setPosts] = useState(post);

  const getQuizzes = () => {
    getData({ id: userId }).unwrap().then((fetchQuiz) => {
      console.log('fetchQuiz', fetchQuiz);
    })
  }

  useEffect(() => {
    getQuizzes();
  }, [])


  return (
    <Box className="w-full mb-12">
      <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
          }}
        >
          <Typography gutterBottom variant="h4" component="div">
            List of Quiz
          </Typography>

          {isLoading && <TableShimmer />}

          {isSuccess && (
            <div
              className="relative pb-32"
              style={{
                display: "flex",
                flexWrap: "wrap",
                justifyContent: "space-around",
                backgroundColor: "white",
              }}
            >
            </div>
          )}
        </Box>
      </Box>
    </Box>
  )
}

export default QuizForStudent
