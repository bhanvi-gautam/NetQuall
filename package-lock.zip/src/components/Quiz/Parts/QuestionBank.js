import { Button, Stack } from '@mui/material'
import DeleteIcon from '@mui/icons-material/Delete';
import CheckIcon from '@mui/icons-material/Check';
import CloseIcon from '@mui/icons-material/Close';
import React from 'react'

const questionBank = ({question,qIndex}) => {
    return (
        <div>
            {/* Create a paper component  */}
            <div className="flex flex-wrap" key={qIndex}>
                <div className="w-full lg:w-12 px-4">
                    <div className="relative w-full mb-3">
                        <label className="block uppercase text-blueGray-600 text-s font-bold mb-2">
                            Question {qIndex + 1}:

                            <input type="text" value={question.text} onChange={(e) => handleQuestionChange(qIndex, e)} className="border-0 px-3 py-3 mt-1 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                        </label>
                        {question.options.map((option, oIndex) => (
                            <div style={{ display: 'flex', justifyContent: 'space-between', marginLeft: '20px' }} key={oIndex}>
                                <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                                    Option {oIndex + 1}:
                                    <input type="text" value={option} onChange={(e) => handleOptionChange(qIndex, oIndex, e)} className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                                </label>
                                <Button variant="contained" endIcon={<DeleteIcon />} onClick={() => deleteOption(qIndex, oIndex)} color="error" size='small' style={{ margin: '18px' }}>
                                    Delete Option
                                </Button>
                                {/* <button type="button" onClick={() => deleteOption(qIndex, oIndex)}>Delete Option</button> */}
                            </div>
                        ))}

                        <Stack direction="row" spacing={2}>
                            <Button variant="contained" endIcon={<AddIcon />} onClick={() => addOption(qIndex)} color="success" size='small' style={{ margin: '7px' }}>
                                Add Option
                            </Button>
                        </Stack>

                        <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                            Multiple Answers:
                            <Toggle on={on} onClick={() => handleMultiAnswerToggle(qIndex)} />
                        </label>
                        {correctAnswers.map((answer, index) => (
                            <div key={index}>
                                <label className="block uppercase text-blueGray-600 text-xs mt-3 font-bold mb-2" style={{ display: 'flex' }}>
                                    Correct Answer {index + 1}:
                                    <input type="text" className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" value={inputValue} onChange={(e) => setInputValue(e.target.value)} required />
                                    <Button variant="contained" onClick={() => handleCorrectAnswerChange(qIndex, index, { target: { value: inputValue } })} color="success" size='small' style={{ margin: '7px' }}><DoneIcon /></Button>
                                </label>
                                {question.multiAnswer && <button onClick={() => handleRemoveCorrectAnswer(index)}>Remove</button>}
                            </div>
                        ))}
                        {question.multiAnswer && <button onClick={handleAddCorrectAnswer}>Add Correct Answer</button>}



                        {/* <input value={question.correctAnswer} onChange={(e) => handleCorrectAnswerChange(qIndex, e)} required /> */}

                        <label className="block uppercase text-blueGray-600 text-xs mt-3 font-bold mb-2">
                            Marks:
                            <input type="number" className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" value={question.marks} onChange={(e) => handleMarksChange(qIndex, e)} min="0" required />
                        </label>

                        <Stack direction="row" spacing={2}>
                            <Button variant="contained" endIcon={<DeleteIcon />} onClick={() => deleteQuestion(qIndex)} color="error" size='small' style={{ margin: '7px' }}>
                                Delete Question
                            </Button>
                        </Stack>

                    </div>
                </div>
            </div>
        </div>
    )
}

export default questionBank


const Toggle = styled.button`
  width: 100px;
  height: 50px;
  position: relative;
  cursor: pointer;
  border-radius: 25px;
  outline: none;
  background-color: ${props => (props.on ? "#4cd137" : "#353b48")};
  border: 3px solid white;

  &::after {
    content: "";
    position: absolute;
    top: 3.5px;
    will-change: transform;
    transform: translate(${props => (props.on ? 5.5 : -44)}px);
    transition: transform 0.2s ease-out;
    width: 35px;
    height: 35px;
    background: white;
    border: 2px solid #7f8fa6;
    outline: none;
    border-radius: 50%;
  }
`;