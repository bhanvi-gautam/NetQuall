import { Box, Button, FormControl, Input, MenuItem, Paper, Select, Stack, Typography } from '@mui/material'
import SendIcon from '@mui/icons-material/Send';
import AddIcon from '@mui/icons-material/Add';

import React, { useState, useEffect } from "react";
import { useGetTeacherSubjectMutation } from "../rtk/AddSlice";
import { notifyError, notifySuccess } from '../../toast';
import { ToastContainer } from 'react-toastify';
import NoDataFound from "../Cards/NoDataFound";
import CardShimmer from "../Effects/CardShimmer";
import DoneIcon from '@mui/icons-material/Done';
import { decryptData } from '../../assets/security/encryDecrypt';
// import QuestionBank from './Parts/QuestionBank'

import styled, { createGlobalStyle } from "styled-components";


const CreateQuiz = () => {
    const [on, toggle] = useState(false);
    const [inputValue,setInputValue]=useState('');
    const [getData, { isLoading, isSuccess, post }] =useGetTeacherSubjectMutation();
    const [correctAnswers, setCorrectAnswers] = useState(['']);
    const [subject,setSubject]=useState('');
    const [posts, setPosts] = useState(post);
    const userId = localStorage.getItem("userId");
    const [length, setLength] = useState(0);
    const [quiz, setQuiz] = useState({
        quizName: '',
        questions: [
            { text: '', options: ['', ''], correctAnswer: '', marks: '0', multiAnswer: false }
        ],
        totalMarks: '0',
    });


    const abc = async () => {
        const fetchPosts = await getData({ userId: userId }).unwrap();
        const subjects = decryptData(fetchPosts.encryptedData);
        setLength(subjects.response.data.length);
        setPosts(subjects.response.data);
    };

    useEffect(() => {
        abc();
    }, []);

    const handleQuizNameChange = (e) => {
        setQuiz({ ...quiz, quizName: e.target.value });
    };

    const handleQuestionChange = (index, e) => {
        const newQuestions = [...quiz.questions];
        newQuestions[index].text = e.target.value;
        setQuiz({ ...quiz, questions: newQuestions });
    };

    const handleOptionChange = (questionIndex, optionIndex, e) => {
        const newQuestions = [...quiz.questions];
        newQuestions[questionIndex].options[optionIndex] = e.target.value;
        setQuiz({ ...quiz, questions: newQuestions });
    };

    
    const handleAddCorrectAnswer = () => {
        setCorrectAnswers([...correctAnswers, '']);
    };
    
    const handleRemoveCorrectAnswer = (index) => {
        const newCorrectAnswers = [...correctAnswers];
        if (newCorrectAnswers.length > 1) {
            newCorrectAnswers.splice(index, 1);
            setCorrectAnswers(newCorrectAnswers);
        } else {
            notifyError('Each question must have at least 1 correct option.')
        }
    };
    
    
    const handleCorrectAnswerChange = (questionIndex,index, e) => {
        const newCorrectAnswers = [...correctAnswers];
        newCorrectAnswers[index] = e.target.value;
        const newQuestions = [...quiz.questions];
        const options = newQuestions[questionIndex].options;
    
        if (newCorrectAnswers.every(ans => options.includes(ans))) { // check if all answers are in options
            newQuestions[questionIndex].correctAnswer = newCorrectAnswers;
            setQuiz({ ...quiz, questions: newQuestions });
            setInputValue(''); // reset the input value
            notifySuccess('Correct answer saved!')
        } else {
            notifyError('All correct answers must be one of the options.');
        }
    };
    


    const handleMarksChange = (questionIndex, e) => {
        const newQuestions = [...quiz.questions];
        newQuestions[questionIndex].marks = e.target.value;
        setQuiz({ ...quiz, questions: newQuestions });
    };

    const handleMultiAnswerToggle = (questionIndex) => {
        const newQuestions = [...quiz.questions];
        newQuestions[questionIndex].multiAnswer = !newQuestions[questionIndex].multiAnswer;
        setQuiz({ ...quiz, questions: newQuestions });
        toggle(!on)
    };
    

    const addOption = (questionIndex) => {
        const newQuestions = [...quiz.questions];
        newQuestions[questionIndex].options.push('');
        setQuiz({ ...quiz, questions: newQuestions });
        
    };
    

    const addQuestion = () => {
        setQuiz({
            ...quiz,
            questions: [
                ...quiz.questions,
                { text: '', options: ['', ''], correctAnswer: '', marks: '', multiAnswer: false }
            ]
        });
    };

    const getTotalMarks = () => {
        return quiz.questions.reduce((total, question) => total + Number(question.marks || 0), 0);
    };

    const deleteOption = (questionIndex, optionIndex) => {
        const newQuestions = [...quiz.questions];
        if (newQuestions[questionIndex].options.length > 2) {
            newQuestions[questionIndex].options.splice(optionIndex, 1);
            setQuiz({ ...quiz, questions: newQuestions });
        } else {
            notifyError('Each question must have at least 2 options.')
        }
    };

    const deleteQuestion = (questionIndex) => {
        const newQuestions = [...quiz.questions];
        if (newQuestions.length > 5) {
            newQuestions.splice(questionIndex, 1);
            setQuiz({ ...quiz, questions: newQuestions });
        } else {
            notifyError('The quiz must have at least 5 questions.')
        }
    };

    const handleSubject = (event) => {
        setSubject(event.target.value);
        console.log('event.target.value', event.target.value)
      };

    const handleSubmit = (e) => {
        e.preventDefault();
        // Check if there are at least 5 questions
        // if (quiz.questions.length < 5) {
        //     notifyError('The quiz must have at least 5 questions.')
        //     return;
        // }

        // Check for any empty question texts or options
        for (let question of quiz.questions) {
            if (question.text.trim() === '' || question.options.some(option => option.trim() === '') || question.marks.trim() === '') {
                notifyError('Please fill out all fields before submitting.')
                return;
            }
        }

        // Update totalMarks
        const updatedTotalMarks = getTotalMarks();
        setQuiz({ ...quiz, totalMarks: updatedTotalMarks});

        // Store the quiz data
        console.log(quiz);
    };


    return (
        <Box className="w-full mb-12">
            {isLoading && <CardShimmer />}

            {isSuccess && (

                <>
                    <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
                        <Box
                            className="px-4"
                            sx={{
                                color: "white",
                                width: "100%",
                                position: "absolute",
                                bottom: 0,
                            }}
                        >
                            <Typography gutterBottom variant="h4" component="div">
                                {"Create Quiz"}
                            </Typography>
                        </Box>
                    </Box>
                    {length === 0 ? (<NoDataFound content="No Subjects" />
                    ) : (
                        <>
                            <div className="flex-auto px-4 lg:px-10 py-10 pt-10">
                                <form onSubmit={handleSubmit}>
                                    <div className="flex flex-wrap">
                                        <div className="w-full lg:w-12 px-4">
                                            <div className="relative w-full mb-3">
                                                <label
                                                    className="block uppercase text-blueGray-600 text-s font-bold mb-2"
                                                >
                                                    Subject Name:
                                                    <Select
                                                        value={subject}
                                                        onChange={handleSubject}
                                                        displayEmpty
                                                        size='small'
                                                        style={{margin:'7px'}}
                                                    >
                                                        <MenuItem value="">
                                                            Select Subject
                                                        </MenuItem>
                                                        {posts.map((data,index)=>{
                                                            return(
                                                            <MenuItem value={data} key={index}>{data}</MenuItem>
                                                            )
                                                        })}
                                                        
                                                       
                                                    </Select>
                                                </label>

                                            </div>
                                        </div>
                                    </div>
                                    <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />
                                    <div className="flex flex-wrap">
                                        <div className="w-full lg:w-12 px-4">
                                            <div className="relative w-full mb-3">
                                                <label
                                                    className="block uppercase text-blueGray-600 text-s font-bold mb-2"
                                                >
                                                    Quiz Name:
                                                </label>
                                                <input type="text" value={quiz.quizName} onChange={handleQuizNameChange} className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                                                    required />

                                            </div>
                                        </div>
                                    </div>
                                    <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />

                                    {quiz.questions.map((question, qIndex) => (
                                      
                                        <Paper>
                                        <QuestionBank question={question} qIndex={qIndex}/>
                                        </Paper>
                                    ))}
                                    <Stack direction="row" spacing={2}>
                                        <Button variant="contained" endIcon={<AddIcon />} onClick={addQuestion} color="success" size='small'>
                                            Add Question
                                        </Button>
                                    </Stack>


                                    <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />

                                    <p>Total Marks: {getTotalMarks()}</p>
                                    <hr className="mt-6 mb-6 border-b-1 border-blueGray-300" />

                                    <Stack direction="row" spacing={2}>
                                        <Button variant="contained" endIcon={<SendIcon />} onClick={handleSubmit}>
                                            Submit Quiz
                                        </Button>
                                    </Stack>
                                </form>
                            </div>
                            <ToastContainer containerId="B" />
                            <ToastContainer containerId="A" />
                        </>
                    )}

                </>
            )}
        </Box>

    )
}

export default CreateQuiz
