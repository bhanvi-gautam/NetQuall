import React from "react";
import CardSettings from "../../components/Cards/CardSettings.js";
import { Box, Typography } from "@mui/material";

export default function Settings() {
  return (
    <>
      <Box className="w-full mb-12">
      <Box className= "relative md:pt-30 pb-32 pt-12"  style={{backgroundColor:'#0099CC'}}>
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
            fontWeight: 700
          }}
        >
          <Typography gutterBottom variant="h4" component="div">
            Settings
          </Typography>
        </Box>
      </Box>
        <div className="w-full lg:w-full px-4">
          <CardSettings />
        </div>
        
      </Box>
    </>
  );
}
