import React, { useEffect, useState } from "react";
import { useLoginMutation } from "../../components/rtk/AddSlice";
import { Link, useNavigate } from "react-router-dom";
import backgroundImage from "../../assets/img/register_bg_2.png";
import { encryptData } from "../../assets/security/encryDecrypt";
import Loading from "./Parts/Loading";
import { useDispatch } from "react-redux";
import { setToken } from "../../components/rtk/app/slice";
import { Alert } from "@mui/material";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";

const Login = () => {
  const dispatch = useDispatch();
  const [sendData, { isLoading, isSuccess, post }] = useLoginMutation();
  const [generalError, setGeneralError] = useState(false);
  const [posts, setPosts] = useState(post);

  const navigate = useNavigate();
  console.log(posts);

  useEffect(() => {
  }, [post]);

  const initialValues = {
    email: "",
    password: ""
  };

  const signInSchema = Yup.object().shape({
    email: Yup.string().email().required("Email is required"),
    password: Yup.string().required("Password is required").min(6, "Password is too short-should be 6 chars minimum"),
  })



  const myStyle = {
    backgroundImage: `linear-gradient(rgba(0, 0, 0, 0.01), rgba(0, 0, 0, 0.3)), url(${backgroundImage})`,
    backgroundSize: "cover",
    backgroundPosition: "center",
    height: "100vh", // This will cover the full height of the viewport
    width: "100%",
  };

  console.log("isLoading", isLoading);
  console.log("isSuccess", isSuccess);
  return (
    <>
      {isLoading ? (
        <Loading />
      ) : (
        <div className=" mx-auto px-4 h-full" style={myStyle}>
          <div className="flex content-center items-center justify-center h-full">
            <div className="w-full lg:w-4/12 px-4">
              <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded-lg bg-blueGray-200 border-0">
                <div className="rounded-t mb-0 px-6 py-6">
                  <div className="text-center mb-3">
                    <h6 className="text-blueGray-700 text-lg font-bold">
                      Sign in with
                    </h6>
                  </div>
                </div>
                <div className="flex-auto px-4 lg:px-10 py-10 pt-0">
                  {generalError &&
                    <Alert style={{ width: '85%', backgroundColor: '#ffb4b4', marginLeft: '28px' }} severity="error">
                      Invalid Credentials.
                    </Alert>}
                  <Formik
                    initialValues={initialValues}
                    validationSchema={signInSchema}
                    onSubmit={async (values) => {
                      console.log(values);
                      try {
                        const data = { email: values.email, password: values.password };
                        const encryptedData = encryptData(data);
                        const response = await sendData({ data: encryptedData });
                        dispatch(setToken(response.data.tokens.access.token));
                        localStorage.setItem("token", response.data.tokens.access.token);
                        const encryptedId = encryptData(response.data.data.id);
                        localStorage.setItem("userId", encryptedId);
                        localStorage.setItem("roleId", response.data.data.role_Id);
                        navigate("/");
                      } catch (error) {
                        setGeneralError(true);
                      }
                    }}
                  >
                    {({ errors, touched, isValid, dirty }) => (

                      <Form>
                        <div className="relative w-full mb-3">
                          <label
                            className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                            htmlFor="grid-password"
                          >
                            Email
                          </label>
                          <Field
                            type="email"
                            name="email"
                            className={`border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150 ${errors.email && touched.email ? "input-error" : ""}`}
                            placeholder="Email"
                          />

                          <ErrorMessage name="email" component="span" className="error" />
                        </div>

                        <div className="relative w-full mb-3">
                        <label
                      className="block uppercase text-blueGray-600 text-xs font-bold mb-2"
                      htmlFor="grid-password"
                    >
                            Password
                          </label>
                          <Field
                            type="password"
                            name="password"
                            className={`border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150 ${errors.password && touched.password ?
                              "input-error" : ""}`}
                            placeholder="Password"
                          />
                          <ErrorMessage
                            name="password"
                            component="span"
                            className="error"
                          />
                        </div>

                        <div className="text-center mt-6">
                          <button
                            className={`bg-blueGray-800 text-white active:bg-blueGray-600 text-sm font-bold uppercase px-6 py-3 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 w-full ease-linear transition-all duration-150 ${dirty && isValid ? "" : "disabled-btn"}`}
                            type="submit"
                            disabled={!(dirty && isValid)}
                          >
                            Sign In
                          </button>
                        </div>
                      </Form>

                    )}
                  </Formik>
                </div>
              </div>
              <div className="flex flex-wrap mt-6 relative">
                <div className="w-1/2">
                  <Link to="/forgotPassword" className="text-blueGray-200">
                    <small>Forgot password?</small>
                  </Link>
                </div>
                <div className="w-1/2 text-right">
                  <Link to="/register" className="text-blueGray-200">
                    <small>Create new account</small>
                  </Link>
                </div>
              </div>
            </div>
          </div>
        </div>
      )
      }
    </>
  );
};

export default Login;
