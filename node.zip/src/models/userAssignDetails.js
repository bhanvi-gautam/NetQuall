const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userAssignDetails extends Model {
        static associate(models) {
            userAssignDetails.hasMany(models.userAssignment, { foreignKey: 'assign_Id' });
        }
    }
    userAssignDetails.init(
        {
            uuid: DataTypes.UUID,
            AssignName: { type: DataTypes.STRING, defaultValue: null },
            fileName: { type: DataTypes.STRING, defaultValue: null },
           
            
        },
        {
            sequelize,
            modelName: 'userAssignDetails',
            underscored: false,
        },
    );
       
    return userAssignDetails;
};