const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userQuizDetails extends Model {
        
        static associate(models) {
            // define association here
            userQuizDetails.belongsTo(models.quizzes,{foreignKey: 'quiz_Id', targetKey: 'id' });
            userQuizDetails.belongsTo(models.user,{foreignKey: 'user_Id', targetKey: 'id' });
        }
    }

    userQuizDetails.init(
        {
            uuid: {
                type: DataTypes.UUID,
                primaryKey: true,
                defaultValue: DataTypes.UUIDV4
            },
            score: DataTypes.DECIMAL(10, 2)               
        },
        {
            sequelize,
            modelName: 'userQuizDetails',
            underscored: false,
        },
    );
    return userQuizDetails;
};