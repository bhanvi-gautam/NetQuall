const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userTeacherDetails extends Model {
        
        static associate(models) {
            // define association here
            userTeacherDetails.belongsTo(models.userSubject);
            userTeacherDetails.belongsTo(models.user);
        }
    }

    userTeacherDetails.init(
        {

            // id: {
            //     type: DataTypes.INTEGER,
            //     primaryKey: true,
            //     autoIncrement: true
            //   },
              
            uuid: DataTypes.UUID,
           
            teacher_Id: {
                type: DataTypes.INTEGER,
                references: {
                    model: 'users', 
                    key: 'id'
                }
            },
            subject_Id: {
                type: DataTypes.STRING,
                references: {
                    model: 'userSubjects',
                    key: 'id'
                }
            }         
        },
        {
            sequelize,
            modelName: 'userTeacherDetails',
            underscored: false,
        },
    );
    return userTeacherDetails;
};