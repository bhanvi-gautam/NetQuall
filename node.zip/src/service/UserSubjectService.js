
const UserSubjectDao = require("../dao/userSubjectDao");
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { response } = require('express');
const logger = require('../config/logger');
const httpStatus = require('http-status');

class UserSubject {
    constructor() {
        this.userSubjectDao = new UserSubjectDao();
    }

    getSubjectId = async (req) => {
        try {
            
            const subjectId = await this.userSubjectDao.findOneByWhere({subjectName: req});

            if (subjectId.dataValues.id) {
                return responseHandler.returnSuccess(httpStatus.OK, 'subjectId fetched successfully',subjectId.dataValues.id);
            }
            return responseHandler.returnError(httpStatus.BAD_REQUEST, 'SubjectId not fetched!');

        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR, 'Error fetching subject Name');
        }
    }
}



module.exports = UserSubject;