const httpStatus = require('http-status');
// const express=require('express')
const cors = require('cors')
const utils = require('../utils/utils')
const fs = require('fs')
const Busboy = require("busboy")
const UserDao = require('../dao/UserDao');
const UserSubjectDao = require('../dao/userSubjectDao');
const UserSemesterDao = require('../dao/userSemesterDao');
const UserCourseDao = require('../dao/userCourseDao');
const UserTeacherDetailsDao = require('../dao/UserTeacherDetailsDao');
const UserAssignmentDao = require('../dao/UserAssignmentDao');
const QuizDao = require('../dao/QuizDao');
const QuizQuestionsDao = require('../dao/QuizQuestionsDao');
const QuizOptionsDao = require('../dao/QuizOptionsDao');
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { Op } = require('sequelize')
const { response } = require('express');
const logger = require('../config/logger');
class QuizService {
    constructor() {
        this.userDao = new UserDao();
        this.userCourseDao = new UserCourseDao();
        this.userSemesterDao = new UserSemesterDao();
        this.userSubjectDao = new UserSubjectDao();
        this.userTeacherDetailsDao = new UserTeacherDetailsDao();
        this.userAssignmentDao = new UserAssignmentDao();
        this.quizDao = new QuizDao();
        this.quizQuestionsDao = new QuizQuestionsDao();
        this.quizOptionsDao = new QuizOptionsDao();
    }

    createQuiz = async (req) => {
        try {
            let message = "Successfully Created Quiz";
            if (await this.quizDao.isQuizNameExists(req.quizName)) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Quiz Name already taken"
                );
            }
            const subject_Id = await this.userSubjectDao.findOneByWhere({ subjectName: req.subject }, ['id']);

            req.subject_Id = subject_Id.dataValues.id;
            let totalMarks = 0;
            req.questions.map((data) => {
                totalMarks += Number(data.marks);
                let temp = [];
                for (let i = 0; i < data.options.length; i++) {
                    if (data.correctAnswer.includes(i)) {
                        temp.push(1);
                    }
                    else {
                        temp.push(0);
                    }
                }
                data.correctAnswer = temp;
            })
            req.totalMarks = totalMarks;
            let uuid = uuidv4();
            this.quizDao.create({ uuid: uuid, quizName: req.quizName, subject_Id: req.subject_Id, quiz_marks: req.totalMarks }).then((quizData) => {
                console.log('data', quizData.dataValues.id);
                req.questions.map((data) => {
                    uuid = uuidv4();
                    this.quizQuestionsDao.create({ uuid: uuid, question: data.text, quiz_Id: quizData.dataValues.id, question_marks: data.marks, question_type: data.multiAnswer }).then((questionData) => {
                        console.log('data', questionData.dataValues.id);

                        for (let i = 0; i < data.options.length; i++) {
                            uuid = uuidv4();
                            this.quizOptionsDao.create({ uuid: uuid, option_text: data.options[i], is_correct: data.correctAnswer[i], question_Id: questionData.dataValues.id }).then((data) => {

                            }).catch((error) => {
                                return responseHandler.returnError(
                                    httpStatus.BAD_REQUEST,
                                    "Can't Create options!"
                                );
                            })
                        }
                    }).catch((error) => {
                        return responseHandler.returnError(
                            httpStatus.BAD_REQUEST,
                            "Can't Create question!"
                        );
                    })
                })

            }).catch((error) => {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Can't Create Quiz!"
                );
            })

            return responseHandler.returnSuccess(httpStatus.CREATED, message);


        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    };

    updateQuiz = async (req) => {
        try {
            console.log('req', req)

            const quizExists = await this.quizDao.checkExist({ id: req.id });

            if (!quizExists) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Quiz does not exists!"
                );
            }

            //update in quiz table 
            const quizNameMarksUpdate = await this.quizDao.updateById({ quizName: req.quizName, quiz_marks: req.quiz_marks }, req.id);
            if (!quizNameMarksUpdate) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Failed to update quiz name and quiz marks"
                );
            }

            //update in question and option table
            //NESTED LOOP 
            //first loop for question , check if the question id exists or not .
            //if exists then update 
            //else create
            //second loop for options 
            let uuid;
            req.quizQuestions.map(async (question) => {
                const questionExists = await this.quizQuestionsDao.checkExist({ id: question.id });
                if (questionExists) {
                    const questionUpdate = await this.quizQuestionsDao.updateById({ question: question.question, question_marks: question.question_marks, question_type: question.question_type }, question.id);
                    if (!questionUpdate) {
                        return responseHandler.returnError(httpStatus.BAD_REQUEST, "Failed to update existing questions");
                    }

                    question.quizOptions.map(async (option) => {
                        const optionExists = await this.quizOptionsDao.checkExist({ id: option.id });
                        if (optionExists) {
                            const optionUpdate = await this.quizOptionsDao.updateById({ option_text: option.option_text, is_correct: option.is_correct }, option.id);
                            if (!optionUpdate) {
                                return responseHandler.returnError(httpStatus.BAD_REQUEST, "Failed to update existing options");
                            }
                        }
                        else {
                            uuid = uuidv4();
                            const optionCreate = await this.quizOptionsDao.create({ uuid: uuid, option_text: option.option_text, is_correct: option.is_correct, question_Id: question.id })
                            if (!optionCreate) {
                                return responseHandler.returnError(httpStatus.BAD_REQUEST, "Failed to create options of existing question")
                            }
                        }

                    })
                }
                else {
                    uuid = uuidv4();
                    const quizData = { uuid: uuid, question: question.question, question_marks: question.question_marks, question_type: question.question_type, quiz_Id: req.id }
                    const questionCreate = await this.quizQuestionsDao.create(quizData);
                    if (!questionCreate) {
                        return responseHandler.returnError(httpStatus.BAD_REQUEST, "Failed to create question");
                    }
                    //getting questionId
                    const questionId = await this.quizQuestionsDao.findOneByWhere(quizData);
                    console.log('questionId', questionId.dataValues.id);

                    question.quizOptions.map(async (option) => {
                        uuid = uuidv4();
                        console.log('option', option)
                        const optionCreate = await this.quizOptionsDao.create({ uuid: uuid, question_Id: questionId.dataValues.id, option_text: option.option_text, is_correct: option.is_correct })
                        if (!optionCreate) {
                            return responseHandler.returnError(httpStatus.BAD_REQUEST, "Failed to create options");
                        }
                    })
                }
            })
            return responseHandler.returnSuccess(httpStatus.CREATED, "Quiz Successfully created");

        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    }

    // updateQuizNew = async (req) => {
    //     try {
    //         console.log('req', req)
    //         clo

    //         const quizExists = await this.quizDao.checkExist({ id: req.id });

    //         if (!quizExists) {
    //             return responseHandler.returnError(
    //                 httpStatus.BAD_REQUEST,
    //                 "Quiz does not exists!"
    //             );
    //         }

    //         //update in quiz table 
    //         const quizNameMarksUpdate = await this.quizDao.updateById({ quizName: req.quizName, quiz_marks: req.quiz_marks }, req.id);
    //         if (!quizNameMarksUpdate) {
    //             return responseHandler.returnError(
    //                 httpStatus.BAD_REQUEST,
    //                 "Failed to update quiz name and quiz marks"
    //             );
    //         }

    //         //first deleting then adding 

    //         //deleting
    //         const questionIds = await this.quizQuestionsDao.findByWhere({ quiz_Id: req.id }, ['quiz_Id', 'id']);
    //         // console.log('questionIds', questionIds)

    //         questionIds.map(async (data) => {
    //             // console.log('data.dataValues.id', data.dataValues.id)
    //             const forOptions = await this.quizOptionsDao.deleteByWhere({ question_Id: data.dataValues.id });
    //             if (forOptions) {
    //                 try {
    //                     await this.quizQuestionsDao.deleteByWhere({ quiz_Id: req.id });

    //                 } catch (error) {
    //                     console.log('Error deleting questions', error)
    //                 }
    //             }
    //             else {
    //                 return responseHandler.returnError(
    //                     httpStatus.BAD_REQUEST,
    //                     "Error deleting options"
    //                 );
    //             }
    //         })
    //         let uuid;
    //         //creating all questions and options
    //         req.quizQuestions.map(async (data) => {
    //             uuid = uuidv4();
    //             const questionCreate = await this.quizQuestionsDao.create({ uuid: uuid, question: data.question, quiz_Id: req.id, question_marks: data.question_marks, question_type: data.question_type });
    //             console.log('questionCreate', questionCreate);
               
    //             if (!questionCreate) {
    //                 return responseHandler.returnError(
    //                     httpStatus.BAD_REQUEST,
    //                     "Error adding new updated questions"
    //                 );
    //             }
    //             const questionId=questionCreate.dataValues.id
    //             // const questionId = await this.quizQuestionsDao.findOneByWhere({ question: data.question, quiz_Id: req.id, question_marks: data.question_marks, question_type: data.question_type });
    //             console.log('questionId========', questionId);
               
    //             data.quizOptions.map(async (option,index) => {
    //                 uuid = uuidv4();
    //                 const optionCreate = await this.quizOptionsDao.create({ uuid: uuid, question_Id: questionId, option_text: option.option_text, is_correct: option.is_correct })
    //                 if (!optionCreate) {
    //                     return responseHandler.returnError(httpStatus.BAD_REQUEST, "Failed to create options");
    //                 }
    //             })
    //         })

    //         return responseHandler.returnSuccess(httpStatus.CREATED, "Quiz Successfully updated");

    //     } catch (error) {
    //         logger.error(e);
    //         return responseHandler.returnError(
    //             httpStatus.BAD_REQUEST,
    //             "Something went wrong!"
    //         );
    //     }
    // }

    updateQuizNew = async (req) => {
        try {
            console.log('req', req);
    
            const quizExists = await this.quizDao.checkExist({ id: req.id });
            if (!quizExists) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Quiz does not exist!"
                );
            }
    
            // Update quiz name and marks
            const quizNameMarksUpdate = await this.quizDao.updateById(
                { quizName: req.quizName, quiz_marks: req.quiz_marks },
                req.id
            );
            if (!quizNameMarksUpdate) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Failed to update quiz name and quiz marks"
                );
            }
    
            // Delete existing questions and options
            const questionIds = await this.quizQuestionsDao.findByWhere(
                { quiz_Id: req.id },
                ['quiz_Id', 'id']
            );
            for (const data of questionIds) {
                const forOptions = await this.quizOptionsDao.deleteByWhere({
                    question_Id: data.dataValues.id
                });
                if (!forOptions) {
                    return responseHandler.returnError(
                        httpStatus.BAD_REQUEST,
                        "Error deleting options"
                    );
                }
                try {
                    await this.quizQuestionsDao.deleteByWhere({
                        quiz_Id: req.id
                    });
                } catch (error) {
                    console.log('Error deleting questions', error);
                }
            }
    
            // Create new questions and options
            for (const data of req.quizQuestions) {
                const uuid = uuidv4();
                const questionCreate = await this.quizQuestionsDao.create({
                    uuid,
                    question: data.question,
                    quiz_Id: req.id,
                    question_marks: data.question_marks,
                    question_type: data.question_type
                });
                if (!questionCreate) {
                    return responseHandler.returnError(
                        httpStatus.BAD_REQUEST,
                        "Error adding new updated questions"
                    );
                }
                const questionId = questionCreate.dataValues.id;
                for (const option of data.quizOptions) {
                    const optionCreate = await this.quizOptionsDao.create({
                        uuid: uuidv4(),
                        question_Id: questionId,
                        option_text: option.option_text,
                        is_correct: option.is_correct
                    });
                    if (!optionCreate) {
                        return responseHandler.returnError(
                            httpStatus.BAD_REQUEST,
                            "Failed to create options"
                        );
                    }
                }
            }
    
            return responseHandler.returnSuccess(
                httpStatus.CREATED,
                "Quiz Successfully updated"
            );
        } catch (error) {
            logger.error(error);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    };
    

    getQuizzes = async (req) => {
        try {
            console.log('req12222', req);
            let required_Id;
            if (req.subject) {
                const subject_Id = await this.userSubjectDao.findOneByWhere({ subjectName: req.subject }, ['id', 'subjectName']);
                required_Id = subject_Id.dataValues.id;
            } else {
                const subject_Id = await this.userTeacherDetailsDao.findOneByWhere({ userId: req }, ['teacher_Id', 'subject_Id'], ['teacher_Id']);
                required_Id = subject_Id.dataValues.subject_Id;
            }
            // return;
            const getQuizzes = await this.quizDao.getQuizzes(required_Id);
            const getSubjectName = await this.userSubjectDao.findById(required_Id);
            if (!getQuizzes) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "No Quiz exists"
                );
            }
            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quizzes fetched successfully', { data: getQuizzes, subjectName: getSubjectName.dataValues.subjectName });


        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }

    };

    getStudentQuiz = async (req) => {
        try {
            const subject_Id = await this.userTeacherDetailsDao.findOneByWhere({ userId: req }, ['teacher_Id', 'subject_Id'], ['teacher_Id']);
            console.log('subject_Id', subject_Id)
            return;
            const getQuizzes = await this.quizDao.getQuizzes(subject_Id.dataValues.subject_Id);
            const getSubjectName = await this.userSubjectDao.findById(subject_Id.dataValues.subject_Id);
            if (!getQuizzes) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "No Quiz exists"
                );
            }
            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quizzes fetched successfully', { data: getQuizzes, subjectName: getSubjectName.dataValues.subjectName });


        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }

    };

    getOneQuiz = async (req) => {
        try {
            const getQuizzes = await this.quizDao.getOneQuiz(req);
            if (!getQuizzes) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "No Quiz exists"
                );
            }
            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quizzes fetched successfully', getQuizzes);


        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }

    };

    liveQuiz = async (req) => {
        try {
            console.log('req', req);
            // return;
            const availability = await this.quizDao.updateById({ is_available: !req.availability }, req.id)

            if (!availability) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Not Changed"
                );
            }
            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quizzes Availability status changed successfully');


        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }

    };

    deleteQuiz = async (req) => {
        try {
            const questionIds = await this.quizQuestionsDao.findByWhere({ quiz_Id: req }, ['quiz_Id', 'id']);
            console.log('questionIds', questionIds)

            questionIds.map(async (data) => {
                console.log('data.dataValues.id', data.dataValues.id)
                const optionsDelete = await this.quizOptionsDao.deleteByWhere({ question_Id: data.dataValues.id });

                if (optionsDelete) {
                    try {
                        await this.quizQuestionsDao.deleteByWhere({ id: data.dataValues.id });

                    } catch (error) {
                        console.log('error', error)
                    }
                }
                else {
                    return responseHandler.returnError(
                        httpStatus.BAD_REQUEST,
                        "Error deleting options"
                    );
                }
            })
            const final = await this.quizDao.deleteByWhere({ id: req });
            if (!final) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Something went wrong!"
                );
            }

            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quiz deleted successfully');


        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    }
}
module.exports = QuizService;