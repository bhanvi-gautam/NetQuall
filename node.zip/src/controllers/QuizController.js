const httpStatus = require('http-status');
const AuthService = require('../service/AuthService');
const TokenService = require('../service/TokenService');
const UserService = require('../service/UserService');
const UserSubjectService = require('../service/UserSubjectService');
const QuizService = require('../service/QuizService');
const logger = require('../config/logger');
const { tokenTypes } = require('../config/tokens');
const fs = require('fs')
const asyncWrapper = require('../middlewares/async');

const decryptData = require('../helper/EncryDecryHelper');
const encryptData = require('../helper/EncryDecryHelper');
const UserQuizDetailsService = require('../service/UserQuizDetailsService');


class QuizController {
    constructor() {
        this.userService = new UserService();
        this.userSubjectService = new UserSubjectService();
        this.tokenService = new TokenService();
        this.authService = new AuthService();
        this.quizService = new QuizService();
        this.userQuizDetailsService= new UserQuizDetailsService();
        this.DATAEncryptionKey = '6d090796-ecdf-11ea-adc1-0242ac112345'
    }

    createQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.data, this.DATAEncryptionKey);
        const quiz = await this.quizService.createQuiz(decryptedData);
        const { status } = quiz.response;

        const { message } = quiz.response;
        res.status(quiz.statusCode).send({ status, message });

    });

    updateQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.encryptedData, this.DATAEncryptionKey);
        const quiz = await this.quizService.updateQuizNew(decryptedData);
        const { status } = quiz.response;

        const { message } = quiz.response;
        res.status(quiz.statusCode).send({ status, message });

    });

    getQuizzes = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.id, this.DATAEncryptionKey);
        console.log('decryptedData', decryptedData)
        const quiz = await this.quizService.getQuizzes(decryptedData);
        const { status } = quiz.response;

        const { message,data } = quiz.response;
        const encryptedData=encryptData.encryptData(data,this.DATAEncryptionKey);
        res.status(quiz.statusCode).send({ status, message ,encryptedData});

    });

    getStudentQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.id, this.DATAEncryptionKey);
        console.log('decryptedData====', decryptedData)
        const quiz = await this.quizService.getStudentQuiz(decryptedData);
        const { status } = quiz.response;

        const { message,data } = quiz.response;
        const encryptedData=encryptData.encryptData(data,this.DATAEncryptionKey);
        res.status(quiz.statusCode).send({ status, message ,encryptedData});

    });
    
    submitUserQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.data, this.DATAEncryptionKey);
        console.log('decryptedData====', decryptedData)
        const quiz = await this.userQuizDetailsService.submitUserQuiz(decryptedData);
        const { status } = quiz.response;

        const { message } = quiz.response;
        res.status(quiz.statusCode).send({ status, message});

    });

    getOneQuiz = asyncWrapper(async (req, res) => {
        console.log('req.body.id', req.body)
        const decryptedData = decryptData.decryptData(req.body.id, this.DATAEncryptionKey);
        console.log('decryptedData', decryptedData)
        const quiz = await this.quizService.getOneQuiz(decryptedData.quizId);
        const { status } = quiz.response;

        const { message,data } = quiz.response;
        const encryptedData=encryptData.encryptData(data,this.DATAEncryptionKey);
        res.status(quiz.statusCode).send({ status, message ,encryptedData});

    });

    getScore = asyncWrapper(async (req, res) => {
        // console.log('req.body.id===', req.body)
        if(req.body.userId){

            const decryptedData = decryptData.decryptData(req.body.userId, this.DATAEncryptionKey);
            const quiz = await this.userQuizDetailsService.getScore(decryptedData);
            const { status } = quiz.response;
    
            const { message,data } = quiz.response;
            const encryptedData=encryptData.encryptData(data,this.DATAEncryptionKey);
            res.status(quiz.statusCode).send({ status, message ,encryptedData});
        }

    });

    getStudentQuizData = asyncWrapper(async (req, res) => {
            // console.log('studentId', studentId)
            const decryptedData=decryptData.decryptData(req.body.encryptedData,this.DATAEncryptionKey);
            const subjectId=await this.userSubjectService.getSubjectId(decryptedData.subject);
// return;
            const quiz = await this.userQuizDetailsService.getStudentQuizData(decryptedData.studentId, subjectId.response.data);
            const { status } = quiz.response;
            const { message,data } = quiz.response;
            console.log('quiz', quiz.response.data)
            const encryptedData=encryptData.encryptData(data,this.DATAEncryptionKey);
            res.status(quiz.statusCode).send({status, message ,encryptedData});
    });

    liveQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.encryptedData, this.DATAEncryptionKey);
        const quiz = await this.quizService.liveQuiz(decryptedData);
        const { status } = quiz.response;
        const { message } = quiz.response;
        res.status(quiz.statusCode).send({ status, message });

    });

    deleteQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.data, this.DATAEncryptionKey);
        const quiz = await this.quizService.deleteQuiz(decryptedData);
        const { status } = quiz.response;
        const { message } = quiz.response;
        res.status(quiz.statusCode).send({ status, message });

    });

}

module.exports = QuizController;