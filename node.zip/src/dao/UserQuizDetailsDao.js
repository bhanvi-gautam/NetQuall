const SuperDao = require('./SuperDao');
const models = require('../models');

const UserQuizDetails = models.userQuizDetails;

class UserQuizDetailsDao extends SuperDao {
    constructor() {
        super(UserQuizDetails);
    }
}
module.exports=UserQuizDetailsDao;