const SuperDao = require('./SuperDao');
const models = require('../models');
const { v4: uuidv4 } = require('uuid');

const UserMigration = models.userMigration;

class UserMigrationDao extends SuperDao {
    constructor() {
        super(UserMigration);
    }

    async addMigration(req){
        // console.log("req",req);
        try {
            const uuid = uuidv4();
        
        return await UserMigration.create({uuid:uuid, student_first_name: req.first_name, student_last_name: req.last_name,old_course_name:req.oldCourse,new_course_name:req.newCourse })
            
        } catch (error) {
            // logger.error(e);
            console.log(e);
            return [];
        }
        }
}
module.exports=UserMigrationDao;