const SuperDao = require('./SuperDao');
const models = require('../models');
const logger = require('../config/logger');

const userAssignment = models.userAssignment;
const userAssignDetails = models.userAssignDetails;
const userSubject = models.userSubject;
const user = models.user;

class UserAssignDetailsDao extends SuperDao {
    constructor() {
        super(userAssignDetails);
    }
   
}
module.exports = UserAssignDetailsDao;