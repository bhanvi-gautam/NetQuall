import React from "react";
import { BrowserRouter, Route, Routes, Navigate  } from "react-router-dom";

import "@fortawesome/fontawesome-free/css/all.min.css";
// import "./assets/styles";
import "./assets/styles/tailwind.css";

// layouts

import Admin from "./layouts/Admin.js";


// views without layouts

import Landing from "./views/Landing.js";
import Profile from "./views/Profile.js";

import ReactDOM from 'react-dom/client'

import { createRoot } from 'react-dom';
import Login from "./views/auth/Login.js";
import Register from "./views/auth/Register.js";
import Dashboard from "./views/admin/Dashboard.js";
import Maps from "./views/admin/Maps.js";
import Settings from "./views/admin/Settings.js";
import Tables from "./views/admin/Tables.js";
import ForgotPassword from "./views/auth/ForgotPassword.js";
import ResetPassword from "./views/auth/ResetPassword.js";
import { Provider } from "react-redux";
import { store } from "./components/rtk/store.js";
import CourseTable from "./components/course/CourseTable.js";

// Define your components such as Admin, Auth, Landing, Profile, Index

const App = () => {
  const routes = [
    { path: "/", element: <Admin /> },
    { path: "/profile", element: <Profile /> },
    // { path: "/auth/register", element: <Register /> },
    // { path: "/admin/dashboard", element: <Dashboard /> },
    { path: "/admin/maps", element: <Maps /> },
    // { path: "/admin/settings", element: <Settings /> },
    { path: "/course", element: <CourseTable/> },
  ];
  // console.log('token', token)
  const token = localStorage.getItem('token');

  return (
    <Provider store={store}>
    <BrowserRouter>
    {!token ? (
        <>
         <Routes>
            <Route path="/" element={<Landing/>} />
            <Route path="/login" element={<Login/>} />
            <Route path="/forgotPassword" element={<ForgotPassword/>} />
            <Route path="/resetPassword/:emailid" element={<ResetPassword />} />
          </Routes>
        </>
      ) : (
        <>
      <Routes>
        {routes.map((route, index) => (
          <Route key={index} path={route.path} element={route.element} />
        ))}
      </Routes>
      </>)}
    </BrowserRouter>
    </Provider>
  );
};

// Use createRoot to render the root of your React application
createRoot(document.getElementById('root')).render(<App />);
