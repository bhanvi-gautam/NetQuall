const SuperDao = require('./SuperDao');
const models = require('../models');
const { Op } = require('sequelize');
const logger = require('../config/logger');
const userCourse = models.userCourse;
const userSemester = models.userSemester;
const userSubject = models.userSubject;

class UserCourseDao extends SuperDao {
    constructor() {
        super(userCourse);
    }
    async getParticularEducation(courseId){
        
        return userCourse.findOne({
            where:{
                id: courseId
            },
            attributes: ['id', 'courseName'],
            include: [{
                model: userSemester,
                // required: false,
                attributes: ['id', 'semesterNo'],
                
                include: [{
                    model: userSubject,
                    attributes: ['id', 'subjectName'],
                }]
            }]
        })
            .then((result) => {
                return result;
            })
            .catch((e) => {
                logger.error(e);
                console.log(e);
            });
    }
    

    async getEducationList(requestWhere) {
        // let {where} = requestWhere;
        console.log(requestWhere);
        return userCourse.findAll({
            where:
                {courseName: {
                    [Op.startsWith]: requestWhere.search
                }}
            ,
            
            attributes: ['id', 'courseName'],
            include: [{
                model: userSemester,
                // required: false,
                attributes: ['id', 'semesterNo'],
                
                include: [{
                    model: userSubject,
                    attributes: ['id', 'subjectName'],
                    // required: false,
                    // where: {
                    //     subjectName: {
                    //         [Op.startsWith]: requestWhere
                    //     }
                    // },
                    
                }]
            }],
            order:requestWhere.sortBy.length===2 ?[requestWhere.sortBy] : [['id','ASC']],
        })
            .then((result) => {
                return result;
            })
            .catch((e) => {
                logger.error(e);
                console.log(e);
            });
    }


}

module.exports = UserCourseDao;
