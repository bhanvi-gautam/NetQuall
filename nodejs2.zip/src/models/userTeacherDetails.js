const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userTeacherDetails extends Model {
        
        static associate(models) {
            // define association here
            // userTeacherDetails.hasMany(models.userSubject,{foreignKey: 'userDetails_Id', targetKey: 'id' });
            userTeacherDetails.belongsTo(models.userSubject, { foreignKey: 'subject_id', targetKey: 'id' });
            userTeacherDetails.belongsTo(models.userCourse, { foreignKey: 'course_id', targetKey: 'id' });
            userTeacherDetails.belongsTo(models.user, { foreignKey: 'teacher_id', targetKey: 'id' });
            
            // userTeacherDetails.belongsTo(models.user, {foreignKey: 'user_Id' , targetKey: 'id' })
        }
    }

    userTeacherDetails.init(
        {
            uuid: DataTypes.UUID,
            // teacher_id:DataTypes.INTEGER,
            // subject_id:DataTypes.INTEGER,
            // course_id: DataTypes.INTEGER,


        },
        {
            sequelize,
            modelName: 'userTeacherDetails',
            underscored: false,
        },
    );
    return userTeacherDetails;
};