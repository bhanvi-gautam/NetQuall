import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter, Route, Routes, Navigate  } from "react-router-dom";

import "@fortawesome/fontawesome-free/css/all.min.css";
// import "./assets/styles";
import "./assets/styles/tailwind.css";

// layouts

import Admin from "./layouts/Admin.js";
import Auth from "./layouts/Auth.js";

// views without layouts

import Landing from "./views/Landing.js";
import Profile from "./views/Profile.js";
import Index from "./views/Index.js";

import { createRoot } from 'react-dom';
import Login from "./views/auth/Login.js";
import Register from "./views/auth/Register.js";
import Dashboard from "./views/admin/Dashboard.js";
import Maps from "./views/admin/Maps.js";
import Settings from "./views/admin/Settings.js";
import Tables from "./views/admin/Tables.js";

// Define your components such as Admin, Auth, Landing, Profile, Index

const App = () => {
  return (
    <BrowserRouter>
      <Routes>
        {/* Ensure that each Route has a valid component or element */}
        <Route path="/admin" element={<Admin />} />
        {/* Uncomment and add other routes with their components */}
         <Route path="/auth" element={<Auth />} /> 
         <Route path="/landing" element={<Landing />} /> 
        <Route path="/profile" element={<Profile />} />
         <Route path="/" element={<Index />} /> 
         <Route path="/auth/login"  element={<Login/>} />
            <Route path="/auth/register"  element={<Register/>} />
            <Route path="/admin/dashboard"  element={<Dashboard/>} />
            <Route path="/admin/maps"  element={<Maps/>} />
            <Route path="/admin/settings"  element={<Settings/>} />
            <Route path="/admin/tables"  element={<Tables/>} />
        {/* Redirect for first page */}
        {/* <Navigate  from="*" to="/" /> */}
      </Routes>
      {/* Ensure that any content outside Routes is valid */}
      
    </BrowserRouter>
  );
};

// Use createRoot to render the root of your React application
createRoot(document.getElementById('root')).render(<App />);
