const express = require("express");
const UserController = require("../controllers/UserController");
const UserValidator = require("../validator/UserValidator");
// const auth = require('../middlewares/auth');

const router = express.Router();
const auth = require("../middlewares/auth");
const userController = new UserController();
const userValidator = new UserValidator();

router.post("/upload", userController.uploadImage);
// router.post("/upload-pdf", userController.uploadPdf);
router.post("/course-id", userController.getCourseId);
router.post("/add-assignment", userController.addAssignment);
router.post("/get-assignment", userController.getAssignment);
router.post("/check-submission", userController.checkSubmission);
router.post("/get-marks", userController.getMarks);
// router.post('/search',userController.searching);
router.post("/student-exists", userController.studentVerify);
router.post("/get-user-count", userController.getUserCount);
// router.post("/requestFile", userController.requestFile);
// router.post('/viewDetails',userController.viewDetail);--->code commented and disturbed a lot!
// router.post('/viewFilteredDetails',userController.viewFilteredDetails);
router.post("/deleteUser", userController.deleteUser);
router.post("/deleteProfile", userController.deleteProfile);
router.post("/getUser", userController.viewUser);
router.post("/update-user", userController.updateUser);
router.post(
  "/email",
  userValidator.checkEmailValidator,
  userController.checkEmail
);
router.post("/enable-disable-user", userController.enableDisableUser);
router.post("/submission", userController.submission);
router.post("/message", userController.sendMessage);
// router.post('/phone-number', userValidator.checkEmailValidator, authController.phone-number);
router.post("/register", userController.register);
// router.post('/login', userValidator.userLoginValidator, userController.login);
router.put(
  "/change-password",
  userValidator.changePasswordValidator,
  userController.changePassword
);

module.exports = router;
