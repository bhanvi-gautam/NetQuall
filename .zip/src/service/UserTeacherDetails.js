const UserDao = require("../dao/UserDao");
// const UserTeacherDetailsDao = require("../dao/UserTeacherDetailsDao")
const UserSubject = require("./UserSubject")
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { response } = require('express');
const logger = require('../config/logger');
const httpStatus = require('http-status');
const {Op}=require('sequelize');
const UserSubjectDao = require("../dao/userSubjectDao");

class UserTeacherDetails {
    constructor() {
        // this.userTeacherDetailsDao = new UserTeacherDetailsDao();
        this.userSubjectDao = new UserSubjectDao();
    }
    getSubject = async (req) => {
        // try {
        //     const where = { teacher_id: req.teacherId, course_id: req.course_Id };
        //     // const where = { course_id: req.course_Id };\

        //     console.log('where', where)
        //     const temp = await this.userTeacherDetailsDao.findByWhere(where, ['subject_id']);
        //     console.log("temp==",temp);

        //     const subjectId = temp?.map(message => {
        //         return message.dataValues.subject_id;
        //     });
        //     const whereClause={
        //         id: {
        //             [Op.in]: subjectId
        //         },
        //     }

        //     const subName = await this.userSubjectDao.findByWhere(whereClause, ['subjectName']);

        //     const subArray=subName?.map(message => {
        //         return message.dataValues.subjectName;
        //     });
        //     const abc={
        //         subjects:subArray
        //     }
        //     if (subArray) {
        //         return responseHandler.returnSuccess(httpStatus.OK, 'subject fetched successfully',abc);
        //     }

        // } catch (e) {
        //     logger.error(e);
        //     return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR, 'Error fetching subject');
        // }

    }


}



module.exports = UserTeacherDetails;