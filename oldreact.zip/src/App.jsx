import { BrowserRouter, Routes, Route } from "react-router-dom";

// import Alert from 'react-bootstrap/Alert';
import Login from "./Components/Login";
import Navbar from "./Components/Navbar";
import AddUser from "./Components/AddUser";
import UsersList from "./Components/UsersList";
import Customer from "./Components/Customer";
import EditForm from "./Components/EditForm";
import ForgotPassword from "./Components/ForgotPassword";
import ChangePassword from "./Components/ChangePassword.jsx";
import ChangePassNew from "./Components/ChangePassNew.jsx";
import MyAccount from "./Components/MyAccount.jsx";
import Teachers from "./Components/Teachers"
import Student from "./Components/Student"
import Sidebar from "./Components/Sidebar";
import WelcomePage from "./Components/WelcomePage";
import Education from "./Components/Education";
import EditUserForm from "./Components/EditUserForm";
import DragAndDrop from "./Components/DragDrop.jsx";

const routes = [
  { path: "/", element: <WelcomePage /> },
  { path: "/courses", element: <Education /> },
  { path: "/users", element: <UsersList /> },
  { path: "/addUser", element: <AddUser /> },
  { path: "/addCourses", element: <Customer /> },
  { path: "/viewUser", element: <UsersList /> },
  { path: "/viewCourses", element: <Education /> },
  { path: "/myaccount", element: <MyAccount/> },
  { path: "/viewTeacher", element: <Teachers /> },
  { path: "/viewStudent", element: <Student /> },
  { path: "/addEducation", element: <Education /> },
  { path: "/changePass1", element: <ChangePassNew /> },
  { path: "/addEducation/editCourse/:courseId", element: <EditForm /> },
  { path: "/addUser/editUser/:userId", element: <EditUserForm /> },
  { path: "/addUser/dragDrop", element: <DragAndDrop/> },

];

const App = () => {

  const token = localStorage.getItem('token');
  // const [show, setShow] = useState(true);

  return (
    <BrowserRouter>

      {!token ? (
        <>
         <Routes>
            <Route path="/" element={<Login/>} />
            <Route path="/forgotPassword" element={<ForgotPassword />} />
            <Route path="/change-password/:email" element={<ChangePassword />} />
          </Routes>
        </>
      ) : (


        <>
          <Navbar />
          {/* <Alert variant="success" onClose={() => setShow(false)} dismissible>Welcome!</Alert> */}
          <div className="container-fluid">
            <div className="row">
              <div className="col-2" style={{ backgroundColor: "#f0f0f0" }}>
                <Sidebar />
              </div>
              <div className="col-10">
              <div style={{ padding: "15px" }}>
                <Routes>
                  {/* <Route path='/' element ={<WelcomePage />}/> */}
                  {routes.map((route, index) => (
                    <Route
                      key={index}
                      path={route.path}
                      element={route.element}
                    />
                  ))}
                </Routes>
                </div>
              </div>
            </div>
          </div>
        </>
      )}
    </BrowserRouter>
  );
}

export default App

