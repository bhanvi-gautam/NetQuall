import React, { useState } from "react";
import RemoveIcon from '@mui/icons-material/Remove';
import AddIcon from '@mui/icons-material/Add';
import { useAddNewPostMutation } from "./rtk/AddSlice";
import { useNavigate } from "react-router-dom";
import { Button, TextField, Grid, IconButton } from "@mui/material";
import CryptoJS from 'crypto-js';


const Form = () => {
  let navigate = useNavigate();
  const [formData, setFormData] = useState({ courseName: "", semester: [] });
  const [semesterField, setSemesterField] = useState([
    {
      sem: 0,
      subject: [{ subjectName: "" }],
    },
  ]);
  const [addNewPost] = useAddNewPostMutation();
  const addSemester = () => {
    const newSemesterField = {
      sem: 0,
      subject: [{ subjectName: "" }],
    };
    setSemesterField([...semesterField, newSemesterField]);
  };

  const secretKey = '6d090796-ecdf-11ea-adc1-0242ac112345';
    const encryptData = (data) => {
        const encryptedData = CryptoJS.AES.encrypt(JSON.stringify(data), secretKey).toString();
        return encryptedData;
    };

    const decryptData = (encryptedData) => {
        console.log("temp1===", encryptedData);
        const decryptedData = CryptoJS.AES.decrypt(encryptedData, secretKey).toString(CryptoJS.enc.Utf8);
        let decryptedObject;
        try {
            decryptedObject = JSON.parse(decryptedData);
            console.log("decryptedObject==", decryptedObject);
        } catch (error) {
            // Handle JSON parsing error if needed
            console.error('Failed to parse decrypted data:', error);
            return null;
        }
        return decryptedObject;
    };

  const addSubjects = (index) => {
    const newSubjectField = { subjectName: "" };
    const data = [...semesterField];
    data[index].subject = [...data[index].subject, newSubjectField];
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };

  const removeSubject = (semesterIndex, subjectIndex) => {
    if (subjectIndex > 0) {
      const data = [...semesterField];
      data[semesterIndex].subject.splice(subjectIndex, 1);
      setSemesterField(data);
    }
  };

  const removeSemester = (semesterIndex) => {
    if (semesterIndex > 0) {
      const data = [...semesterField];
      data.splice(semesterIndex, 1);
      setSemesterField(data);
    }
  }


  const handleSemesterChange = (index, e) => {
    let data = [...semesterField];
    data[index][e.target.name] = e.target.value;
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };

  const handleSubjectChange = (index1, index2, e) => {
    let data = [...semesterField];
    data[index1].subject[index2][e.target.name] = e.target.value;
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    const courseName = e.target.elements.courseName.value;
    let id= localStorage.getItem('userId');
    const updatedFormData = {
      ...formData,
      courseName,
      "userID": id,
      "user_Id": id,
    };

    const encryptedData=encryptData(updatedFormData);
    await addNewPost({updatedFormData:encryptedData}).unwrap();

    setFormData({ courseName: "", semester: [] });
    setSemesterField([
      {
        sem: 0,
        subject: [{ subjectName: "" }],
      },
    ]);
    navigate('/viewCourses');
  };



  return (
    <div className="container">
      <div className="row">
        <div className="col-12">
          <h1>Get details</h1>
        </div>
      </div>
      <form onSubmit={handleSubmit}>
      <Grid container spacing={2}>
            <Grid item xs={12}>
              <TextField
                id="courseName"
                label="Course Name"
                name="courseName"
                variant="standard"
                fullWidth
                required
                onChange={(e) =>
                  setFormData({ ...formData, courseName: e.target.value })
                }
              />
            </Grid>
            {semesterField.map((semester, index1) => (
              <Grid item xs={12} sm={6} key={index1}>
                <TextField
                  id={`sem-${index1}`}
                  label="Semester No"
                  type="number"
                  name="sem"
                  value={semester.sem}
                  onChange={(e) => handleSemesterChange(index1, e)}
                  variant="standard"
                  fullWidth
                  required
                />
                <IconButton color="primary" onClick={() => addSemester()}>
                  <AddIcon />
                </IconButton>
                {semesterField.length > 1 && (
                  <IconButton
                    color="secondary"
                    onClick={() => removeSemester(index1)}
                  >
                    <RemoveIcon />
                  </IconButton>
                )}
                {semester.subject.map((sub, index2) => (
                  <Grid container spacing={2} key={index2}>
                    <Grid item xs={12}>
                      <TextField
                        id={`subjectName-${index1}-${index2}`}
                        label="Subject Name"
                        name="subjectName"
                        value={sub.subjectName}
                        onChange={(e) => handleSubjectChange(index1, index2, e)}
                        variant="standard"
                        fullWidth
                        required
                      />
                      <IconButton
                        color="primary"
                        onClick={() => addSubjects(index1)}
                      >
                        <AddIcon />
                      </IconButton>
                      {semester.subject.length > 1 && (
                        <IconButton
                          color="secondary"
                          onClick={() => removeSubject(index1, index2)}
                        >
                          <RemoveIcon />
                        </IconButton>
                      )}
                    </Grid>
                  </Grid>
                ))}
              </Grid>
            ))}
            <Grid item xs={12}>
              <Button
                type="submit"
                variant="contained"
                color="primary"
                fullWidth
              >
                Submit
              </Button>
            </Grid>
          </Grid>
   
      </form>
    </div>


  );
};

export default Form;
