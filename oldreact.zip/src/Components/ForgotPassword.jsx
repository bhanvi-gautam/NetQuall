import { React, useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import Timer from './Timer';
import CryptoJS from 'crypto-js';
import { useVerifyEmailMutation, useVerifyOTPMutation, useClearOTPMutation } from './rtk/AddSlice';

const ForgotPassword = () => {
    let navigate = useNavigate();
    const [sendEmail, { isLoading, isSuccess, isError }] = useVerifyEmailMutation();
    const [sendOtp] = useVerifyOTPMutation();
    const [clearOTP] = useClearOTPMutation();
    const [show, setShow] = useState(false);
    const [email, setEmail] = useState('');
    const secretKey = '6d090796-ecdf-11ea-adc1-0242ac112345';

    const encryptData = (data) => {
        const encryptedData = CryptoJS.AES.encrypt(JSON.stringify(data), secretKey).toString();
        return encryptedData;
    };

    const decryptData = (encryptedData) => {
        // console.log("temp1===", encryptedData);
        const decryptedData = CryptoJS.AES.decrypt(encryptedData, secretKey).toString(CryptoJS.enc.Utf8);
        let decryptedObject;
        try {
            decryptedObject = JSON.parse(decryptedData);
            // console.log("decryptedObject==", decryptedObject);
        } catch (error) {
            // Handle JSON parsing error if needed
            console.error('Failed to parse decrypted data:', error);
            return null;
        }
        return decryptedObject;
    };


    const handleOtp = async (e) => {
        e.preventDefault();
        let OTP = e.target.elements.otp.value;
        // console.log("emailCheck===", email);
        try {
            const temp={ email: email, otp: OTP };
            const encryptedData=encryptData(temp);
            console.log("temp===",encryptedData);
            const check = await sendOtp({temp:encryptedData}).unwrap();
            console.log(check);

            if (check) {
                navigate(`/change-password/${email}`);

            }


            else {
                window.alert('Wrong OTP');
            }
        } catch (error) {
            console.error(error);
            window.alert('Wrong OTP');
        }
        // console.log(OTP);
    }

    const handleSubmit = async (e) => {
        e.preventDefault();

        // email = e.target.elements.email.value;
        console.log(email);
        try {
            const encryptedData = encryptData({email:email});
            const verify = await sendEmail(encryptedData).unwrap();
            //timer of 50sec ... n after refresh also same
            setTimeout(async () => {
                const encryptedData1 = encryptData({email:email});
                await clearOTP({email:encryptedData1});
            }, 60000);
            console.log(verify);
            if (verify.code === 200) {
                console.log("hie");
                setShow(true);
            }
            else {
                window.alert('Error sending email');
            }
        } catch (error) {
            console.error(error);
            window.alert('Error sending email');
        }

    }

    useEffect(() => {

    }, [show]);
    return (
        <div>
            <h1>Hello</h1>
            <h1>Enter your Registered Email address</h1>

            <form onSubmit={handleSubmit} className='formStyle'>

                <div className="form-outline mb-4">
                    <input type="email" className="form-control" name="email" onChange={(e) => setEmail(e.target.value)} />
                    <label className="form-label" htmlFor="form2Example1">
                        Email address
                    </label>
                </div>

                <div>
                    <button type="submit" className="btn btn-primary btn-block mb-4">
                        Send OTP
                    </button>
                </div>
            </form>
            {show &&
                <>
                    <form onSubmit={handleOtp} className='formStyle'>
                        <div className="form-outline mb-4">
                            <input type="text" className="form-control" name="otp" />
                            <label className="form-label" htmlFor="form2Example1">
                               <span> Enter OTP</span> <span><Timer/></span>
                            </label>
                        </div>
                        <button type='submit' className="btn btn-primary btn-block mb-4">Verify</button>
                    </form>
                </>

            }



        </div>
    )
}

export default ForgotPassword
