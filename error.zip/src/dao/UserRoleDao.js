const SuperDao = require('./SuperDao');
const models = require('../models');

const UserRole = models.userRole;

class UserRoleDao extends SuperDao {
    constructor() {
        super(UserRole);
    }
}
module.exports=UserRoleDao;