const SuperDao = require('./SuperDao');
const models = require('../models');
const logger = require('../config/logger');
const Sequelize = require('sequelize');


const userAssignment = models.userAssignment;
const userAssignDetails = models.userAssignDetails;
const userSubject = models.userSubject;
const user = models.user;

class UserAssignmentDao extends SuperDao {
    constructor() {
        super(userAssignment);
    }
    async findStudentAssignment(req) {
        try {
            console.log('req34232', req)
            const result = await userAssignment.findAll({
                where: req.assign_Id ?
                        {
                            assign_Id: req.assign_Id
                        } : {},
                attributes: ['id', 'assignment', 'deadlineDate', 'deadlineTime', 'status','assign_Id','submission','marks'],
                include: [{
                    model: userAssignDetails,
                    attributes: ['id', 'AssignName'],
                },{
                    model: user,
                    where: req.user_Id ?
                        {
                            id: req.user_Id
                        } : {},
                    attributes: ['id', 'first_name', 'last_name'],
                }, {
                    model: userSubject,
                    where: req.subject ?
                        {
                            subjectName: req.subject
                        } : {},
                    attributes: ['id', 'subjectName']
                },
                // {
                //     model:userAssignment,
                //     as:'Children',
                //     where: {
                //         assign_Id: Sequelize.col('userAssignment.assign_Id'),
                //     }
                // }
                ]
            });
            return result;
        } catch (error) {
            logger.error(error);
            throw error;
        }

    }


    async findAssignment(req) {
        try {
            console.log('req34232', req)
            console.log('object', req.status)
            const result = await userAssignment.findAll({

                where: req.status!==-1 ?
                    {
                        status: req.status
                    } : {},
                attributes: ['id', 'assignment', 'deadlineDate', 'deadlineTime', 'status','assign_Id','submission'],
                include: [{
                    model: userAssignDetails,
                    attributes: ['id', 'AssignName'],
                },{
                    model: user,
                    where: req.user_Id ?
                        {
                            id: req.user_Id
                        } : {},
                    attributes: ['id', 'first_name', 'last_name'],
                }, {
                    model: userSubject,
                    where: req.subject ?
                        {
                            subjectName: req.subject
                        } : {},
                    attributes: ['id', 'subjectName']
                },
                ]
            });
            return result;
        } catch (error) {
            logger.error(error);
            throw error;
        }

    }


    async allData() {
            // return userAssignment.findAll({
            //     include: [{
            //         model: userAssignment,
            //         as: 'Children'
            //     }]
            // }).then(userAssignments => {
            //     console.log("123333===",userAssignments);
            //     return userAssignments;
            // }).catch(error => {
            //     console.error(error);
            // });
            
    }
}
module.exports = UserAssignmentDao;