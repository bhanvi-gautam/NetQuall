import React, { useState } from 'react'
// Import the styles
import '@react-pdf-viewer/core/lib/styles/index.css';
import '@react-pdf-viewer/default-layout/lib/styles/index.css';
import './PdfUploader.css';
import { useUploadImageMutation, useAddAssignmentMutation } from '../../rtk/AddSlice';
import { decryptData, encryptData } from '../../../assets/security/encryDecrypt';
import Divider from '@mui/material/Divider';

export const PdfUploader = ({ subject, handleCloseParent }) => {

    const [pdfFile, setPdfFile] = useState(null);
    const [name, setName] = useState('');
    const [fileSize, setFileSize] = useState(1);
    const [uploadImage] = useUploadImageMutation();
    const [addData] = useAddAssignmentMutation();
    const [pdfFileError, setPdfFileError] = useState('');
    const [deadlineDate, setDeadlineDate] = useState();
    const [fileName, setFileName] = useState('');
    const [deadlineTime, setDeadlineTime] = useState();
    const [fileId, setFileId] = useState("");
    const encryptedId = localStorage.getItem('userId');
    const userId = decryptData(encryptedId);
    const [file, setFile] = useState();
    const status = 0;

    // onchange event
    const fileType = ['application/pdf'];
    const handlePdfFileChange = (e) => {
        let selectedFile = e.target.files[0];
        if (selectedFile) {
            if (selectedFile && fileType.includes(selectedFile.type)) {
                let reader = new FileReader();
                reader.readAsDataURL(selectedFile);
                reader.onloadend = (e) => {
                    setFile(selectedFile);
                    setPdfFile(e.target.result);
                    setPdfFileError('');
                    setFileName(selectedFile.name);
                    setFileSize(selectedFile.size);
                }
            }
            else {
                setPdfFile(null);
                setPdfFileError('Please select valid pdf file');
            }
        }
        else {
            console.log('select your file');
        }
    }

    // form submit
    const handlePdfFileSubmit = async (e) => {
        e.preventDefault();
        console.log("hie")
        let assignment = ""
        if (fileName) {
            const extension = file.name.split(".");
            const temp = extension[1];
            console.log('extension', temp)

            const start = 0;
            const end = fileSize;
            const fileData = new FormData();
            fileData.append("file", file);
            await uploadImage({
                y: temp,
                x: fileData,
                z: `bytes=${start}-${end}/${fileSize}`,
            }).then((result) => {
                console.log('result', result.data.data)
                assignment = result.data.data;
            }).catch((err) => {
                console.log('err', err)
            });
        }
        console.log('assignment', assignment)
        const data = { deadlineDate, deadlineTime, assignment, userId, status, subject, name };
        // return;
        try {
            const encryptedData = encryptData(data);
            await addData({ data: encryptedData }).then((fetchPt) => {
                handleCloseParent(100);
            });
        } catch (error) {
            console.error("Error in upload or add operations", error);
        }
    }
    // console.log('deadline', deadlineDate)
    return (
        <div className='container'>
            <form className='form-group' onSubmit={handlePdfFileSubmit}>
                <div className='container1'>
                    <label htmlFor="name">Choose Assignment to Upload:</label>
                    <input type="file" className='form-control'
                        required onChange={handlePdfFileChange}
                    />
                </div>
                {pdfFileError && <div className='error-msg'>{pdfFileError}</div>}


                <Divider variant="middle" />

                <div className='container'>
                    <label htmlFor="name">Name of Assignment:</label>
                    <input type="text" name="name"
                        className='form-control' required onChange={(e) => setName(e.target.value)}
                    />
                </div>

                <Divider variant="middle" />

                <div className='container'>
                    <label htmlFor="date">Deadline Date for Submission:</label>
                    <input type="date" name="date"
                        className='form-control' required onChange={(e) => setDeadlineDate(e.target.value)}
                        min={new Date().toISOString().split("T")[0]}
                    />
                </div>

                <Divider variant="middle" />

                <div className='container'>
                    <label htmlFor="time">End Time for Submission on the Last Day:</label>

                    <input type="time" name="time"
                        className='form-control' required onChange={(e) => {
                            setDeadlineTime(e.target.value);
                        }
                        }
                    />
                </div>

                <Divider variant="middle" />


                <button type="submit" className='upload' disabled={pdfFileError || !deadlineDate || !deadlineTime || name === '' ? true : false}>
                    UPLOAD
                </button>

            </form>

        </div>
    )
}

export default PdfUploader