import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useGetPostsMutation, useDeletePostMutation } from "../rtk/AddSlice";
import { encryptData, decryptData } from "../../assets/security/encryDecrypt";
import CardTable3 from "../Cards/CardTable3";
import TableShimmer from "../Effects/TableShimmer";
import { Box, Button, Typography } from "@mui/material";
import { useSelector } from "react-redux";
import { InputAdornment, TextField } from "@mui/material";
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import KeyboardArrowUpIcon from '@mui/icons-material/KeyboardArrowUp';
import SearchIcon from "@mui/icons-material/Search";
import { notifySuccess } from "../../toast";
import { ToastContainer } from "react-toastify";

const Education = () => {
  const [getdata, { isLoading, isSuccess, post }] = useGetPostsMutation();
  const [posts, setPosts] = useState(post);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState([]);
  const[asc,setAsc]=useState(false);
  const[desc,setDesc]=useState(false);
  // const [count,setCount]=useState(0);
  const count=useSelector((state)=>state.token.count)
  console.log('count', count)
  const handleSortParent = (value) => {
    setSortBy(value);
  };

  
  const handleCountParent=(value)=>{
    console.log('hie')
    if(count%3===0){
      setSortBy("");
      setAsc(false);
      setDesc(false);
    }
    else if(count%3===1){
      setSortBy(["courseName", "asc"]);
      setAsc(true);
      setDesc(false);
    }
    else{
      setSortBy(["courseName", "desc"]);
      setDesc(true);
      setAsc(false);
    }
  }

  const filteredData = async (value) => {
    const fetchPosts = await getdata({
      search: search,
      sortBy: sortBy,
    }).unwrap();
    const temp = decryptData(fetchPosts.data);
    setPosts(temp);
    if(value){
      console.log('value', value)
      // try{
        notifySuccess("Data Deleted!")
      // }catch(error){

      // }
    }
  };

  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    handleSearchParent(search);
  };


  useEffect(() => {
    filteredData();
    console.log("123344")
  }, [sortBy, search]);

  const handleSearchParent = (value) => {
    setSearch(value);
  };
  console.log("sortBy", sortBy);
  console.log("search", search);

  console.log("posts", posts);
  return (
    <>
      <Box className="w-full mb-12">
        <Box className= "relative md:pt-30 pb-32 pt-12"  style={{backgroundColor:'#0099CC'}}>
        <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
            style={{display:"flex" ,justifyContent:"space-between"}}
          >
            <Typography gutterBottom variant="h4" component="div" style={{marginBottom:'-5px'}} >
              List of Courses
            </Typography>
            <form className="flex">
                <TextField
                  className="form-control mr-2"
                  type="search"
                  placeholder="Search by Course"
                  aria-label="Search"
                  value={search}
                  margin="dense"
                  onChange={handleSearchChange}
                  sx={{
                    backgroundColor: 'white',
                  }}
                  style={{borderRadius:'4px', margin:'4px'}}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon />
                      </InputAdornment>
                    ),
                  }}
                />
                <Button
                  type="submit"
                  variant="contained"
                  color="success"
                  onClick={handleSearch}
                  style={{margin:'4px', height: '50px',width:'35px', borderRadius:'2px'}}
                >
                  Search
                </Button>
              </form>
          </Box>
        </Box>
        {isLoading && <TableShimmer />}

        {isSuccess && (
          <div
            className="relative pb-32"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >
            <CardTable3
              content={posts}
              errorMessg={"No Courses available"}
              handleSortParent={handleSortParent}
              handleCountParent={handleCountParent}
              Icon={asc ? <KeyboardArrowUpIcon/> : desc ? <KeyboardArrowDownIcon/> : null}
              filteredData={filteredData}
            />
          </div>
        )}
      </Box>
      <ToastContainer containerId="A"/>
    </>
  );
};

export default Education;
