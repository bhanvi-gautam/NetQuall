import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Popover from '@mui/material/Popover';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import DeleteIcon from '@mui/icons-material/Delete';
import NoDataFound from "./NoDataFound";
import dummyProfile from "../../assets/img/dummyProfile.png";
import { encryptData } from '../../assets/security/encryDecrypt';
import QuizRoundedIcon from '@mui/icons-material/QuizRounded';
import { useSubmissionMutation } from "../rtk/AddSlice";
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import ArticleRoundedIcon from '@mui/icons-material/ArticleRounded';
import { Box, Divider, Fade, List, ListItemButton, ListItemIcon, ListItemText, Paper, Popper } from "@mui/material";

export default function CardTable4({
    title,
    content,
    heading,
    errorMessg,
    subject

}) {
    const [anchorEl, setAnchorEl] = useState(null);
    const [sendData] = useSubmissionMutation();
    const [clicked, setClicked] = useState(false);
    const [marks, setMarks] = useState(null);
    const [error, setError] = useState(null);
    const [openId, setOpenId] = useState(null);

    const handleClick = (id) => (event) => {
        setAnchorEl(event.currentTarget);
        setOpenId(prev => prev !== id ? id : null);
      };

    useEffect(() => {

    }, [clicked])

    const [id, setId] = useState();
    let navigate = useNavigate();
    const handleAssignmentSubmission = async (e, id) => {

        e.preventDefault();
        if (marks !== null) {
            setClicked(true);
            const payload = { id: id, marks: marks };
            const encryptedData = encryptData(payload);
            await sendData(encryptedData).unwrap();
        } else {
            setError('Please enter marks before accepting the assignment');
        }
    }

    let flag = 0;
    console.log('content', content)
    return (
        <>

            <div className="block w-full overflow-x-auto">
                {/* Projects table */}
                <table className="items-center w-full bg-transparent border-collapse">
                    <thead>
                        <tr>
                            {heading?.map((data) => (
                                <th
                                    className={
                                        "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                                    }
                                >
                                    {data}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {content?.map((data, index) => {
                            if (data.is_available === 1) {
                                flag++;
                                return (
                                    <tr key={index}>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.profile ? (
                                                <img
                                                    src={`http://localhost:3003/images/${data.profile}`}
                                                    width="100"
                                                    height="100"
                                                    style={{ borderRadius: '50%' }}
                                                />
                                            ) : (
                                                <img src={dummyProfile} width="100" height="100" style={{ borderRadius: '50%' }} />
                                            )}
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.first_name + " " + data.last_name}
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.email}
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4" >
                                            {/* <Link to={`/viewStudentUnderTeacher/${subject}/${data.id}`}><ArrowForwardIosIcon /></Link> */}
                                            <Popper
                                                sx={{ zIndex: 1200 }}
                                                open={openId === data.id}
                                                anchorEl={anchorEl}
                                                placement='right-start'
                                                transition
                                            >
                                                {({ TransitionProps }) => (
                                                    <Fade {...TransitionProps} timeout={350}>
                                                        <Box sx={{ width: '100%', maxWidth: 360, bgcolor: 'background.paper' }}>
                                                            <List component="nav" aria-label="main mailbox folders">
                                                            <Link to={`/viewStudentUnderTeacher/${subject}/${data.id}`}>
                                                                <ListItemButton>
                                                                    <ListItemIcon>
                                                                        <ArticleRoundedIcon />
                                                                    </ListItemIcon>
                                                                    <ListItemText primary="Assignments" />
                                                                </ListItemButton>
                                                                </Link>
                                                                <Divider />
                                                                <Link to={`/viewStudentUnderTeacherQuiz/${subject}/${data.id}`}>
                                                                <ListItemButton>
                                                                    <ListItemIcon>
                                                                        <QuizRoundedIcon />
                                                                    </ListItemIcon>
                                                                    <ListItemText primary="Quizzes" />
                                                                </ListItemButton>
                                                                </Link>
                                                            </List>
                                                        </Box>
                                                    </Fade>
                                                )}
                                            </Popper>
                                            <Button onClick={handleClick( data.id)}><ArrowForwardIosIcon /></Button>
                                        </td>
                                    </tr>
                                )
                            }
                        })}
                    </tbody>
                </table>
                {flag === 0 && <NoDataFound content={errorMessg} />}
            </div>
        </>
    );
}
// what is going wrong i want popover to close when clicked outside the popover and also to each row has different popover and not affected by each other, at a time at most one popover is open 