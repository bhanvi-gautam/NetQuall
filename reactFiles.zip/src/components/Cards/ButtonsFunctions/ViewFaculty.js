import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import LockIcon from "@mui/icons-material/Lock";
import { useGetUserSubjectMutation } from "../../rtk/AddSlice";
import {decryptData,encryptData} from "../../../assets/security/encryDecrypt";
import CardTable from "../CardTable";
import CardShimmer from "../../Effects/CardShimmer";

const ViewFaculty = () => {
  const { courseId } = useParams();
  const [getdata, { isLoading, isSuccess, post }] = useGetUserSubjectMutation();
  const [posts, setPosts] = useState(post);

  // const courseId = decryptData(course_Id);
  console.log(courseId);

  const abc = async () => {
    const payload={courseId:courseId, roleId:'2'}
    // const encryptedData=encryptData(payload);
    const fetchPosts = await getdata(payload).unwrap();
    // const temp = decryptData(fetchPosts.data);
console.log('fetchPosts', fetchPosts)
    // setPosts(temp);
    setPosts(fetchPosts);
  };

  useEffect(() => {
    abc();
  }, []);
console.log("posts===",posts?.data)
  return (
    <>
      <div className="w-full mb-12 px-4">
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className= "relative md:pt-30 pb-32 pt-12"  style={{backgroundColor:'#0099CC'}}
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <CardTable
              title={"List of Faculty Members"}
              content={posts?.data}
              heading={[
                "Profile",
                "Faculty Name",
                "Email",
                "Subject",
                "Semester No",
              ]}
              role={2}
              errorMessg={"No Faculty available for this Course yet!"}
            />
          </div>
        )}
      </div>
    </>
  );
};

export default ViewFaculty;
