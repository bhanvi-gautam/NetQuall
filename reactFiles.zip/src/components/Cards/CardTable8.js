import React, { useEffect, useState } from "react";
import Box from '@mui/material/Box';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Modal from '@mui/material/Modal';
import DeleteIcon from '@mui/icons-material/Delete';
import NoDataFound from "./NoDataFound";
import EditIcon from '@mui/icons-material/Edit';
import { encryptData } from '../../assets/security/encryDecrypt';
import { useDeleteQuizMutation, useQuizLiveMutation } from "../rtk/AddSlice";
import { Link } from "react-router-dom";

export default function CardTable8({ content, errorMessg, getQuizData, subject, heading }) {

    const [quizLive] = useQuizLiveMutation();
    const [show, setShow] = useState(false);
    const [deleteQuiz] = useDeleteQuizMutation();
    const [open, setOpen] = useState(true)
    const [editingQuizId, setEditingQuizId] = useState(null);

    const openEdit = (id) => {
        setEditingQuizId(id)
    };

    const handleEditClose = () => setOpen(false);

    const handleLive = async (id, available) => {
        console.log('id', id);
        const encryptedData = encryptData({ id: id, availability: available });
        quizLive({ encryptedData }).unwrap().then((data) => {
            if (available) {
                getQuizData("Quiz NOT LIVE now!")
            } else {
                getQuizData("Quiz LIVE now!")
            }
        }).catch((error) => {
            console.log(error);
        })
    }



    const verifyDelete = (id) => setShow(!show);

    const handleClose = () => setShow(false);

    const handleDelete = async (id) => {
        console.log('id', id)
        const encryptedId = encryptData(id);
        deleteQuiz({ data: encryptedId }).unwrap().then((data) => {
            getQuizData("Quiz Deleted");
        }).catch((error) => {
            console.log(error);
        })
    }

    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 400,
        bgcolor: 'background.paper',
        border: '2px solid #000',
        boxShadow: 24,
        p: 4,
    };


    let flag = 0;
    return (
        <>
            <div className="block w-full overflow-x-auto">
                <table className="items-center w-full bg-transparent border-collapse">
                    <thead>
                        <tr>
                            {heading?.map((data) => (
                                <th
                                    className={
                                        "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                                    }
                                >
                                    {data}
                                </th>
                            ))}
                        </tr>
                    </thead>
                    <tbody>
                        {content?.map((data, index) => {
                            flag++;
                            return (
                                <tr key={index}>
                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        {data.quizName}
                                    </td>
                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        {subject}
                                    </td>
                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        {data.quiz_marks}
                                    </td>

                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4" >

                                       {data.is_available ?  <EditIcon/>: <Link to={`/viewAllQuizzes/edit/${data.id}`}><EditIcon/></Link>} 
                                       {data.is_available ?  <DeleteIcon/>: <DeleteIcon onClick={() => verifyDelete(data.id)}/>} 
                                      

                                        {show &&
                                            <>
                                                <Modal
                                                    open={show}
                                                    onClose={handleClose}
                                                    aria-labelledby="modal-modal-title"
                                                    aria-describedby="modal-modal-description"
                                                >
                                                    <Box sx={style}>
                                                        <Typography id="modal-modal-title" variant="h6" component="h2">
                                                            Are you sure you want to delete this Quiz?
                                                        </Typography>
                                                        <Typography id="modal-modal-description" sx={{ mt: 2 }}>
                                                            <Button variant="contained" color="error" onClick={handleClose}>Cancel</Button>{" "}
                                                            <Button variant="contained" color="success" onClick={() => handleDelete(data.id)}>Yes</Button>
                                                        </Typography>
                                                    </Box>
                                                </Modal>
                                            </>
                                        }
                                    </td>

                                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        {data.is_available === 1 ? <Button variant="contained" color="success">LIVE</Button> : <Button variant='outlined' color="error" onClick={() => handleLive(data.id, 0)}>NOT LIVE</Button>}
                                    </td>
                                </tr>
                            )
                        })}


                    </tbody>
                </table>

                {flag === 0 && <NoDataFound content={errorMessg} />}
            </div>

        </>
    );
}