import React, { useState, useEffect } from "react";
import { useGetSubjectsMutation } from "../../rtk/AddSlice";
import { MenuItem, Grid } from "@mui/material";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";
import { decryptData } from "../../../assets/security/encryDecrypt";

const SubjectDropDown = ({ title, course, onSubjectChange }) => {
    const [subject, setSubject] = useState(0);
    const [getData, { post1 }] = useGetSubjectsMutation();
    const [posts, setPosts] = useState(post1);
    const [subArray, setSubArray] = useState([])

    const handleChange = (e) => {
        e.preventDefault();
        const selectedSubject = e.target.value;
        setSubject(selectedSubject);
        onSubjectChange(selectedSubject);
    };

    const filteredData = async () => {
        try {
            const fetchPosts = await getData({ course }).unwrap();
            const temp = decryptData(fetchPosts.data);
            let newPosts = [];
            temp?.forEach((data) => {
                data?.forEach((data1) => {
                    newPosts.push(data1.subjectName);
                });
            });
            setPosts(newPosts);
        } catch (error) {
            console.log(error);
        }
    };

    useEffect(() => {
        filteredData();
    }, [course]);
    console.log('posts', posts)



    // console.log('subArray', subArray)

    return (
        <form>
            <Grid item xs={12}>
                <InputLabel id="demo-simple-select-label">{title}</InputLabel>
                <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={subject}
                    label="Subject"
                    size={"small"}
                    onChange={handleChange}
                    defaultValue="Select-a-Subject"
                    style={{ minWidth: 320 }}
                >
                    {posts?.map((data, index) => {                            
                            return <MenuItem value={data} key={index}>{data}</MenuItem>;
                    })}
                </Select>
            </Grid>
        </form>
    );
};

export default SubjectDropDown;