import React, { useEffect, useState } from 'react'
import { useNavigate, useParams } from 'react-router-dom'
import { useGetOneQuizMutation, useSubmitUserQuizMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import { Button, Grid, Stack, Typography, Box, FormControlLabel, Radio, Checkbox, Chip } from '@mui/material';
import { styled } from '@mui/material/styles';
import Paper from '@mui/material/Paper';
import Loading from '../../views/auth/Parts/Loading';
import Timer from './Parts/Timer'
import { pink } from '@mui/material/colors';

const Quiz = () => {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [submitData] = useSubmitUserQuizMutation();
  const quizId = useParams();
  const userId = localStorage.getItem('userId');
  const [getData, { isLoading, isSuccess, post }] = useGetOneQuizMutation();
  const [posts, setPosts] = useState(post);
  const [quizData, setQuizData] = useState(post);
  const [userAnswers, setUserAnswers] = useState({});
  const [markedForReview, setMarkedForReview] = useState([]);
  const [visitedQuestions, setVisitedQuestions] = useState([]);
  const navigate=useNavigate();

  const Item = styled(Paper)(({ theme }) => ({
    backgroundColor: theme.palette.mode === 'dark' ? '#1A2027' : '#fff',
    ...theme.typography.body2,
    padding: theme.spacing(2),
    margin:theme.spacing(2),
    // textAlign: 'center',
    height: '400px',
    color: theme.palette.text.secondary,
  }));



  const getQuiz = async () => {
    const encryptedId = encryptData(quizId);
    await getData({ id: encryptedId }).then((data) => {
      const temp = decryptData(data.data.encryptedData);
      setPosts(temp.quizQuestions);
      setQuizData(temp)
    })
  }
  useEffect(() => {
    getQuiz();
  }, []);
  console.log('posts', posts)
  // console.log('userAnswers', userAnswers)

  const handleOptionChange = (option, index) => {
    if (posts[currentQuestion]?.question_type === false) {
      setUserAnswers({
        ...userAnswers,
        [currentQuestion]: { [index]: option.option_text }
      });
    } else {
      setUserAnswers({
        ...userAnswers,
        [currentQuestion]: {
          ...userAnswers[currentQuestion],
          [index]: userAnswers[currentQuestion]?.[index] ? undefined : option.option_text
        }
      });
    }
    setVisitedQuestions(prevState => {
      if (!prevState.includes(currentQuestion)) {
        return [...prevState, currentQuestion];
      } else {
        return prevState;
      }
    });
  };

  const handleClearResponse = () => {
    setUserAnswers({
      ...userAnswers,
      [currentQuestion]: {}
    });
    // setVisitedQuestions(prevState => {
    //   if (!prevState.includes(currentQuestion)) {
    //     return [...prevState, currentQuestion];
    //   } else {
    //     return prevState;
    //   }
    // });
  };

  const handleMarkForReview = () => {
    setMarkedForReview(prevState => {
      if (prevState.includes(currentQuestion)) {
        return prevState.filter(questionIndex => questionIndex !== currentQuestion);
      } else {
        return [...prevState, currentQuestion];
      }
    });
  };

  const getColor = (index) => {
    if (markedForReview.includes(index)) {
      return userAnswers[index] && Object.keys(userAnswers[index]).length !== 0 ? 'secondary' : 'warning';
    } else if (visitedQuestions.includes(index)) {
      return userAnswers[index] && Object.keys(userAnswers[index]).length !== 0 ? 'success' : 'error';
      // return userAnswers[index] ? 'success' : 'error';
    } else {
      return 'default';
    }
  };
  // visitedQuestions.filter(q => userAnswers[q] && Object.keys(userAnswers[q]).length !== 0)
  console.log('visitedQuestions', visitedQuestions)
  console.log('userAnswers', userAnswers)

  const handleSubmit = async () => {
    let score = 0;
    for (let i = 0; i < posts?.length; i++) {
      const correctOptions = posts[i].quizOptions.filter(option => option.is_correct).map(option => option.option_text);
      const userSelectedOptions = Object.values(userAnswers[i] || {}).filter(Boolean);
      if (posts[i].question_type === false) {
        if (JSON.stringify(correctOptions) === JSON.stringify(userSelectedOptions)) {
          score += posts[i].question_marks;
        }
      } else {
        const correctSelected = correctOptions.filter(option => userSelectedOptions.includes(option));
        score += (correctSelected.length / correctOptions.length) * posts[i].question_marks;
      }
    }
    console.log('Final Score:', score);
    const decryptId = decryptData(userId);
    const encryptedData = encryptData({ finalScore: score, quizId: quizId.quizId, userId: decryptId });
    await submitData({ data: encryptedData }).then((data)=>{
      navigate('/finished')
    })
  }
  return (
    <>
      {isLoading && <Loading />}
      {isSuccess &&
        <Box className="w-full mb-12">
          <Box className="relative md:pt-32 pb-32 pt-14" style={{ backgroundColor: '#135268' }}>
            <Box
              className="px-4"
              sx={{
                color: "white",
                width: "100%",
                position: "absolute",
                bottom: 0,
              }}
            >
              <Stack direction="row" justifyContent="space-between">
                <Typography gutterBottom variant="h4" component="div" style={{ textTransform: "capitalize" }}>{quizData?.quizName}</Typography>
                <Typography gutterBottom variant="h5" component="div" ><Timer /></Typography>
              </Stack>
            </Box>
          </Box>
          <div
            className="relative pb-2 pt-2 "
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >
            <Grid container spacing={2}>
              <Grid xs={4}>
                <Item elevation={0}>
                <Stack direction="row" spacing={1}>
                    {posts?.map((_, index) => (
                      <Chip
                        label={index + 1}
                        clickable
                        color={getColor(index)}
                        onClick={() => setCurrentQuestion(index)}/>))}
                  </Stack>
                  <Typography variant="body1" sx={{ mt:6,mb:1}}>Progress:</Typography>
                  <Typography variant="body2" style={{ color: 'green' }}>Answered: {visitedQuestions.filter(q => userAnswers[q] && Object.keys(userAnswers[q]).length !== 0).length}</Typography>
                  <Typography variant="body2" style={{ color: 'red' }}>Not Answered: {visitedQuestions.filter(q => !userAnswers[q]).length}</Typography>
                  <Typography variant="body2" style={{ color: '#da930c' }}>Marked for Review and Not Answered: {markedForReview.filter(q => userAnswers[q] && Object.keys(userAnswers[q]).length === 0).length}</Typography>
                  <Typography variant="body2" style={{ color: '#e546e5' }}>Marked for Review and Answered: {markedForReview.filter(q => userAnswers[q] && Object.keys(userAnswers[q]).length !== 0).length}</Typography>
                  <Typography variant="body2" style={{ color: 'black' }}>Not Visited: {(posts?.length - visitedQuestions?.length)<0 ? 0 : (posts?.length - visitedQuestions?.length)}</Typography>
                </Item>
              </Grid>
              <Grid xs={8}>
                <Item elevation={0}>
                  <Box display="flex" flexDirection="column" height="100%">
                    <Box>
                      <Stack direction="row" justifyContent="space-between">
                        <Grid xs={7}><Typography gutterBottom variant="h5" component="div" >Question No: {currentQuestion + 1}</Typography>
                          <Typography gutterBottom variant="h6" component="div" >{posts[currentQuestion]?.question}</Typography>
                          <Stack>
                            {posts[currentQuestion]?.quizOptions.map((option, index) => {
                              if (posts[currentQuestion]?.question_type === false) {
                                return (
                                  <FormControlLabel
                                    control={<Radio />}
                                    label={option.option_text}
                                    checked={!!userAnswers[currentQuestion]?.[index]}
                                    onChange={() => handleOptionChange(option, index)}
                                    key={index}
                                  />
                                );
                              } else {
                                return (
                                  <FormControlLabel
                                    control={<Checkbox />}
                                    label={option.option_text}
                                    checked={!!userAnswers[currentQuestion]?.[index]}
                                    onChange={() => handleOptionChange(option, index)}
                                    key={index}
                                  />
                                );
                              }
                            })}
                          </Stack></Grid>
                        <Grid xs={2}> <Typography gutterBottom variant="h6" component="div" >Marks:{posts[currentQuestion]?.question_marks}</Typography></Grid>
                      </Stack>
                    </Box>
                    <Box mt="auto">
                      <Stack direction="row" spacing={2}>
                        <Button
                          variant="contained"
                          color="primary"
                          disabled={currentQuestion === 0}
                          onClick={() => setCurrentQuestion(currentQuestion - 1)}
                          fullWidth
                        >Back</Button>
                        <Button
                          variant="contained"
                          color="warning"
                          onClick={handleMarkForReview}
                          fullWidth
                        >Mark for Review</Button>
                        <Button
                          variant="contained"
                          sx={{backgroundColor: pink[700]}}
                          onClick={handleClearResponse}
                          fullWidth
                        >Clear Response</Button>
                        {currentQuestion < posts?.length - 1 ? (<Button
                          variant="contained"
                          color="primary"
                          onClick={() => {setCurrentQuestion(currentQuestion + 1); setVisitedQuestions([...visitedQuestions, currentQuestion])}}
                          fullWidth
                        >Next</Button>
                        ) : (
                          <Button
                            variant="contained"
                            color="success"
                            onClick={() => { handleSubmit() }}
                            fullWidth
                          >Submit
                          </Button>
                        )}
                      </Stack>
                    </Box>
                  </Box>
                </Item>
              </Grid>
            </Grid>
          </div>
        </Box>
      }
    </>
  )
}
export default Quiz;

// colors not getting assigned properly , use mui components ... maintain visited questions array too .. 
// colors is as follows:
// 1. if not visited ->default
// 2. if visited and answer selected->success
// 3.if visited and not answered->error
// 4.if marked for review and not answered->warning
// 5.if marked for review and answered->secondary
// and in the legend section show the number of questions in each category too.. and the categories are visited,not visited,visited and not answered,mark for review and not answered,mark for review and answered  
      