import { Box, Button, Container, Grid, Stack, Typography } from '@mui/material';
import React from 'react';
import { useNavigate } from 'react-router-dom';
import img from '../../assets/img/finish.png'

export default function Finished() {
  const navigate = useNavigate();

  return (
    <Box className="w-full mb-12">
      <Box className="relative md:pt-32 pb-32 pt-14" style={{ backgroundColor: '#135268' }}>
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
          }}
        >
          <Stack direction="row" justifyContent="space-between">
            <Typography gutterBottom variant="h4" component="div" style={{ textTransform: "capitalize" }}>{' '}</Typography>
          </Stack>
        </Box>
      </Box>
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          // alignItems: "center",
          pt:6,
          minHeight: "100vh",
          backgroundColor:'white',
          overflow:"hidden"
        }}
      >
        <Container maxWidth="md">
          <Grid container spacing={2}>
            <Grid xs={6}>
              <Typography variant="h2" sx={{ mt: 6, mb: 6 }}>Quiz Finished!</Typography>
              <Button onClick={() => navigate('/')} sx={{ mt: 6 }}>Go Home</Button>
            </Grid>
            <Grid xs={6}>
              <img src={img} alt="Quiz Finished!" />
            </Grid>
          </Grid>
        </Container>

      </Box>
    </Box>
  );
}
