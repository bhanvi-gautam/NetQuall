import React, { useState } from 'react';
import { Card, CardContent, Typography, CardActions, Button, Checkbox, TextField, Modal, Box } from '@mui/material';
import { notifyError, notifySuccess } from '../../toast';
import { ToastContainer } from 'react-toastify';

const AnnouncementItem = ({ post, roleId, onUpdate, onDelete }) => {
    const [isEditing, setIsEditing] = useState(false);
    const [updatedHeading, setUpdatedHeading] = useState(post.announcement_heading);
    const [updatedDescription, setUpdatedDescription] = useState(post.announcement_description);
    const [isForStudents, setIsForStudents] = useState(post.available_for_student);
    const [isForTeachers, setIsForTeachers] = useState(post.available_for_teachers);
    const [showDeleteModal, setShowDeleteModal] = useState(false);

    const handleUpdateClick = () => {
        if (!isForStudents && !isForTeachers) {
            notifyError("Error: At least one checkbox must be selected.");
            return;
        }

        onUpdate({

            id: post.id,
            announcement_heading: updatedHeading,
            announcement_description: updatedDescription,
            available_for_student: isForStudents,
            available_for_teachers: isForTeachers,
        });
        // notifySuccess("Announcement Updated")
        setIsEditing(false);
    };

    const style = {
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: 400,
        bgcolor: 'background.paper',
        borderRadius:'2px',
        // border: '1px solid #000',
        boxShadow: 24,
        p: 4,
    };

    const handleDeleteClick = () => {
        setShowDeleteModal(true);
    };

    const handleConfirmDelete = () => {
        onDelete(post.id);
        setShowDeleteModal(false);
    };

    return (
        <Card variant="outlined">
            <CardContent>
                {isEditing ? (
                    <>
                        <TextField
                            label="Announcement Heading"
                            value={updatedHeading}
                            sx={{mr:1}}
                            onChange={(e) => setUpdatedHeading(e.target.value)}
                        />
                        <TextField
                            label="Announcement Description"
                            sx={{mr:1}}
                            value={updatedDescription}
                            onChange={(e) => setUpdatedDescription(e.target.value)}
                        />
                        <Checkbox
                            checked={isForStudents}
                            onChange={() => setIsForStudents(!isForStudents)}
                        />
                        For Students
                        <Checkbox
                            checked={isForTeachers}
                            onChange={() => setIsForTeachers(!isForTeachers)}
                        />
                        For Teachers
                    </>
                ) : (
                    <>
                        <Typography sx={{ mb: 1.5 }} color="text.secondary">

                            {roleId === '4' && <>
                                {post.available_for_student && "For Students"}
                                {post.available_for_student && post.available_for_teachers && " and "}
                                {post.available_for_teachers && "For Teachers"}
                            </>
                            }
                        </Typography>
                        <Typography variant="h5">{post.announcement_heading}</Typography>
                        <Typography variant="body2">{post.announcement_description}</Typography>
                    </>
                )}
            </CardContent>
            <CardActions>
                {roleId === '4' && (
                    <>
                        {isEditing ? (
                            <>
                            <Button size="small" onClick={handleUpdateClick}>Save</Button>
                            <Button size="small" onClick={() => setIsEditing(false)}>Cancel</Button>
                            </>
                        ) : (
                            <>
                            <Button size="small" onClick={() => setIsEditing(true)}>Update</Button>
                       
                        <Button size="small" onClick={handleDeleteClick}>
                            Delete
                        </Button>
                        </>
                         )}
                        <Modal open={showDeleteModal} onClose={() => setShowDeleteModal(false)}>
                            <Box sx={style}>
                                <Typography variant="h6">Are you sure?</Typography>
                                <Typography variant="body2">Announcement will be removed permanently.</Typography>
                                <Button onClick={() => setShowDeleteModal(false)}>Cancel</Button>
                                <Button onClick={handleConfirmDelete}>Yes</Button>
                            </Box>
                        </Modal>
                    </>
                )}
            </CardActions>
            <ToastContainer containerId="B"/>
            <ToastContainer containerId="A"/>
        </Card>
    );
};

export default AnnouncementItem;
