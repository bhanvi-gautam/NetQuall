import { Box, Typography } from '@mui/material';
import React from 'react'

const CustomCard = ({ profile, name, laneId }) => {
    return (
        <Box display="flex" alignItems="center">
            <Box mr={2}>
                <img
                    src={profile}
                    alt="Profile"
                    width="50"
                    height="50"
                    style={{ borderRadius: '50%' }}
                />
            </Box>
            <Box>
                <Typography variant="subtitle1">{name}</Typography>
                {/* <Typography variant="caption">Lane ID: {laneId}</Typography> */}
            </Box>
        </Box>
    );
};

export default CustomCard
