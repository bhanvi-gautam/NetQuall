const httpStatus = require('http-status');
const AuthService = require('../service/AuthService');
const TokenService = require('../service/TokenService');
const UserService = require('../service/UserService');
const QuizService = require('../service/QuizService');
const logger = require('../config/logger');
const { tokenTypes } = require('../config/tokens');
const fs = require('fs')
const asyncWrapper = require('../middlewares/async');

const decryptData = require('../helper/EncryDecryHelper');
const encryptData = require('../helper/EncryDecryHelper');


class QuizController {
    constructor() {
        this.userService = new UserService();
        this.tokenService = new TokenService();
        this.authService = new AuthService();
        this.quizService = new QuizService();
        this.DATAEncryptionKey = '6d090796-ecdf-11ea-adc1-0242ac112345'
    }

    createQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.data, this.DATAEncryptionKey);
        const quiz = await this.quizService.createQuiz(decryptedData);
        const { status } = quiz.response;

        const { message } = quiz.response;
        res.status(quiz.statusCode).send({ status, message });

    });

    getQuizzes = asyncWrapper(async (req, res) => {
        // const decryptedData = decryptData.decryptData(req.body, this.DATAEncryptionKey);
        const quiz = await this.quizService.getQuizzes(req.body);
        const { status } = quiz.response;

        const { message,data } = quiz.response;
        const encryptedData=encryptData.encryptData(data,this.DATAEncryptionKey);
        res.status(quiz.statusCode).send({ status, message ,encryptedData});

    });

    getStudentQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.id, this.DATAEncryptionKey);
        console.log('decryptedData====', decryptedData)
        const quiz = await this.quizService.getStudentQuiz(decryptedData);
        const { status } = quiz.response;

        const { message,data } = quiz.response;
        const encryptedData=encryptData.encryptData(data,this.DATAEncryptionKey);
        res.status(quiz.statusCode).send({ status, message ,encryptedData});

    });

    getOneQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.id, this.DATAEncryptionKey);
        const quiz = await this.quizService.getOneQuiz(decryptedData.quizId);
        const { status } = quiz.response;

        const { message,data } = quiz.response;
        const encryptedData=encryptData.encryptData(data,this.DATAEncryptionKey);
        res.status(quiz.statusCode).send({ status, message ,encryptedData});

    });

    liveQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.encryptedData, this.DATAEncryptionKey);
        const quiz = await this.quizService.liveQuiz(decryptedData);
        const { status } = quiz.response;
        const { message } = quiz.response;
        res.status(quiz.statusCode).send({ status, message });

    });

    deleteQuiz = asyncWrapper(async (req, res) => {
        const decryptedData = decryptData.decryptData(req.body.data, this.DATAEncryptionKey);
        const quiz = await this.quizService.deleteQuiz(decryptedData);
        const { status } = quiz.response;
        const { message } = quiz.response;
        res.status(quiz.statusCode).send({ status, message });

    });

}

module.exports = QuizController;