const express = require('express');
const authRoute = require('./authRoute');
const userRoute = require('./userRoute');
const lmsRoute=require('./lmsRoute');
const quizRoute=require('./quizRoute');

const router = express.Router();

const defaultRoutes = [
    {
        path: '/auth',
        route: authRoute,
    },
    {
        path: '/user',
        route: userRoute,
    },
    {
        path:'/lms',
        route: lmsRoute,
    },
    {
        path:'/quiz',
        route: quizRoute,
    }
];

defaultRoutes.forEach((route) => {
    router.use(route.path, route.route);
});

module.exports = router;
