const SuperDao = require('./SuperDao');
const models = require('../models');

const userSemester = models.userSemester;

class UserSemesterDao extends SuperDao {
    constructor() {
        super(userSemester);
    }

 
}

module.exports = UserSemesterDao;
