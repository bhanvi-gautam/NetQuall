const SuperDao = require('./SuperDao');
const models = require('../models');

const QuizQuestions = models.quizQuestions;

class QuizQuestionsDao extends SuperDao {
    constructor() {
        super(QuizQuestions);
    }
}
module.exports=QuizQuestionsDao;