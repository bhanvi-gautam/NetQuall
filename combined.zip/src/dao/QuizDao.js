const SuperDao = require('./SuperDao');
const models = require('../models');
const logger = require('../config/logger');

const Quiz = models.quizzes;
const QuizQuestions = models.quizQuestions;
const QuizOptions = models.quizOptions;

class QuizDao extends SuperDao {
    constructor() {
        super(Quiz);
    }

    async isQuizNameExists(quizName) {
        console.log('quizName', quizName)
        return Quiz.count({ where: { quizName :quizName} }).then((count) => {
            if (count != 0) {
                return true;
            }
            return false;
        });
    }

    async getQuizzes(subjectId){
        return Quiz.findAll({
            where:{
                subject_Id:subjectId,
            },
            attributes:['id','quizName','subject_Id','quiz_marks','is_available'],
            include:[{
                model:QuizQuestions,
                attributes:['id','question','quiz_Id','question_marks','question_type'],
                include:[{
                    model:QuizOptions,
                    attributes:['id','option_text','is_correct','question_Id']
                }]
            }]
        }).then((result)=>{
            return result;
        }).catch((e)=>{
            logger.error(e);
            console.log(e);
        })
    }

    
    async getOneQuiz(req){
        return Quiz.findOne({
            where:{
                id:req,
            },
            attributes:['id','quizName','quiz_marks'],
            include:[{
                model:QuizQuestions,
                attributes:['id','question','quiz_Id','question_marks','question_type'],
                include:[{
                    model:QuizOptions,
                    attributes:['id','option_text','is_correct','question_Id']
                }]
            }]
        }).then((result)=>{
            return result;
        }).catch((e)=>{
            logger.error(e);
            console.log(e);
        })
    }

}
module.exports=QuizDao;