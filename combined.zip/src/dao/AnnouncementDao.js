const SuperDao = require('./SuperDao');
const models = require('../models');

const Announcement = models.announcement;

class AnnouncementDao extends SuperDao {
    constructor() {
        super(Announcement);
    }
}
module.exports=AnnouncementDao;