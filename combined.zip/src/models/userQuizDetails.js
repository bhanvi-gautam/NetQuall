const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userQuizDetails extends Model {
        
        static associate(models) {
            // define association here
        }
    }

    userQuizDetails.init(
        {
            uuid: DataTypes.UUID,
               
        },
        {
            sequelize,
            modelName: 'userQuizDetails',
            underscored: false,
        },
    );
    return userQuizDetails;
};