const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userSubject extends Model {
        
        static associate(models) {
            // define association here
            userSubject.belongsTo(models.userSemester, { foreignKey: 'semester_Id', targetKey: 'id' });
            userSubject.belongsToMany(models.user,{
                through:'userTeacherDetails',
                // foreignKey:'subject_Id',
            });
            userSubject.hasMany(models.userTeacherDetails)
            userSubject.hasMany(models.userAssignment,{foreignKey:'userSubject_Id'})
            userSubject.hasMany(models.quizzes,{foreignKey:'subject_Id',targetKey:'id'})
        }
    }

    userSubject.init(
        {
            uuid: DataTypes.UUID,
            subjectName: DataTypes.STRING,
            is_available: { type: DataTypes.INTEGER, defaultValue: '0' },

        },
        {
            sequelize,
            modelName: 'userSubject',
            underscored: false,
        },
    );
    return userSubject;
};