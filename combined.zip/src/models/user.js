const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class user extends Model {
        static associate(models) {
            user.belongsTo(models.userCourse,{foreignKey: 'course_Id', targetKey: 'id' })
            user.belongsToMany(models.userSubject,{
                through:'userTeacherDetails',
                // foreignKey:'teacher_Id',
            });
            user.hasMany(models.userTeacherDetails, { as: 'teachers' });
            user.hasMany(models.userAssignment,{foreignKey:'user_Id'});
            user.belongsToMany(models.quizzes,{
                through:'userQuizDetails',
                // sourceKey:'id',
                // targetKey:'id',
            })
        }
    }
    user.init(
        {
            uuid: DataTypes.UUID,
            profile: { type: DataTypes.STRING, defaultValue: null },
            first_name: DataTypes.STRING,
            last_name: DataTypes.STRING,
            email: DataTypes.STRING,
            password: DataTypes.STRING,
            status: {
                type: DataTypes.INTEGER,
                comment: 'status: 0 = No subject, 1 = Subject Available',
            },
            email_verified: DataTypes.INTEGER,
            address: DataTypes.STRING,
            phone_number: DataTypes.INTEGER,
            otp_generated: { type: DataTypes.STRING, defaultValue: '0' },
            
            is_available: {
                type: DataTypes.INTEGER,
                defaultValue: '0',
                comment: 'Availability status: 0 = Not Available, 1 = Available',
            },
            is_deleted: { type: DataTypes.INTEGER, defaultValue: '0' },
            about:{
                type:DataTypes.STRING,
                defaultValue:null
            }
        },
        {
            sequelize,
            modelName: 'user',
            underscored: false,
        },
    );
       
    return user;
};