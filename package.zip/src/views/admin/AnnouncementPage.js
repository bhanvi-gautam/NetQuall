import React, { useEffect, useState } from 'react'
import { useDeleteAnnouncementMutation, useGetAnnouncementQuery, useUpdateAnnouncementMutation } from '../../components/rtk/AddSlice'
import { Box, Button, Card, CardActions, CardContent, Modal, Typography } from '@mui/material';
import { notifyError, notifySuccess } from '../../toast'
import AnnouncementItem from './AnnouncementItem';
import { ToastContainer } from 'react-toastify';

const style = {
  position: 'absolute',
  top: '50%',
  left: '50%',
  transform: 'translate(-50%, -50%)',
  width: 400,
  bgcolor: 'background.paper',
  border: '2px solid #000',
  boxShadow: 24,
  p: 4,
};

const AnnouncementPage = () => {
  
  const roleId = localStorage.getItem('roleId');
  const { data: responseData, isLoading, isSuccess, error, refetch } = useGetAnnouncementQuery(roleId);
  const [updateAnnouncement, { isLoading: isUpdating }] = useUpdateAnnouncementMutation();
  const [deleteData] = useDeleteAnnouncementMutation();
  const [show, setShow] = useState(false);
  useEffect(() => {
    const getAnnouncement = async () => {
      try {
        await refetch();
      } catch (err) {
        console.error("Error fetching announcement:", err);
      }
    }

    getAnnouncement();
  }, [refetch]);

  const handleClose = async (value) => {
    setShow(!show);
    if (value) {
      await refetch();
    }
  }

  const handleAnnouncementUpdate = async (updatedData) => {
    console.log('Updated data:', updatedData);
    updateAnnouncement(updatedData).then(async (data) => {
      await refetch();
    }).catch((error) => {
      console.log('error', error)
    });

  };

  const handleDelete = (id) => {
    console.log('id', id)
    deleteData(id).unwrap().then((data) => {
      handleClose(1000);
      notifySuccess("Announcement Deleted")
    }).catch((error) => {
      notifyError("Failed to delete announcement")
    })
  }

  console.log('responseData', responseData?.data)
  return (
    <div style={{minHeight: '100vh'}}>
      <Box display="flex" justifyContent="center" mt={2}>
        <Typography variant="h4"> Latest Updates & Notices
</Typography>
      </Box>
      {isSuccess &&
        <div>
          {responseData.data.map((post, index) => {
            return (
              <Box key={index} sx={{ minWidth: 165, m: 4 }}>

                <AnnouncementItem
                  post={post}
                  roleId={roleId}
                  onUpdate={handleAnnouncementUpdate}
                  onDelete={handleDelete}
                />

              </Box>
            )
          })}

        </div>
      }
      <ToastContainer containerId="A"/>
      <ToastContainer containerId="B"/>
    </div>
  );
}

export default AnnouncementPage;
