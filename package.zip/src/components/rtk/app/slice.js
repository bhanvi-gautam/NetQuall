 import { createSlice } from "@reduxjs/toolkit";

let initialState={strValue:'',count:1}

const slice = createSlice({
    name: 'token',
    initialState,
    reducers: {
        setToken: (state, action) => {
            state.strValue = action.payload;
            console.log('state.strValue', state.strValue)
        },
        increment: (state) => {
            state.count += 1;
            console.log('state.count', state.count)

        }
        
    }
});

export default slice.reducer;
export const {setToken,increment}=slice.actions;

//common for for count and token!
                    