import { Subject } from 'rxjs';

const subject = new Subject();

const castingService = {
    sendMessage: (senderId, message = {}, target) => subject.next({
        text: message,
        senderId: senderId,
        target: target
    }),
    clearMessages: () => subject.next(),
    onMessage: () => subject.asObservable()
};

export default castingService;