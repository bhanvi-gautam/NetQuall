import * as React from 'react';
import Button from '@mui/material/Button';
import { styled } from '@mui/material/styles';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import IconButton from '@mui/material/IconButton';
import CloseIcon from '@mui/icons-material/Close';
import Typography from '@mui/material/Typography';
import InfoOutlinedIcon from '@mui/icons-material/InfoOutlined';

const BootstrapDialog = styled(Dialog)(({ theme }) => ({
  '& .MuiDialogContent-root': {
    padding: theme.spacing(2),
  },
  '& .MuiDialogActions-root': {
    padding: theme.spacing(1),
  },
}));

export default function CustomizedDialogs( {handleCloseParent}) {
  const [open, setOpen] = React.useState(true);

  const handleClose = () => {
    setOpen(false);
    handleCloseParent();
  };

  return (
    <React.Fragment>
      <BootstrapDialog
        onClose={handleClose}
        aria-labelledby="customized-dialog-title"
        open={open}

        style={{backgroundColor:'beige'}}
      >
        <DialogTitle sx={{ m: 0, p: 2 }} id="customized-dialog-title">
        <InfoOutlinedIcon/> Attention Users:
        </DialogTitle>
        <IconButton
          aria-label="close"
          onClick={handleClose}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            color: (theme) => theme.palette.grey[500],
          }}
        >
          <CloseIcon />
        </IconButton>
        <DialogContent dividers >
    <Typography variant="body1" gutterBottom >
      Please acquaint yourselves with the operational nuances of this interface:
    </Typography>
    <Typography variant="subtitle1" gutterBottom>
      Submission Timeliness Indicator:
    </Typography>
    <Typography variant="body2" gutterBottom>
      The 'Submitted On' column employs a color-coded system to signify submission punctuality. A green background denotes adherence to the deadline, while a red background indicates a tardy submission.
    </Typography>
    <Typography variant="subtitle1" gutterBottom>
      Assessment Confirmation Status:
    </Typography>
    <Typography variant="body2" gutterBottom>
      In the 'Accepted/Unaccepted' column, the presence of an 'Accepted' button signifies that the evaluation is complete, and the awarded marks are immutable. Conversely, an 'Unaccepted' button indicates the opportunity to appraise the student's work; such entries remain unchecked.
    </Typography>
    <Typography variant="subtitle1" gutterBottom>
      Mark Allocation Protocol:
    </Typography>
    <Typography variant="body2" gutterBottom>
      Exercise judiciousness when assigning marks, as they are irrevocable upon submission. Your discernment in evaluation is paramount.
    </Typography>
    <Typography variant="subtitle1" gutterBottom>
      Administrative Support:
    </Typography>
    <Typography variant="body2" gutterBottom>
      Should any discrepancies or uncertainties arise, do not hesitate to reach out to the administrative team for resolution.
    </Typography>
    <Typography variant="body1" gutterBottom>
      We trust you will find this system to be intuitive and efficient. Thank you for your meticulous attention to detail and commitment to excellence.
    </Typography>
  </DialogContent>
  <DialogActions>
    <Button onClick={handleClose} color='info'>
      Understood
    </Button>
        </DialogActions>
      </BootstrapDialog>
    </React.Fragment>
  );
}
