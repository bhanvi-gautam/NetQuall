import React from "react";
import { Box, Button, Container, Typography } from "@mui/material";
import Grid from "@mui/material/Grid";
import img from "../../assets/img/noDataFound.png";

export default function Error({ content }) {
  return (
    <Box
      sx={{
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        minHeight: "100vh",
      }}
    >
      <Container maxWidth="md">
        <Grid container spacing={2}>
          <Grid xs={6}>
            <Typography variant="h1">No Data</Typography>
            <Typography variant="h6">{content}</Typography>
          </Grid>
          <Grid xs={6}>
            <img src={img} alt="No Data Found" />
          </Grid>
        </Grid>
      </Container>
    </Box>
  );
}
