import React, { useEffect, useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import Button from "@mui/material/Button";
import DeleteIcon from "@mui/icons-material/Delete";
import NoDataFound from "./NoDataFound";
import { encryptData } from "../../assets/security/encryDecrypt";
import { useDeletePostMutation } from "../rtk/AddSlice";
import EditIcon from "@mui/icons-material/Edit";
import { useDispatch } from "react-redux";
import { increment } from "../rtk/app/slice";
import { notifySuccess } from "../../toast";
import { ToastContainer } from "react-toastify";
export default function CardTable3({
  content,
  errorMessg,
  handleCountParent,
  Icon,filteredData
}) {
  const [open, setOpen] = useState(false);
  const [deleteData] = useDeletePostMutation();
  const [count, setCount] = useState(0);
  const [courseIdToDelete, setCourseIdToDelete] = useState(null);
  const dispatch = useDispatch();

  const handleCountChange = (e) => {
    e.preventDefault();
    setCount(count + 1);
    dispatch(increment())
    handleCountParent();
  };

  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
  };

  const deleteCourse = async () => {
    if (courseIdToDelete) {
      let courseId = courseIdToDelete;
        const deleteInfo = { courseId };
        const encryptedData = encryptData(deleteInfo);
        await deleteData({ encryptedData }).unwrap().then((fetchPt)=>{
          filteredData(1000);
      });
      setCourseIdToDelete(null);
      handleClose();
    } else {
      console.log("No course selected for deletion");
    }
  };

  let flag = 0;
  return (
    <>
      <div className="relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded bg-white">
        
        <div className="block w-full overflow-x-auto">
          {/* Projects table */}
          <table className="items-center w-full bg-transparent border-collapse">
             <thead>
              <tr>
                {/* {heading?.map((data) => ( */}
                <th
                  className={
                    "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                  }
                >
                  Sno
                </th>
                <th
                  className="px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                  onClick={handleCountChange}
                >
                  Course Name {Icon}
                </th>
                <th
                  className={
                    "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                  }
                >
                  Action
                </th>
                {/* ))} */}
              </tr>
            </thead>
            <tbody>
              {content?.map((data, index) => {
                flag++;
                return (
                  <tr key={index}>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {index + 1}
                    </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                      {data.courseName}
                    </td>
                    <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4" style={{ display: "flex", justifySelf: "stretch" }}>
                      <Link to={`/courseDetail/editCourse/${data.id}`}>
                        <EditIcon />
                      </Link>
                      <DeleteIcon
                        onMouseEnter={() => setCourseIdToDelete(data.id)}
                        // onClick={deleteCourse}
                        onClick={handleClickOpen}
                      />
                      <Dialog
                        open={open}
                        onClose={handleClose}
                        aria-labelledby="alert-dialog-title"
                        aria-describedby="alert-dialog-description"
                      >
                        <DialogTitle id="alert-dialog-title">
                          {"Are you sure you want to delete this course?"}
                        </DialogTitle>
                        <DialogContent>
                          <DialogContentText id="alert-dialog-description">
                            All the semester and subject data inside will also be deleted
                          </DialogContentText>
                        </DialogContent>
                        <DialogActions>
                          <Button onClick={handleClose}>Cancel</Button>
                          <Button onClick={deleteCourse} autoFocus>
                            Yes
                          </Button>
                        </DialogActions>
                      </Dialog>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>

          {flag === 0 && <NoDataFound content={errorMessg} />}
        </div>
      </div>
      <ToastContainer />
    </>
  );
}
