import React, { useState, useEffect } from 'react'
import { useGetOnePostMutation, useGetCourseIdMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import { Link } from 'react-router-dom';
import NoDataFound from '../Cards/NoDataFound';
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import {
  Paper,
  Typography,
  Card,
  CardContent,
  CardActions,
  IconButton,
  Alert,
  Stack,
} from "@mui/material";


const QuizForStudent = () => {
  const userId = localStorage.getItem('userId');
  const [getCourseId] = useGetCourseIdMutation();
  const [getData, { isLoading, isSuccess }] = useGetOnePostMutation();
  const [info, setInfo] = useState(null);

  console.log('userId', userId)

  const abc = async () => {
    const fetch = await getCourseId({ userId }).unwrap();
    const decryptedData = decryptData(fetch.data);
    const encryptedId = encryptData({ decryptedData });
    const fetchPt = await getData({ courseId: encryptedId }).unwrap();
    const fetchPosts = decryptData(fetchPt.data);
    console.log("hie--", fetchPosts.userSemesters);
    setInfo(fetchPosts.userSemesters);
  }
  let flag = 0;
  useEffect(() => {
    abc();
  }, [])
  return (
    <div className="w-full mb-12">
      {isLoading && <CardShimmer />}

      {isSuccess && (
        <>
          <div
            className="relative md:pt-30 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              position: "relative", // Ensure positioning context for absolute positioning
              backgroundColor: '#0099CC'
            }}
          >
            <Typography gutterBottom
              variant="h4"
              component="div"
              color={"white"}
              style={{
                position: "absolute",
                bottom: 0,
                left: 15,
              }}>
              Explore Subject by Quizzes!
            </Typography>

          </div>
          <div
            className="relative md:pt-30 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "flex-start",
              alignItems: "flex-start",
              padding: "0 20px",
              backgroundColor: 'white'
            }}
          >
            <Stack sx={{ width: '100%' }} spacing={2}>
              <Alert severity="info" style={{ margin: '10px' }}>
              Welcome to your academic journey! Explore a world of knowledge and learning through a variety of subjects. Click on the subjects below to access quizzes, expand your understanding, and enhance your skills.<br/>
              Quizzes are a great way to reinforce your understanding of the material. Challenge yourself and have fun while learning!
              <br/>Feel free to dive into the subjects that interest you most. Happy learning! 📚🌟
              </Alert>
            </Stack>

            {info?.map((data, index1) => {
              return data.userSubjects.map((data1, index) => {
                flag++;
                return (
                  <Card
                    key={index}
                    elevation={2}
                    style={{
                      height: "50px",
                      width: "780px",
                      margin: "15px",
                      position: "relative"
                    }}
                  >
                    <CardContent>
                      <Typography
                        variant="p"
                        component="div"
                        style={{
                          fontWeight: "bold",
                        }}
                      >
                        <Link to={"/viewSubjectQuiz/" + data1.subjectName}>{data1.subjectName}</Link>
                      </Typography>
                      <CardActions
                        style={{ position: "absolute", bottom: 0, right: 0 }}
                      >
                        <IconButton>
                          <Link to={"/viewSubjectQuiz/" + data1.subjectName}>
                            <ArrowForwardIcon />
                          </Link>
                        </IconButton>
                      </CardActions>
                    </CardContent>

                  </Card>
                );
              })
              if (flag === 0) {
                return <NoDataFound content={"No Subjects"} />
              }
            })}

          </div>
        </>
      )}
    </div>
  )
}

export default QuizForStudent
