import React, { useState, useEffect } from 'react'
import { useParams } from 'react-router-dom'
import { useGetStudentSubjectAssignMutation } from '../rtk/AddSlice'
import { decryptData } from '../../assets/security/encryDecrypt';
import CardShimmer from '../Effects/CardShimmer';
import CardTable4 from '../Cards/CardTable4';
import { Box, Button, Modal, Typography } from '@mui/material';
import PdfUploader from './Parts/PdfUploader';
import { notifySuccess } from "../../toast";
import { ToastContainer } from "react-toastify";

const ListStudentSubjectWise = () => {
  const [getData, { isLoading, isSuccess, post }] = useGetStudentSubjectAssignMutation();
  const [posts, setPosts] = useState(post);
  const [show, setShow] = useState(false);
  const subject = useParams();

  console.log('subject', subject)

  const abc = async () => {
    const fetchPosts = await getData({ subject }).unwrap();
    console.log('fetchPosts', fetchPosts.encryptedData);
    const students = decryptData(fetchPosts.encryptedData);
    console.log('students', students)
    setPosts(students.response.data);
  }

  const handleClose = (value) => {
    setShow(false);
    if (value === 100) {
      console.log('value', value)
      notifySuccess("Assignment Given")
    }
  }
  useEffect(() => {

  }, [show])
  const style = {
    position: 'absolute',
    top: '50%',
    left: '50%',
    transform: 'translate(-50%, -50%)',
    width: 560,
    bgcolor: 'background.paper',
    boxShadow: 24,
    p: 4,
  };

  useEffect(() => {
    abc();
  }, [])
  console.log('posts', posts)


  return (
    <>

      <Box className="w-full mb-12">
        <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
          <Box
            className="px-4"
            sx={{
              color: "white",
              width: "100%",
              position: "absolute",
              bottom: 0,
            }}
          >
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <Typography gutterBottom variant="h4" component="div">
                {"Students under " + subject.subject}
              </Typography>

              <div style={{ display: "flex", flexDirection: "column" }}>
                <Button variant="contained" color="success" onClick={() => setShow(!show)}>
                  Give assignment
                </Button>

                {show &&
                  <Modal
                    open={show}
                    onClose={handleClose}
                    aria-labelledby="modal-modal-title"
                    aria-describedby="modal-modal-description"
                  >
                    <Box sx={style}>
                      <PdfUploader subject={subject.subject} handleCloseParent={handleClose} />
                    </Box>
                  </Modal>
                }
              </div>
            </div>
          </Box>
        </Box>
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className="relative pb-2"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
              backgroundColor: "white",
            }}
          >

            <CardTable4
              title={"Students under " + subject.subject}
              content={posts}
              heading={[
                "Profile",
                "Student Name",
                "Email",
                "Assignments Section"
              ]}
              roleId={3}
              subject={subject.subject}

              errorMessg={"No Student available"}
            />
          </div>
        )}
      </Box>
      <ToastContainer containerId="A" />

    </>
  )
}

export default ListStudentSubjectWise
