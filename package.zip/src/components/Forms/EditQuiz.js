import { Box, Button, Typography } from '@mui/material';
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom';
import { useGetOneQuizMutation } from '../rtk/AddSlice';
import { decryptData, encryptData } from '../../assets/security/encryDecrypt';
import PostDetailsShimmer from '../Effects/PostDetailsShimmer';


const EditQuiz = () => {
  const quizId = useParams();
  const [getData, { isLoading, isSuccess, post }] = useGetOneQuizMutation();
  const [posts, setPosts] = useState(post);
  const [quizData, setQuizData] = useState(post);
  const getQuiz = async () => {
    const encryptedId = encryptData(quizId);
    await getData({ id: encryptedId }).then((data) => {
      console.log('data', data.data.encryptedData)
      const temp = decryptData(data.data.encryptedData);
      setPosts(temp);
      setQuizData(temp)
    })
  }
  useEffect(() => {
    getQuiz();
  }, []);

  // Handle Option Change
  // const handleOptionChange = (qIndex, oIndex) => {
  //   const newPosts = { ...posts };
  //   const selectedOption = newPosts?.quizQuestions[qIndex]?.quizOptions[oIndex];
  //   newPosts?.quizQuestions[qIndex]?.quizOptions?.forEach((option) => {
  //     option.is_correct = false;
  //   });
  //   selectedOption.is_correct = true;
  //   setPosts(newPosts);
  // };

  // Handle input changes
  const handleInputChange = (e, qIndex, oIndex) => {
    const { name, value, type, checked } = e.target;
    setQuizData(prevState => {
      let updatedQuizData = { ...prevState }; // Create a copy of the current state
      if (name === 'quizName') {
        updatedQuizData.quizName = value; // Update quiz name
      } else if (name.startsWith('question')) {
        updatedQuizData.quizQuestions[qIndex].question = value; // Update question text
      } else if (name.startsWith('option')) {
        updatedQuizData.quizQuestions[qIndex].quizOptions[oIndex].option_text = value; // Update option text
      } else if (name.startsWith('marks')) {
        updatedQuizData.quizQuestions[qIndex].question_marks = Number(value); // Update question marks
      } else if (type === 'checkbox' || type === 'radio') {
        updatedQuizData.quizQuestions[qIndex].quizOptions[oIndex].is_correct = checked; // Update is_correct for checkboxes and radio buttons
      }
      return updatedQuizData;
    });
  };


  const handleSubmit = (e) => {
    e.preventDefault();
    // Validate inputs
    // const hasEmptyInputs = posts.quizQuestions.some(
    //   (question) =>
    //     !question.question ||
    //     question.quizOptions.some((option) => !option.option_text)
    // );
    // const hasCorrectAnswer = posts.quizQuestions.some((question) =>
    //   question.quizOptions.some((option) => option.is_correct)
    // );

    // if (hasEmptyInputs) {
    //   alert('Please fill in all fields.');
    // } else if (!hasCorrectAnswer) {
    //   alert('Please select at least one correct answer.');
    // } else {
    //   // Save the edited quiz (you can replace this with your backend logic)
    console.log('Edited quiz:', quizData);

  };

  return (
    <Box className="w-full mb-12">
      <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
          }}
        >
          <Typography gutterBottom variant="h4" component="div">Edit Quiz</Typography>
        </Box>
      </Box>
      {isLoading && <PostDetailsShimmer />}
      {isSuccess &&
        <div className="flex-auto px-4 lg:px-10 py-10 pt-10">
          <form onSubmit={handleSubmit}>
            <div className="flex flex-wrap">
              <div className="w-full lg:w-12 px-4">
                <div className="relative w-full mb-3">
                  <label
                    className="block uppercase text-blueGray-600 text-s font-bold mb-2or SAP Deployment activities."
                  >
                    Quiz Name:
                  </label>
                  <input type="text" defaultValue={quizData?.quizName} onChange={(e) => handleInputChange(e)} className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150"
                    required />

                </div>
              </div>
            </div>
            {quizData?.quizQuestions?.map((question, qIndex) => (
              <div className="flex flex-wrap" key={qIndex}>
                <div className="w-full lg:w-12 px-4">
                  <div className="relative w-full mb-3">
                    <label className="block uppercase text-blueGray-600 text-s font-bold mb-2">
                      Question {qIndex + 1}:
                      <input type="text" name={`question_${qIndex}`} defaultValue={question.question} onChange={(e) => handleInputChange(e, qIndex)} className="border-0 px-3 py-3 mt-1 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                    </label>
                    {question?.quizOptions?.map((option, oIndex) => (
                      <div style={{ display: 'flex', alignItems: "center" }} key={oIndex}>

                        <label className="block uppercase text-blueGray-600 text-xs font-bold mb-2">
                          Option {oIndex + 1}:
                          <input type="text" name={`option_${qIndex}_${oIndex}`} defaultValue={option.option_text} onChange={(e) => handleInputChange(e, qIndex, oIndex)} className="border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                        </label>
                        <input
                          type={question.question_type ? "checkbox" : "radio"}
                          name={question.question_type ? `option_${qIndex}` : `option_${qIndex}_${oIndex}`}
                          defaultValue={option.id}
                          checked={option.is_correct}
                          onChange={(e) => handleInputChange(e, qIndex, oIndex)}
                          style={{ marginLeft: "20px" }}
                        />

                      </div>
                    ))}
                    <label className="block uppercase text-blueGray-600 text-xs font-bold mb-6 mt-5">Marks: 
                     <input type="number" name={`marks_${qIndex}`} defaultValue={question.question_marks} onChange={(e) => handleInputChange(e, qIndex)} className="border-0 px-3 py-3 mt-1 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150" required />
                     </label>
                  </div>
                </div>
              </div>
            ))}
            <p>Total Marks: {posts.quiz_marks}</p>
            <Button type="submit" >Submit Quiz</Button>
          </form>
        </div>}
    </Box>

  );
};

export default EditQuiz;

