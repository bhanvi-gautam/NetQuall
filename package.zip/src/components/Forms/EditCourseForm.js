import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import DeleteIcon from '@mui/icons-material/Delete';
import { encryptData, decryptData } from '../../assets/security/encryDecrypt';
import { useUpdateCourseMutation, useGetOnePostMutation, useDeletePostMutation, useGetPostsMutation } from '../rtk/AddSlice';
import { Button, Grid, Typography, Box, TextField, Alert, Paper } from '@mui/material';
import PostDetailsShimmer from '../Effects/PostDetailsShimmer';
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import { notifySuccess } from "../../toast";
import { ToastContainer } from "react-toastify";
import CourseDropDown from './Parts/CourseDropDown';


const EditForm = () => {
    let navigate = useNavigate();
    const { courseId } = useParams();
    const [semArr, setSemArr] = useState([]);
    const [getdata, { isLoading, isSuccess }] = useGetOnePostMutation();
    const [updateData] = useUpdateCourseMutation();
    const [deletePost] = useDeletePostMutation();
    const [info, setInfo] = useState(null);
    const [formData, setFormData] = useState(info);
    const encryptedData = localStorage.getItem("userId");
    const [search, setSearch] = useState("");
    const [sortBy, setSortBy] = useState([]);
    const [open, setOpen] = useState(false);
    const [open2, setOpen2] = useState(false);
    const [getCourse] = useGetPostsMutation();
    const [openAlert, setOpenAlert] = useState(false);
    const [courseArr, setCourseArr] = useState([]);
    const abc = async (value) => {
        console.log(courseId);
        const encryptedId = encryptData({ courseId });
        getdata({ courseId: encryptedId })
            .unwrap()
            .then((fetchPt) => {
                const fetchPosts = decryptData(fetchPt.data)
                console.log("hie--", fetchPosts)

                setInfo(fetchPosts);
                setFormData(fetchPosts)
                setSemArr(fetchPosts.userSemesters)
            })
            .catch((error) => {
                console.error('Error fetching data:', error);
            });

        await getCourse({
            search: search,
            sortBy: sortBy,
        }).unwrap().then((fetchPt) => {
            const temp = decryptData(fetchPt.data);
            temp.map((course) => {
                setCourseArr(prevCourseArr => [...prevCourseArr, course.courseName.toLowerCase()]);
            });
        });

        console.log('courseArr', courseArr)

        if (value) {
            notifySuccess("Data Updated!")
        }
    };

    useEffect(() => {
        abc();
    }, [courseId]);
    useEffect(() => {
        // console.log("semArr1==", semArr);
    }, [semArr]);
    useEffect(() => {

    }, [openAlert]);


    const deleteItem = async (courseId = 0, semesterId = 0, subjectId = 0) => {
        try {
            if (courseId && semesterId && subjectId) {
                const deleteInfo = { courseId, semesterId, subjectId }
                const encryptedData = encryptData(deleteInfo);
                await deletePost({ encryptedData }).unwrap().then((fetchPt) => {
                    abc();
                })
                handleClose2();
            }
            else if (courseId && semesterId) {
                const deleteInfo = { courseId, semesterId }
                const encryptedData = encryptData(deleteInfo);
                await deletePost({ encryptedData }).unwrap().then((fetchPt) => {
                    abc();
                })
                handleClose();

            }
            else {
                const deleteInfo = { courseId }
                const encryptedData = encryptData(deleteInfo);
                await deletePost({ encryptedData }).unwrap().then((fetchPt) => {
                    abc();
                })

            }

        } catch (error) {
            console.log("Error deleting data");
        }
    }
    const handleSemesterChange = (index, e) => {
        const semester = e.target.value;
        let newArray;
        setSemArr((prevArray) => {
            newArray = [...prevArray];
            newArray[index] = Number(semester);
            return newArray;
        });

        setFormData((prev) => {
            const newFormData = { ...prev };
            newFormData.userSemesters = newFormData.userSemesters.map((sem, i) => {
                return { ...sem, semesterNo: newArray[i] || sem.semesterNo };
            });
            return newFormData;
        });
    };


    const handleClickOpen = () => {
        setOpen(true);
    };
    const handleClickOpen2 = () => {
        setOpen2(true);
    };

    const handleClose = () => {
        setOpen(false);

        notifySuccess("Data Deleted!");
    };
    const handleClose2 = () => {
        setOpen2(false);

        notifySuccess("Data Deleted!");
    };
    useEffect(() => {
        //    abc();
    }, [handleClose, handleClose2])
    const handleSubjectChange = (semesterIndex, subjectIndex, e) => {
        const subjectName = e.target.value;
        console.log("id===", subjectIndex)

        setSemArr((prevSemArr) => {
            const newSemArr = { ...prevSemArr };//shallow copy?
            const semesterSubjects = newSemArr[semesterIndex]?.userSubjects || [];
            const newSubjects = [...semesterSubjects];
            console.log("semesterSubjects==", semesterSubjects)//no change
            newSubjects[subjectIndex] = { subjectName: subjectName };
            console.log("arrnewSub==", newSubjects);//change
            newSemArr[semesterIndex] = { ...newSemArr[semesterIndex], userSubjects: newSubjects };
            console.log("arrnewSem==", newSemArr);//no change

            return newSemArr;
        });
        // ----------------WILL WORK WITHOUT FORMDATA ALSO -----------------------------
        // ----------------YOU NEED TO UPDATE UPDATEDDATA IN HANDLEUPDATE -----------------------------
        setFormData((prev) => {
            const newFormData = { ...prev };
            newFormData.userSemesters = newFormData.userSemesters.map((sem, i) => {
                if (i === semesterIndex) {
                    const newUserSubjects = sem.userSubjects.map((sub, j) => {
                        return j === subjectIndex ? { id: sub.id, subjectName: subjectName } : sub;
                    });
                    return { ...sem, userSubjects: newUserSubjects };
                }
                return sem;
            });
            return newFormData;
        });
    };

    const handleChange = (value1, prevCourse) => {
        console.log("value1", value1);

        if (value1.toLowerCase().trim() === prevCourse.toLowerCase()) {
            console.log("1st")
            setFormData({ ...formData, courseName: prevCourse })
            return;
        }
        // console.log('courseArr===', courseArr)
        else if (courseArr.includes(value1.toLowerCase().trim())) {
            console.log("2nd")
            setOpenAlert(true);
            setFormData({ ...formData, courseName: prevCourse })
        }
        else {
            console.log("3rd")
            setOpenAlert(false)
            setFormData({ ...formData, courseName: value1.trim() })
        }
    };


    const handleUpdate = async (e) => {
        e.preventDefault();
        if (openAlert) {
            return;
        }
        else {
            const updatedFormData = {

                "courseId": formData.id,
                "courseName": formData.courseName,
                "semester": formData.userSemesters.map(sem => {
                    return {
                        "Id": sem.id,
                        "sem": sem.semesterNo,
                        "subject": sem.userSubjects.map(sub => {
                            return {
                                "id": sub.id,
                                "subjectName": sub.subjectName
                            };
                        })
                    }
                }),
            };
            const encryptedData = encryptData(updatedFormData);
            await updateData({ updatedFormData: encryptedData }).unwrap().then((data) => {
                abc(1000);
            });

        }

    }

    return (
        <>
            <Box className="w-full mb-12">
                <Box className= "relative md:pt-30 pb-32 pt-12"  style={{backgroundColor:'#0099CC'}}>
                    <Box
                        className="px-4"
                        sx={{
                            color: "white",
                            width: "100%",
                            position: "absolute",
                            bottom: 0,
                        }}
                    >
                        <Typography gutterBottom variant="h4" component="div">
                            View/Update Form Details
                        </Typography>
                    </Box>
                </Box>
                {isLoading && <PostDetailsShimmer />}

                {isSuccess &&
                    <form className="flex flex-col space-y-4" onSubmit={handleUpdate} style={{
                        backgroundColor: "rgb(255 255 255)",
                        padding: "16px",
                        height: "100vh",
                    }}>

                        {openAlert && <Alert severity="error" onClose={() => { setOpenAlert(false) }}>Course Already Exists</Alert>}

                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <Typography variant="h6">Course:</Typography>
                                <TextField
                                    type="text"
                                    name="courseName"
                                    defaultValue={info?.courseName}
                                    InputProps={{
                                        readOnly: true,
                                    }}
                                />
                            </Grid>

                            <Grid item
                                xs={12}
                                style={{
                                    display: "flex",
                                    alignItems: "center",
                                    justifyContent: "flex-start",
                                }}
                            >
                                <Typography style={{ marginRight: "10px", fontSize: "20px" }}>
                                    Change Course?
                                </Typography>
                                <TextField
                                    type="text"
                                    name="courseName"
                                    defaultValue={info?.courseName}
                                    onChange={(e) => handleChange(e.target.value, info?.courseName)}
                                />

                                {/* <CourseDropDown title={"Course"} onCourseChange={handleChange} defaultValue={info?.courseName}/> */}
                            </Grid>


                            {info?.userSemesters.map((sem, index1) => (
                                <Grid item xs={12} key={sem.id}>
                                    <Grid container spacing={2}>
                                        <Grid item xs={12} >
                                            
                                                <Typography variant="body1" style={{ marginLeft: '10px' }}>Semester No {index1 + 1}:</Typography>
                                                <TextField
                                                    type="number"
                                                    name="sem"
                                                    defaultValue={sem.semesterNo}
                                                    style={{ marginLeft: '10px' }}
                                                    onChange={(e) => handleSemesterChange(index1, e)}
                                                />
                                                <DeleteIcon onClick={handleClickOpen} />
                                            
                                            <Dialog
                                                open={open}
                                                onClose={handleClose}
                                                aria-labelledby="alert-dialog-title"
                                                aria-describedby="alert-dialog-description"
                                            >
                                                <DialogTitle id="alert-dialog-title">
                                                    {"Are you Sure You Want to Delete?"}
                                                </DialogTitle>
                                                <DialogContent>
                                                    <DialogContentText id="alert-dialog-description">
                                                        All the data inside will be deleted
                                                    </DialogContentText>
                                                </DialogContent>
                                                <DialogActions>
                                                    <Button onClick={handleClose}>Cancel</Button>
                                                    <Button onClick={(e) => deleteItem(courseId, sem.id)} autoFocus>
                                                        Delete
                                                    </Button>
                                                </DialogActions>
                                            </Dialog>
                                            <Grid item xs={12} key={sem.id}>
                                            {sem.userSubjects?.map((sub, index2) => (
                                                    <Grid container spacing={2}>
                                                        <Grid item xs={6}>
                                                            
                                                                <Typography variant="body1" style={{ marginLeft: '40px' }}>Subject Name:</Typography>
                                                                <TextField
                                                                    type="text"
                                                                    name="subjectName"
                                                                    style={{ marginLeft: '40px' }}
                                                                    defaultValue={sub.subjectName}
                                                                    onChange={(e) => handleSubjectChange(index1, index2, e)}
                                                                />
                                                                <DeleteIcon onClick={handleClickOpen2} />
                                                            
                                                            <Dialog
                                                                open={open2}
                                                                onClose={handleClose2}
                                                                aria-labelledby="alert-dialog-title"
                                                                aria-describedby="alert-dialog-description"
                                                            >
                                                                <DialogTitle id="alert-dialog-title">
                                                                    {"Are you Sure You Want to Delete?"}
                                                                </DialogTitle>
                                                                <DialogContent>
                                                                    <DialogContentText id="alert-dialog-description">
                                                                        All the data inside will be deleted
                                                                    </DialogContentText>
                                                                </DialogContent>
                                                                <DialogActions>
                                                                    <Button onClick={handleClose2}>Cancel</Button>
                                                                    <Button onClick={(e) => deleteItem(courseId, sem.id, sub.id)} autoFocus>
                                                                        Delete
                                                                    </Button>
                                                                </DialogActions>
                                                            </Dialog>
                                                        </Grid>
                                                    </Grid>
                                                
                                            ))}
                                            </Grid>
                                        </Grid>
                                    </Grid>
                                </Grid>
                            ))}
                            <Grid item xs={12}>
                                <Button
                                    type="submit"
                                    variant="contained"
                                    color="primary"
                                    sx={{ mt: 2, width: "150px" }}
                                >
                                    Submit
                                </Button>
                            </Grid>
                        </Grid>
                    </form>
                }
            </Box>
            <ToastContainer containerId="A" />
        </>
    );
};

export default EditForm;
