import React, { useState, useEffect } from "react";
import { useGetPostsMutation } from "../../rtk/AddSlice";
import { MenuItem, Grid } from "@mui/material";
import InputLabel from "@mui/material/InputLabel";
import Select from "@mui/material/Select";
import { decryptData } from "../../../assets/security/encryDecrypt";

const CourseDropDown = ({ title, onCourseChange ,defaultValue}) => {
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState([]);
  const [course, setCourse] = useState(0);
  const [getdata, { post1 }] = useGetPostsMutation();
  const [posts, setPosts] = useState(post1);

  const handleChange = (e) => {
    e.preventDefault();
    setCourse(e.target.value);
    console.log("e.target.value", e.target.value);
    onCourseChange(e.target.value);
  };

  const filteredData = async () => {
    try {
      const fetchPosts = await getdata({
        search: search,
        sortBy: sortBy,
      }).unwrap();
      const temp = decryptData(fetchPosts.data);
      setPosts(temp);
    } catch (error) {
      console.log(error);
    }
  };

  useEffect(() => {
    filteredData();
  }, []);

  return (
    <form>
      <Grid item xs={12}>
        <InputLabel id="demo-simple-select-label">{title}</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={course}
          label="Course"
          onChange={handleChange}
          defaultValue={defaultValue ? defaultValue: "Select-a-Course"}
          size={"small"}
          style={{ minWidth: 320 }}
          sx={{
            "& .MuiInput-root": {
              "& fieldset": {
                borderColor: "#000",
                borderWidth: 1,
              },
              "&:hover fieldset": {
                borderColor: "#000",
              },
              "&.Mui-focused fieldset": {
                borderColor: "#000",
              },
            },
            "& .MuiOutlinedInput-notchedOutline": {
              borderColor: "#000",
            },
          }}
        >
          {posts?.map((data) => {
            return (
              <MenuItem value={data.courseName}>{data.courseName}</MenuItem>
            );
          })}
        </Select>
      </Grid>
    </form>
  );
};

export default CourseDropDown;
