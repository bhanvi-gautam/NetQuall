import { Box, Button, Grid, TextField, Typography } from '@mui/material'
import React, { useState } from 'react'
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { useAddAnnouncementMutation } from '../rtk/AddSlice';
import { encryptData } from '../../assets/security/encryDecrypt';
import { notifyError, notifySuccess } from '../../toast'
import { ToastContainer } from 'react-toastify';
import { useNavigate } from 'react-router-dom';

const AddAnnouncement = () => {
  const navigate=useNavigate();
  const [sendData] = useAddAnnouncementMutation();
  const initialValues = {
    heading: "",
    description: "",
    showToStudents: false,
    showToTeachers: false,
  };

  const addingAnnouncementSchema = Yup.object().shape({
    heading: Yup.string().required("Heading is required"),
    description: Yup.string(),
    showToStudents: Yup.boolean(),
    showToTeachers: Yup.boolean(),
  }).test('at-least-one-checkbox', 'At least one checkbox must be selected', (value) => {
    return value.showToStudents || value.showToTeachers;
  }); 

  return (
    <Box className="w-full mb-12">
      <Box className="relative md:pt-30 pb-32 pt-12" style={{ backgroundColor: '#0099CC' }}>
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
            fontWeight: 700
          }}
        >
          <Typography gutterBottom variant="h4" component="div">Add New Announcement</Typography>
        </Box>
      </Box>

      <Formik
        initialValues={initialValues}
        validationSchema={addingAnnouncementSchema}
        onSubmit={async(values) => {
          console.log('values', values);
          if(!values.showToStudents && !values.showToTeachers){
            notifyError("Atleast make it available for one of the audience!");
            return;
          }
          const encryptedData = encryptData(values);
          sendData({ data: encryptedData }).unwrap().then((fetch) => {
            // notifySuccess("Announcement Added!");
            navigate('/')
          })
        }}
      >
        {({ errors, touched, isValid, dirty }) => {
          console.log('isValid', isValid)
          console.log('dirty', dirty)
          return (
            <Form className="flex flex-col space-y-4" style={{
              backgroundColor: "rgb(255 255 255)",
              padding: "16px",
              height: "100vh",
            }}>
              <Grid item xs={12} >
                <Typography variant="h6" sx={{mt:2,mb:1}}>Heading:</Typography>
                <Field
                  type="heading"
                  name="heading"
                  className={`border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150 ${errors.heading && touched.heading ? "input-error" : ""}`}
                  placeholder="Heading"
                />
                <ErrorMessage name="heading" component="span" className="error" style={{ color: "#ef2a2a" }} />
              </Grid>

              <Grid item xs={12}>
                <Typography variant="h6" sx={{mt:3 ,mb:1}}>Description:</Typography>
                <Field
                  as="textarea"
                  name="description"
                  className={`border-0 px-3 py-3 placeholder-blueGray-300 text-blueGray-600 bg-white rounded text-sm shadow focus:outline-none focus:ring w-full ease-linear transition-all duration-150 ${errors.description && touched.description ? "input-error" : ""}`}
                  placeholder="Description"
                />
                <ErrorMessage name="description" component="span" className="error" style={{ color: "#ef2a2a" }} />
              </Grid>

              <Grid item xs={12}>
              <Typography variant="h6" sx={{mt:3,mb:1}}>Show to:</Typography>
              <div style={{ display: "flex", justifyContent: "space-evenly" }}>
                <label>
                  <Field type="checkbox" name="showToStudents" />
                  Students
                </label>
                <label>
                  <Field type="checkbox" name="showToTeachers" />
                  Teachers
                </label>
              </div>

              <ErrorMessage name="showToStudents" component="div" />
            </Grid>

            <Grid item xs={12}>
            <button
                className={`text-white text-sm font-bold uppercase px-4 py-2 rounded shadow hover:shadow-lg outline-none focus:outline-none mr-1 mb-1 w-full ease-linear transition-all duration-150 ${
                  !(dirty && isValid)
                    ? "bg-gray-500 cursor-not-allowed"
                    : "bg-blue-500 hover:bg-blue-600"
                }`}
                type="submit"
                disabled={!(dirty && isValid)}
                style={{ backgroundColor: "#008aff", marginTop: "30px" }}
              >
                Submit
              </button>
            </Grid>
            </Form>
          )
        }}
      </Formik>
      <ToastContainer containerId="A" />
      <ToastContainer containerId="B" />
    </Box>
  )
}

export default AddAnnouncement
