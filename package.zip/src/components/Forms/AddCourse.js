import React, { useState } from "react";
import RemoveIcon from '@mui/icons-material/Remove';
import AddIcon from '@mui/icons-material/Add';
import { useAddNewPostMutation } from "../rtk/AddSlice";
import { useNavigate } from "react-router-dom";
import { Button, TextField, Grid, IconButton, Typography, Box } from "@mui/material";
import { encryptData, decryptData } from "../../assets/security/encryDecrypt";
import Alert from '@mui/material/Alert';


const AddCourse = () => {
  let navigate = useNavigate();
  const [formData, setFormData] = useState({ courseName: "", semester: [] });
  const[open,setOpen]=useState(false);
  const [alert,setAlert]=useState('');
  const [semesterField, setSemesterField] = useState([
    {
      sem: 0,
      subject: [{ subjectName: "" }],
    },
  ]);
  const [addNewPost] = useAddNewPostMutation();
  const addSemester = () => {
    const newSemesterField = {
      sem: 0,
      subject: [{ subjectName: "" }],
    };
    setSemesterField([...semesterField, newSemesterField]);
  };


  const addSubjects = (index) => {
    const newSubjectField = { subjectName: "" };
    const data = [...semesterField];
    data[index].subject = [...data[index].subject, newSubjectField];
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };

  const removeSubject = (semesterIndex, subjectIndex) => {
    if (subjectIndex > 0) {
      const data = [...semesterField];
      data[semesterIndex].subject.splice(subjectIndex, 1);
      setSemesterField(data);
    }
  };

  const removeSemester = (semesterIndex) => {
    if (semesterIndex > 0) {
      const data = [...semesterField];
      data.splice(semesterIndex, 1);
      setSemesterField(data);
    }
  }


  const handleSemesterChange = (index, e) => {
    let data = [...semesterField];
    data[index][e.target.name] = e.target.value;
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };

  const handleSubjectChange = (index1, index2, e) => {
    let data = [...semesterField];
    data[index1].subject[index2][e.target.name] = e.target.value;
    setSemesterField(data);

    setFormData({
      ...formData,
      semester: data.map((sem) => ({
        sem: sem.sem,
        subject: sem.subject.map((sub) => ({
          subjectName: sub.subjectName,
        })),
      })),
    });
  };


  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const courseName = e.target.elements.courseName.value;
      let encryptedId = localStorage.getItem('userId');
      let id = encryptData(encryptedId)
      const updatedFormData = {
        ...formData,
        courseName,
        "userID": id,
        "user_Id": id,
      };
      const encryptedData = encryptData(updatedFormData);
      await addNewPost({ updatedFormData: encryptedData }).unwrap();

      setFormData({ courseName: "", semester: [] });
      setSemesterField([
        {
          sem: 0,
          subject: [{ subjectName: "" }],
        },
      ]);
      navigate('/course');
    } catch (error) {
      console.log('error', error.data.message)
      setOpen(true);
      setAlert(error.data.message)
    }

  };



  return (
    <Box className="w-full mb-12">
      <Box className= "relative md:pt-30 pb-32 pt-12"  style={{backgroundColor:'#0099CC'}}>
        <Box
          className="px-4"
          sx={{
            color: "white",
            width: "100%",
            position: "absolute",
            bottom: 0,
          }}
        >
          <Typography gutterBottom variant="h4" component="div">
            Add New Course
          </Typography>

        </Box>
      </Box>
      {open && <Alert severity="error" onClose={() => {setOpen(false)}}>{alert}</Alert>}
      <form className="flex flex-col space-y-4" onSubmit={handleSubmit} style={{
        backgroundColor: "rgb(255 255 255)",
        padding: "16px",
        height: "100vh",
      }}>
        <Grid container spacing={2}>
          <Grid item xs={12}>
            <Typography variant="h6">Course:</Typography>
            <TextField
              type="text"
              name="courseName"
              required
              size={"small"}
              onChange={(e) =>
                setFormData({ ...formData, courseName: e.target.value })
              }
            />
          </Grid>
          {semesterField.map((semester, index1) => (
            <Grid item xs={12} key={semester.id}>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <Typography variant="body1" style={{ marginLeft: '10px' }}>Semester No {index1 + 1}:</Typography>
                  <TextField
                    type="number"
                    name="sem"
                    value={semester.sem}
                    size={"small"}
                    inputProps={{ min: "1" }}
                    onChange={(e) => handleSemesterChange(index1, e)}
                    required
                  />
                  <IconButton color="primary" onClick={() => addSemester()}>
                    <AddIcon />
                  </IconButton>
                  {semesterField.length > 1 && (
                    <IconButton
                      color="secondary"
                      onClick={() => removeSemester(index1)}
                    >
                      <RemoveIcon />
                    </IconButton>
                  )}
                  {semester.subject.map((sub, index2) => (
                    <Grid item xs={12} key={sub.id}>
                      <Grid container spacing={2}>
                        <Grid item xs={12}>
                          <Typography variant="body1" style={{ marginLeft: '20px' }}>Subject Name:</Typography>
                          <TextField
                            name="subjectName"
                            value={sub.subjectName}
                            size={"small"}
                            onChange={(e) => handleSubjectChange(index1, index2, e)}
                            style={{ marginLeft: '20px' }}
                          />
                          <IconButton
                            color="primary"
                            onClick={() => addSubjects(index1)}
                          >
                            <AddIcon />
                          </IconButton>
                          {semester.subject.length > 1 && (
                            <IconButton
                              color="secondary"
                              onClick={() => removeSubject(index1, index2)}
                            >
                              <RemoveIcon />
                            </IconButton>
                          )}
                        </Grid>
                      </Grid>
                    </Grid>
                  ))}
                </Grid>
              </Grid>
            </Grid>
          ))}
          <Grid item xs={12}>
            <Button
              type="submit"
              variant="contained"
              color="primary"
              sx={{ mt: 2, width: "150px" }}
            >
              Submit
            </Button>
          </Grid>
        </Grid>

      </form>
    </Box>



  );
};

export default AddCourse;
