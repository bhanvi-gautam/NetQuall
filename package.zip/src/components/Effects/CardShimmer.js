import React from "react";
import { ShimmerSimpleGallery } from "react-shimmer-effects";

const CardShimmer = () => {
  return (
    <div>
      <ShimmerSimpleGallery card imageHeight={200} />
    </div>
  );
};

export default CardShimmer;
