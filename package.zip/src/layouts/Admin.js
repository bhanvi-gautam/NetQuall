import React from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import HeaderStats from "../components/Headers/HeaderStats.js";
import AnnouncementPage from "../views/admin/AnnouncementPage.js";

export default function Admin() {
  return (
    <>
      <HeaderStats />
      <div>
      <AnnouncementPage/>
      </div>
    </>
  );
}
