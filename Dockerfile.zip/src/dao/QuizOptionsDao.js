const SuperDao = require('./SuperDao');
const models = require('../models');

const QuizOptions = models.quizOptions;

class QuizOptionsDao extends SuperDao {
    constructor() {
        super(QuizOptions);
    }
}
module.exports=QuizOptionsDao;