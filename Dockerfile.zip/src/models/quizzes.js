const {Model}=require('sequelize')


module.exports=(sequelize,DataTypes)=>{
    class quizzes extends Model{
        static associate(models){
            quizzes.hasMany(models.quizQuestions,{foreignKey:'quiz_Id',targetKey: 'id'})
            quizzes.belongsTo(models.userSubject,{foreignKey:'subject_Id',targetKey: 'id'})
            quizzes.belongsToMany(models.user,{
                through:'userQuizDetails',
            })
           
        }
    }

    quizzes.init(
        {
            uuid: DataTypes.UUID,
            quizName:DataTypes.STRING,
            quiz_marks:DataTypes.INTEGER,
            is_available: {
                type: DataTypes.INTEGER,
                defaultValue: '0',
                comment: 'Availability status: 0 = Not Available, 1 = Available',
            },
        },
        {
            sequelize,
            modelName:'quizzes',
            underscored:false,
        },
    );
    return quizzes;
}