const {Model}=require('sequelize')


module.exports=(sequelize,DataTypes)=>{
    class quizOptions extends Model{
        static associate(models){
            quizOptions.belongsTo(models.quizQuestions,{foreignKey:'question_Id',targetKey: 'id'})
        }
    }

    quizOptions.init(
        {
            uuid: DataTypes.UUID,
            option_text:DataTypes.TEXT('tiny'),
            is_correct:{type:DataTypes.BOOLEAN, defaultValue: false},
        },
        {
            sequelize,
            modelName:'quizOptions',
            underscored:false,
        },
    );
    return quizOptions;
}