const {Model}=require('sequelize')


module.exports=(sequelize,DataTypes)=>{
    class quizQuestions extends Model{
        static associate(models){
            quizQuestions.belongsTo(models.quizzes,{foreignKey:'quiz_Id',targetKey:'id'})
            quizQuestions.hasMany(models.quizOptions,{foreignKey:'question_Id',targetKey:'id'})
        }
    }

    quizQuestions.init(
        {
            uuid: DataTypes.UUID,
            question:DataTypes.TEXT('tiny'),
            question_marks:DataTypes.INTEGER,
            question_type:{
                type: DataTypes.BOOLEAN,
                defaultValue: false,
                comment: 'false = Single Answer, true = Multiple Answers',
            },
        },
        {
            sequelize,
            modelName:'quizQuestions',
            underscored:false,
        },
    );
    return quizQuestions;
}