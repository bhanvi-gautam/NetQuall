const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class Announcement extends Model {
        /**
         * Helper method for defining associations.
         * This method is not a part of Sequelize lifecycle.
         * The `models/index` file will call this method automatically.
         */
    }

    Announcement.init(
        {
            uuid: DataTypes.UUID,
            announcement_heading: DataTypes.STRING,
            announcement_description: DataTypes.STRING,
        },
        {
            sequelize,
            modelName: 'announcement',
            underscored: true,
        },
    );
    return Announcement;
};
