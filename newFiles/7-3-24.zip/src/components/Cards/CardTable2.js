import React from "react";
import { useNavigate,Link } from "react-router-dom";
import EditIcon from '@mui/icons-material/Edit';
import Button from '@mui/material/Button';
import MoreVertIcon from '@mui/icons-material/MoreVert';
import DeleteIcon from '@mui/icons-material/Delete';
import NoDataFound from "./NoDataFound";
import dummyProfile from "../../assets/img/dummyProfile.png";
import { useEnableDisableUserMutation } from "../rtk/AddSlice";
import CryptoJS from "crypto-js";

export default function CardTable2({
    title,
    content,
    heading,
    errorMessg,
}) {

    const [sendData]=useEnableDisableUserMutation();
    const secretKey = '6d090796-ecdf-11ea-adc1-0242ac112345';
    let navigate = useNavigate();
    const encryptData = (data) => {
        const encryptedData = CryptoJS.AES.encrypt(JSON.stringify(data), secretKey).toString();
        return encryptedData;
    };

    const decryptData = (encryptedData) => {
        console.log("temp1===", encryptedData);
        const decryptedData = CryptoJS.AES.decrypt(encryptedData, secretKey).toString(CryptoJS.enc.Utf8);
        let decryptedObject;
        try {
            decryptedObject = JSON.parse(decryptedData);
            console.log("decryptedObject==", decryptedObject);
        } catch (error) {
            // Handle JSON parsing error if needed
            console.error('Failed to parse decrypted data:', error);
            return null;
        }
        return decryptedObject;
    };
    const handleDisableUser=async(id)=>{
        console.log("id====",id);
        const encryptedUserId = encryptData(id);
        await sendData(encryptedUserId).unwrap();
       
            navigate('/viewTeacher');
       

    }
    let flag = 0;
    console.log('content', content)
    return (
        <>
            <div
                className={
                    "relative flex flex-col min-w-0 break-words w-full mb-6 shadow-lg rounded " +
                    "bg-white"
                }
            >
                <div className="rounded-t mb-0 px-4 py-3 border-0">
                    <div className="flex flex-wrap items-center">
                        <div className="relative w-full px-4 max-w-full flex-grow flex-1">
                            <h3 className={"font-semibold text-lg text-blueGray-700"}>
                                {title}
                            </h3>
                        </div>
                    </div>
                </div>
                <div className="block w-full overflow-x-auto">
                    {/* Projects table */}
                    <table className="items-center w-full bg-transparent border-collapse">
                        <thead>
                            <tr>
                                {heading?.map((data) => (
                                    <th
                                        className={
                                            "px-6 align-middle border border-solid py-3 text-xs uppercase border-l-0 border-r-0 whitespace-nowrap font-semibold text-left bg-blueGray-50 text-blueGray-500 border-blueGray-100"
                                        }
                                    >
                                        {data}
                                    </th>
                                ))}
                            </tr>
                        </thead>
                        <tbody>
                            {content.map((data, index) => {
                                flag++;
                                return (
                                    <tr key={index}>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.users[0].profile ? (
                                                <img
                                                    src={`http://localhost:3003/images/${data.users[0].profile}`}
                                                    width="100"
                                                    height="100"
                                                />
                                            ) : (
                                                <img src={dummyProfile} width="100" height="100" />
                                            )}
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.users[0].first_name + " " + data.users[0].last_name}
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.users[0].email}
                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.users[0].userSubject.subjectName}

                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.users[0].userSubject.userSemester?.semesterNo || ""}

                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            {data.courseName}

                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                        <Link to={`/viewTeacher/edit/${data.users[0].id}`}><EditIcon /></Link>

                                        </td>
                                       
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            <DeleteIcon />

                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            <MoreVertIcon />

                                        </td>
                                        <td className="border-t-0 px-6 align-middle border-l-0 border-r-0 text-xs whitespace-nowrap p-4">
                                            <>
                                            {data.users[0].is_available===1 ?
                                                <Button variant="contained" color="success">
                                                    Accepted
                                                </Button> :
                                                <Button variant="outlined" color="error" onClick={()=>handleDisableUser(data.users[0].id)}>
                                                    Unaccepted
                                                </Button>
                            }
                                            </>

                                        </td>
                                    </tr>
                                );

                            })}


                        </tbody>
                    </table>

                    {flag === 0 && <NoDataFound content={errorMessg} />}
                </div>
            </div>
        </>
    );
}