const express = require('express');
const cors = require('cors');
const passport = require('passport');
const httpStatus = require('http-status');
const routes = require('./route');
const Jimp = require('jimp');
const { jwtStrategy } = require('./config/passport');
const { errorConverter, errorHandler } = require('./middlewares/error');
const ApiError = require('./helper/ApiError');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser')
// const CryptoJS=require("crypto-js");

// Encrypt
// var ciphertext = CryptoJS.AES.encrypt(JSON.stringify(data), 'my-secret-key@123').toString();
  
// // Decrypt
// var bytes = CryptoJS.AES.decrypt(ciphertext, 'my-secret-key@123');
// var decryptedData = JSON.parse(bytes.toString(CryptoJS.enc.Utf8));

const winston = require('winston');
const { createLogger, format, transports } = winston;

process.env.PWD = process.cwd();

const app = express();

// enable cors
app.use(cors());
app.options('*', cors());
app.use(express.urlencoded({ extended: true, limit: '50mb' }));
app.use(express.json({ limit: '50mb' }));
const maxRequestBodySize = '50mb';
app.use(bodyParser.json({ limit: maxRequestBodySize }));
app.use(bodyParser.urlencoded({ limit: maxRequestBodySize, extended: true }));


const morgan = require('morgan');
const DailyRotateFile = require('winston-daily-rotate-file');
const userAgentParser = require('ua-parser-js');
// const morganBody = require('morgan-body');

// Define custom colorization options
const customColors = {
	info: 'blue',
	warn: 'yellow',
	error: 'red',
	debug: 'magenta',
	customLogLevel: 'green', // Custom log level with a green color
};

// Create a custom colorizer function
const customColorizer = format.colorize({ all: true, colors: customColors });

// Define custom timestamp format
const customTimestamp = format.timestamp({ format: 'MM/DD/YYYY HH:mm:ss A' });

// Create a log format for winston
const logFormat = format.combine(
	customColorizer,
	customTimestamp,
	format.align(),
	format.printf(
		(info) =>
			`${info.timestamp} ${info.level}: ${info.message} - ` +
			`Client IP: ${info.clientIP || 'N/A'}, ` +
			`HTTP Method: ${info.httpMethod || 'N/A'}, ` +
			`URL: ${info.url || 'N/A'}, ` +
			`HTTP Status: ${info.httpStatus || 'N/A'}, ` +
			`Response Size: ${info.responseSize || 'N/A'}, ` +
			`Referer: ${info.referer || 'N/A'}, ` +
			`User-Agent: ${info.userAgent || 'N/A'}`,
	)
);

// Create a transport for rotating log files
const fileTransport = new DailyRotateFile({
	filename: 'logs/application-%DATE%.log',
	datePattern: 'YYYY-MM-DD',
	zippedArchive: true,
	maxSize: '20m', // Rotate log files when they reach 20MB
	maxFiles: '14d', // Keep logs for up to 14 days
	dirname: 'logs', // Directory to store log files
	format: logFormat,
	level: 'info',
});


// Create a logger for winston
const winstonLogger = createLogger({
	transports: [fileTransport], // Remove the esTransport here
});

// Create a custom stream for morgan using Winston's log method

const morganStream = {
	write: (message) => {
		// Log the message using Winston
		winstonLogger.info(message.trim());

		// Optionally, you can parse the message for additional information
		// and save header and body parameters to the database or any other storage
		const logInfo = message.split(' - ');
		if (logInfo.length >= 2) {
			const logMessage = logInfo[1].trim();
			const requestInfoMatch = logMessage.match(/"(.+)" (.+) (.+) "([^"]+)" "([^"]+)"/);
			if (requestInfoMatch && requestInfoMatch.length === 6) {
				const httpMethod = requestInfoMatch[2];
				const url = requestInfoMatch[1];
				const httpStatus = requestInfoMatch[3];
				const responseSize = requestInfoMatch[4];
				const referer = requestInfoMatch[5];

				// Extract User-Agent from the Morgan message
				const userAgentMatch = logMessage.match(/"([^"]+)"$/);
				const userAgent = userAgentMatch ? userAgentMatch[1] : 'N/A';

				// Extract Client IP from Morgan message
				const clientIPMatch = logMessage.match(/^\s*([\d.:]+)\s+/);
				const clientIP = clientIPMatch ? clientIPMatch[1] : 'N/A';

				// Log the message with additional information
				winstonLogger.info(logMessage, {
					clientIP,
					httpMethod,
					url,
					httpStatus,
					responseSize,
					referer,
					userAgent,
				});

				// Save header and body parameters to the database or any other storage
				const headerParams = message; // Modify this to access actual headers
				const bodyParams = message;   // Modify this to access actual body
				//console.log('Header Parameters:', headerParams);
				//console.log('Body Parameters:', bodyParams);
			}
		}
	},
};


// Use the custom stream for morgan middleware
app.use(morgan('combined', { stream: morganStream }));



//save api request data in file
// Create a log directory if it doesn't exist
const logDirectory = path.join(__dirname, 'logs');
if (!fs.existsSync(logDirectory)) {
	fs.mkdirSync(logDirectory);
}

// Set up morgan to log requests (optional)
 app.use(morgan('dev'));




// Define the path to the directory containing your images
const imagesDirectory = path.join(__dirname, 'utils', 'images');
app.use('/images', async (req, res, next) => {
    const imagePath = path.join(imagesDirectory, req.url);
    try {
        const image = await Jimp.read(imagePath);
        image.resize(80, Jimp.AUTO).flip(true,false);
        // Compress the image
        image.quality(20);
        const compressedBuffer = await image.getBufferAsync(Jimp.MIME_PNG);
        res.type('image/png').send(compressedBuffer);
    } catch (error) {
        next(error);
    }
});

// Middleware to serve static files in the 'images' directory
app.use('/images', express.static(imagesDirectory)); 


app.use(express.static(`${process.env.PWD}/public`));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// jwt authentication
app.use(passport.initialize());
passport.use('jwt', jwtStrategy);

app.get('/', async (req, res) => {
    res.status(200).send('Congratulations! API is working!');
});
app.use('/api', routes);

// send back a 404 error for any unknown api request
app.use((req, res, next) => {
    next(new ApiError(httpStatus.NOT_FOUND, 'Not found'));
});

// convert error to ApiError, if needed
app.use(errorConverter);







// handle error
app.use(errorHandler);
const db = require('./models');

// Uncomment this line if you want to sync database model
// db.sequelize.sync()
//  db.sequelize.sync({alter: true})

module.exports = app;
