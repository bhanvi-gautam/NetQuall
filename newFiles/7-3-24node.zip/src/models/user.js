const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class user extends Model {
        static associate(models) {
            user.belongsTo(models.userCourse,{foreignKey: 'course_Id', targetKey: 'id' })
            user.belongsTo(models.userSubject,{foreignKey: 'subject_Id', targetKey: 'id' })
           
        }
    }
    user.init(
        {
            uuid: DataTypes.UUID,
            profile: { type: DataTypes.STRING, defaultValue: null },
            first_name: DataTypes.STRING,
            last_name: DataTypes.STRING,
            email: DataTypes.STRING,
            password: DataTypes.STRING,
            status: DataTypes.INTEGER,
            email_verified: DataTypes.INTEGER,
            address: DataTypes.STRING,
            phone_number: DataTypes.INTEGER,
            otp_generated: { type: DataTypes.STRING, defaultValue: '0' },
            
            is_available: {
                type: DataTypes.INTEGER,
                defaultValue: '1',
                comment: 'Availability status: 0 = Not Available, 1 = Available',
            },
            is_deleted: { type: DataTypes.INTEGER, defaultValue: '0' },
        },
        {
            sequelize,
            modelName: 'user',
            underscored: false,
        },
    );
       
    return user;
};