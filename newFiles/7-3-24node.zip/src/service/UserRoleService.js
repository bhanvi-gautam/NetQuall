const UserDao = require("../dao/UserDao");
const UserRoleDao = require("../dao/UserRoleDao");
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { response } = require('express');
const logger = require('../config/logger');
const httpStatus = require('http-status');

class UserRoleService {
    constructor() {
        this.userDao = new UserDao();
        this.userRoleDao = new UserRoleDao();
    }

    getRole=async(req)=>{
        try {
            const where={id:2};
            
            const temp=await this.userRoleDao.findOneByWhere(where);
            if (temp.role_name) {
                return responseHandler.returnSuccess(httpStatus.OK, 'Role fetched successfully', temp.role_name);
            }

        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR, 'Error fetching role');
        }
    }
}



module.exports = UserRoleService;