const SuperDao = require('./SuperDao');
const models = require('../models');
const { Op } = require('sequelize');
const logger = require('../config/logger');
const userCourse = models.userCourse;
const userSemester = models.userSemester;
const userSubject = models.userSubject;
const user = models.user;

class UserCourseDao extends SuperDao {
    constructor() {
        super(userCourse);
    }
    async getParticularEducation(courseId) {

        return userCourse.findOne({
            where: {
                id: courseId
            },
            attributes: ['id', 'courseName'],
            include: [{
                model: userSemester,
                // required: false,
                attributes: ['id', 'semesterNo'],

                include: [{
                    model: userSubject,
                    attributes: ['id', 'subjectName'],
                }]
            }]
        })
            .then((result) => {
                return result;
            })
            .catch((e) => {
                logger.error(e);
                console.log(e);
            });
    }

    async getEducationList(requestWhere) {
        // let {where} = requestWhere;
        console.log(requestWhere);
        return userCourse.findAll({
            where:
            {
                courseName: {
                    [Op.startsWith]: requestWhere.search
                }
            }
            ,

            attributes: ['id', 'courseName'],
            include: [{
                model: userSemester,
                // required: false,
                attributes: ['id', 'semesterNo'],

                include: [{
                    model: userSubject,
                    attributes: ['id', 'subjectName'],
                }]
            }],
            order: requestWhere.sortBy.length === 2 ? [requestWhere.sortBy] : [['id', 'ASC']],
        })
            .then((result) => {
                return result;
            })
            .catch((e) => {
                logger.error(e);
                console.log(e);
            });
    }
    async findSubject(requestWhere) {
        console.log('requestWhere', requestWhere)
        try {
            const result = await userCourse.findAll({
                
                where: requestWhere.courseId ? 
                {
                    id: requestWhere.courseId
                } :{},
                attributes: ['id', 'courseName'],
                include: [{
                    model: user,
                    where:requestWhere.id?
                    {
                        id:requestWhere.id,
                        
                    }:
                    {
                        role_Id: requestWhere.roleId
                    },
                    attributes: ['id', 'first_name', 'last_name', 'email', 'address', 'phone_number', 'profile','is_available'],
                    include: [{
                        model: userSubject,
                        attributes: ['id', 'subjectName'],

                        include:[{
                            model:userSemester,
                            attributes:['id','semesterNo']
                        }]
                    }]
                }]
            });
            return result;
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }

     async isStudentExists(req){

        try {
            return userCourse.count({
                where:{
                    courseName:req.oldCourse
                },
                include:[{
                    model:user,
                    where:{
                        first_name:req.firstName,
                        last_name:req.lastName
                    }
                }]
            }).then((count) => {
                if (count != 0) {
                    return true;
                }
                return false;
            });
          
        } catch (error) {
            logger.error(error);
            throw error;
        }
    }
}

module.exports = UserCourseDao;