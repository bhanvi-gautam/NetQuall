
const UserSubjectDao = require("../dao/userSubjectDao");
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { response } = require('express');
const logger = require('../config/logger');
const httpStatus = require('http-status');

class UserSubject {
    constructor() {
        this.userSubjectDao = new UserSubjectDao();
    }

    // getSubjectName = async (req) => {
    //     try {
            
    //         const name = await this.userSubjectDao.findById(req);

    //         if (name.dataValues.subjectName) {
    //             return responseHandler.returnSuccess(httpStatus.OK, 'Role fetched successfully',name.dataValues.subjectName);
    //         }

    //     } catch (e) {
    //         logger.error(e);
    //         return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR, 'Error fetching subject Name');
    //     }
    // }
}



module.exports = UserSubject;