// const SuperDao = require('./SuperDao');
// const models = require('../models');

// const UserTeacherDetails = models.userTeacherDetails;

// class UserTeacherDetailsDao extends SuperDao {
//     constructor() {
//         super(UserTeacherDetails);
//     }
// }
// module.exports=UserTeacherDetailsDao;