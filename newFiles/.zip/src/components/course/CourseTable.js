import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
// import CardTable from '../Cards/CardTable'
import CardItem from "../Cards/CardItem";
import Dropdown from "react-bootstrap/Dropdown";
import { useGetPostsMutation, useDeletePostMutation } from "../rtk/AddSlice";
import CryptoJS from "crypto-js";
import Typography from "@mui/material/Typography";
import LmsShimmer from "../Effects/TableShimmer";

const CourseTable = () => {
  let navigate = useNavigate();
  const [getdata, { isLoading, isSuccess, post }] = useGetPostsMutation();
  // const [deleteData] = useDeletePostMutation();
  const [posts, setPosts] = useState(post);
  // const [courseIdToDelete, setCourseIdToDelete] = useState(null);
  const [search, setSearch] = useState("");
  const [sortBy, setSortBy] = useState([]);
  const secretKey = "6d090796-ecdf-11ea-adc1-0242ac112345";

  const encryptData = (data) => {
    const encryptedData = CryptoJS.AES.encrypt(
      JSON.stringify(data),
      secretKey
    ).toString();
    return encryptedData;
  };

  const decryptData = (encryptedData) => {
    const decryptedData = CryptoJS.AES.decrypt(
      encryptedData,
      secretKey
    ).toString(CryptoJS.enc.Utf8);
    let decryptedObject;
    try {
      decryptedObject = JSON.parse(decryptedData);
    } catch (error) {
      // Handle JSON parsing error if needed
      console.error("Failed to parse decrypted data:", error);
      return null;
    }
    return decryptedObject;
  };
  const filteredData = async () => {
    const fetchPosts = await getdata({
      search: search,
      sortBy: sortBy,
    }).unwrap();
    const temp = decryptData(fetchPosts.data);
    setPosts(temp);
  };

  useEffect(() => {
    filteredData();
  }, [sortBy]);
  const handleSearchChange = (e) => {
    setSearch(e.target.value);
  };

  const handleSearch = async (e) => {
    e.preventDefault();
    filteredData();
  };

  // const dropdown = (

  //     <Dropdown>
  //         <Dropdown.Toggle variant="success" id="dropdown-basic">
  //             Sort By
  //         </Dropdown.Toggle>

  //         <Dropdown.Menu>
  //             <Dropdown.Item onClick={() => setSortBy(['courseName', 'desc'])}>Course Name (Z-A) </Dropdown.Item>
  //             <Dropdown.Item onClick={() => setSortBy(['courseName', 'asc'])}>Course Name(A-Z)</Dropdown.Item>
  //             <Dropdown.Item onClick={() => setSortBy('')}>Remove</Dropdown.Item>
  //         </Dropdown.Menu>
  //     </Dropdown>

  // )
  // const deleteCourse = async () => {
  //     if (courseIdToDelete) {
  //         let courseId = courseIdToDelete;
  //         setTimeout(async () => {
  //             const deleteInfo={ courseId }
  //             const encryptedData=encryptData(deleteInfo);
  //             await deleteData({ encryptedData }).unwrap();
  //         }, 100);
  //         setCourseIdToDelete(null);
  //         var bootstrapModal = bootstrap.Modal.getInstance(modalRef.current);
  //         bootstrapModal.hide();
  //         navigate('/viewCourses');
  //     }
  //     else {
  //         console.log("No course selected for deletion");
  //     }
  // }

  const heading = [
    "Course Name",
    "About Course",
    "Faculty Members",
    "Students Enrolled",
  ];

  return (
    <div className="w-full mb-12 px-4">
      {isLoading && <LmsShimmer row={10} col={4} />}

      {isSuccess && (
        <>
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <div style={{ color: "white", width: "100%" }}>
              <Typography gutterBottom variant="h3" component="div">
                All Courses
              </Typography>
            </div>
            <br />

            {posts?.map((data, index) => (
              <div key={index}>
                <CardItem courseId={data.id} content={data.courseName} />
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  );
};

export default CourseTable;
