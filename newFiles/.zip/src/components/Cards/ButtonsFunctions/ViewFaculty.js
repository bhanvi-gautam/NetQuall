import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import LockIcon from "@mui/icons-material/Lock";
import { useGetUsersMutation } from "../../rtk/AddSlice";
import CryptoJS from "crypto-js";
import CardTable from "../CardTable";
import CardShimmer from "../../Effects/CardShimmer";

const ViewFaculty = () => {
  const { course_Id } = useParams();
  const [getdata, { isLoading, isSuccess, post }] = useGetUsersMutation();
  const [posts, setPosts] = useState(post);
  const secretKey = "6d090796-ecdf-11ea-adc1-0242ac112345";

  const encryptData = (data) => {
    const encryptedData = CryptoJS.AES.encrypt(
      JSON.stringify(data),
      secretKey
    ).toString();
    return encryptedData;
  };

  const decryptData = (encryptedData) => {
    const decryptedData = CryptoJS.AES.decrypt(
      encryptedData,
      secretKey
    ).toString(CryptoJS.enc.Utf8);
    let decryptedObject;
    try {
      decryptedObject = JSON.parse(decryptedData);
      console.log("decryptedObject==", decryptedObject);
    } catch (error) {
      // Handle JSON parsing error if needed
      console.error("Failed to parse decrypted data:", error);
      return null;
    }
    return decryptedObject;
  };
  const courseId = decryptData(course_Id);
  console.log(courseId);

  const abc = async () => {
    const fetchPosts = await getdata({
      filters: [false, false],
      search: "",
      sortBy: [],
    }).unwrap();
    const temp = decryptData(fetchPosts.data);

    setPosts(temp);
  };

  useEffect(() => {
    abc();
  }, []);

  return (
    <>
      <div className="w-full mb-12 px-4">
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <CardTable
              title={"List of Faculty Members"}
              content={posts}
              heading={[
                "Profile",
                "Faculty Name",
                "Email",
                "Address",
                "Phone number",
              ]}
              courseId={courseId}
              role={2}
              errorMessg={"No Faculty available for this Course yet!"}
            />
          </div>
        )}
      </div>
    </>
  );
};

export default ViewFaculty;
