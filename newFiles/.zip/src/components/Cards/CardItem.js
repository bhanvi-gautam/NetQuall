import * as React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import "./CardItem.css";
import ViewCourseDetail from "./ButtonsFunctions/ViewCourseDetail";
import viewCourses from "../../assets/img/viewCourses.png";
import viewStudent from "../../assets/img/viewStudent.png";
import teacher from "../../assets/img/teacher.png";
import CryptoJS from "crypto-js";
const ActionAreaCard = ({ key, courseId, content }) => {
  const navigate = useNavigate();
  const [isOpen, setIsOpen] = useState(false);

  const secretKey = "6d090796-ecdf-11ea-adc1-0242ac112345";

  const encryptData = (data) => {
    const encryptedData = CryptoJS.AES.encrypt(
      JSON.stringify(data),
      secretKey
    ).toString();
    return encryptedData;
  };

  const decryptData = (encryptedData) => {
    const decryptedData = CryptoJS.AES.decrypt(
      encryptedData,
      secretKey
    ).toString(CryptoJS.enc.Utf8);
    let decryptedObject;
    try {
      decryptedObject = JSON.parse(decryptedData);
      console.log("decryptedObject==", decryptedObject);
    } catch (error) {
      // Handle JSON parsing error if needed
      console.error("Failed to parse decrypted data:", error);
      return null;
    }
    return decryptedObject;
  };

  const handleClick = () => {
    setIsOpen(!isOpen);
  };

  const encryptedId = encryptData(courseId);

  const handleViewStudent = () => {
    const encryptedData = encryptData(courseId);
    navigate(`/course/viewStudents/${encryptedData}`);
  };

  const handleViewFaculty = () => {
    const encryptedId = encryptData(courseId);
    navigate(`/course/viewFaculty/${encryptedId}`);
  };

  return (
    <Card
      key={courseId}
      sx={{ maxWidth: 240, transition: "max-width 0.3s" }}
      className="custom-card"
      onClick={handleClick}
    >
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          <div style={{ margin: "10px" }}>{content}</div>
        </Typography>

        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <img src={teacher} onClick={handleViewFaculty} className="image" />
          <img
            src={viewStudent}
            onClick={handleViewStudent}
            className="image"
          />
        </div>
      </CardContent>

      {isOpen && (
        <CardContent style={{ height: "500px" }}>
          <div className="card-content">
            <ViewCourseDetail course_Id={encryptedId} />
          </div>
        </CardContent>
      )}
    </Card>
  );
};
export default ActionAreaCard;
