import React from "react";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";

import "@fortawesome/fontawesome-free/css/all.min.css";
// import "./assets/styles";
import "./assets/styles/tailwind.css";

// layouts

import Admin from "./layouts/Admin.js";

// views without layouts

import Landing from "./views/Landing.js";
import Profile from "./views/Profile.js";

import ReactDOM from "react-dom/client";

import { createRoot } from "react-dom";
import Login from "./views/auth/Login.js";
import Register from "./views/auth/Register.js";
import Dashboard from "./views/admin/Dashboard.js";
import Maps from "./views/admin/Maps.js";
import Settings from "./views/admin/Settings.js";
import Tables from "./views/admin/Tables.js";
import ForgotPassword from "./views/auth/ForgotPassword.js";
import ResetPassword from "./views/auth/ResetPassword.js";
import { Provider } from "react-redux";
import { store } from "./components/rtk/store.js";
import CourseTable from "./components/course/CourseTable.js";
import ViewCourseDetail from "./components/Cards/ButtonsFunctions/ViewCourseDetail.js";
import ViewFaculty from "./components/Cards/ButtonsFunctions/ViewFaculty.js";
import ViewStudents from "./components/Cards/ButtonsFunctions/ViewStudents.js";
import Sidebar from "./components/Sidebar/Sidebar.js";
import AdminNavbar from "./components/Navbars/AdminNavbar.js";
import FooterAdmin from "./components/Footers/FooterAdmin.js";

// Define your components such as Admin, Auth, Landing, Profile, Index

const App = () => {
  const routes = [
    { path: "/", element: <Admin /> },
    { path: "/profile", element: <Profile /> },
    {
      path: "/course/viewCourseDetail/:course_Id",
      element: <ViewCourseDetail />,
    },
    {
      path: "/course/viewFaculty/:course_Id",
      element: <ViewFaculty />,
    },
    {
      path: "/course/viewStudents/:course_Id",
      element: <ViewStudents />,
    },
    // { path: "/auth/register", element: <Register /> },
    // { path: "/admin/dashboard", element: <Dashboard /> },
    { path: "/admin/maps", element: <Maps /> },
    // { path: "/admin/settings", element: <Settings /> },
    { path: "/course", element: <CourseTable /> },
  ];
  const token = localStorage.getItem("token");

  return (
    <Provider store={store}>
      <BrowserRouter>
        {!token ? (
          <>
            <Routes>
              <Route path="/" element={<Landing />} />
              <Route path="/login" element={<Login />} />
              <Route path="/forgotPassword" element={<ForgotPassword />} />
              <Route
                path="/resetPassword/:emailid"
                element={<ResetPassword />}
              />
            </Routes>
          </>
        ) : (
          <>
            <Sidebar />
            <div className="relative md:ml-64 bg-blueGray-100">
              <AdminNavbar />
              {/* <HeaderStats /> */}

              <Routes>
                {routes.map((route, index) => (
                  <Route
                    key={index}
                    path={route.path}
                    element={route.element}
                  />
                ))}
              </Routes>
            </div>
            {/* <div className="px-4 md:px-10 mx-auto w-full -m-24">
                {/* <FooterAdmin />
              </div> */}
          </>
        )}
      </BrowserRouter>
    </Provider>
  );
};

// Use createRoot to render the root of your React application
createRoot(document.getElementById("root")).render(<App />);
