import * as React from "react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
import Typography from "@mui/material/Typography";
import { CardActionArea } from "@mui/material";
import "./CardItem.css";
import viewStudent from "../../assets/img/viewStudent.png";
import teacher from "../../assets/img/teacher.png";
import {encryptData} from '../../assets/security/encryDecrypt';
const ActionAreaCard = ({ key, courseId, content }) => {
  const navigate = useNavigate();
  // const [isOpen, setIsOpen] = useState(false);
  // const handleClick = () => {
  //   setIsOpen(!isOpen);
  // };

  const encryptedId = encryptData(courseId);

  const handleViewStudent = () => {
    // const encryptedData = encryptData(courseId);
    navigate(`/course/viewStudents/${courseId}`);
  };

  const handleViewFaculty = () => {
    const encryptedId = encryptData(courseId);
    console.log('courseId', courseId)
    navigate(`/course/viewFaculty/${courseId}`);
  };

  return (
    <Card
      key={courseId}
      sx={{ maxWidth: 240, transition: "max-width 0.3s" }}
      className="custom-card"
      // onClick={handleClick}
    >
      <CardContent>
        <Typography gutterBottom variant="h5" component="div">
          <div style={{ margin: "10px" }}>{content}</div>
        </Typography>

        <div style={{ display: "flex", justifyContent: "space-between" }}>
          <img src={teacher} onClick={handleViewFaculty} className="image" />
          <img
            src={viewStudent}
            onClick={handleViewStudent}
            className="image"
          />
        </div>
      </CardContent>

      {/* {isOpen && (
        <CardContent style={{ height: "500px" }}>
          <div className="card-content">
            <ViewCourseDetail course_Id={encryptedId} />
          </div>
        </CardContent>
      )} */}
    </Card>
  );
};
export default ActionAreaCard;
