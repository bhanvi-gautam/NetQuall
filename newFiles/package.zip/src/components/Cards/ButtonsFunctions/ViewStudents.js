import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { useGetUserSubjectMutation } from "../../rtk/AddSlice";
import {decryptData,encryptData} from "../../../assets/security/encryDecrypt";
import CardTable from "../CardTable";
import CardShimmer from "../../Effects/CardShimmer";

const ViewStudents = () => {
  const { courseId } = useParams();
  const [getdata, { isLoading, isSuccess, post }] = useGetUserSubjectMutation();
  const [posts, setPosts] = useState(post);

  // const courseId = encryptData(course_Id);

  const abc = async () => {
    const payload={courseId:courseId, roleId:'3'}
    // const encryptedData=encryptData(payload);
    const fetchPosts = await getdata(payload).unwrap();
    // const temp = decryptData(fetchPosts.data);
    setPosts(fetchPosts);
  };
  useEffect(() => {
    abc();
  }, []);

  return (
    <>
      <div className="w-full mb-12 px-4">
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <CardTable
              title={"List of Students"}
              content={posts?.data}
              heading={[
                "Profile",
                "Student Name",
                "Email",
                "Address",
                "Phone number",
              ]}
              role={3}
              
              errorMessg={"No Student enrolled under this Course yet!"}
            />
          </div>
        )}
      </div>
    </>
  );
};

export default ViewStudents;
