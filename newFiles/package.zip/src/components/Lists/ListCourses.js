import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useGetPostsMutation, useDeletePostMutation } from '../rtk/AddSlice';
import { encryptData,decryptData } from "../../assets/security/encryDecrypt";
import CardTable3 from "../Cards/CardTable3";
import CardShimmer from "../Effects/CardShimmer";

const Education = () => {
    const [getdata, { isLoading, isSuccess, post }] = useGetPostsMutation();
    const [posts, setPosts] = useState(post);
    const [search, setSearch] = useState('');
    const [sortBy, setSortBy] = useState([]);
  
  const handleSortParent=(value)=>{
    setSortBy(value)
  }

    const filteredData = async () => {

        const fetchPosts = await getdata({ search: search, sortBy: sortBy }).unwrap();
        const temp = decryptData(fetchPosts.data)
        setPosts(temp);
    }

    useEffect(() => {
        filteredData();
    }, [sortBy,search]);

    const handleSearchParent = (value) => {
      setSearch(value);
  }
  console.log('sortBy', sortBy)
  console.log('search', search)

   console.log("posts",posts);
    return (
        <>
      <div className="w-full mb-12 px-4">
        {isLoading && <CardShimmer />}

        {isSuccess && (
          <div
            className="relative bg-lightBlue-600 md:pt-32 pb-32 pt-12"
            style={{
              display: "flex",
              flexWrap: "wrap",
              justifyContent: "space-around",
            }}
          >
            <CardTable3
              title={"List of Courses"}
              content={posts}
              heading={[
                "Sno",
                "Course Name",
                "Edit",
                "Delete"
              ]}
              errorMessg={"No Courses available"}
              handleSearchParent={handleSearchParent}
              handleSortParent={handleSortParent}
            />
          </div>
        )}
      </div>
    </>
    );
};

export default Education;