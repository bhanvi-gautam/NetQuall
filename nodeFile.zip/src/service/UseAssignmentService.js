
const UserAssignmentDao = require("../dao/UserAssignmentDao");
const UserSubjectDao = require("../dao/userSubjectDao");
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { response } = require('express');
const logger = require('../config/logger');
const httpStatus = require('http-status');

class UserAssignment {
    constructor() {
        this.userAssignmentDao = new UserAssignmentDao();
        this.userSubjectDao = new UserSubjectDao();
    }
    getAssignment = async (req) => {
        try {
            const assignment=await this.userAssignmentDao.findAssignment(req);
            console.log('assignment', assignment)
            if(assignment){
                return responseHandler.returnSuccess(
                    httpStatus.OK,
                    "Assignments fetched successfully",
                    assignment
                );
            }
            else{
                return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR,"No assignments")
            }
            
        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    };

    allData = async () => {
        try {
            const assignment=await this.userAssignmentDao.allData();
            if(assignment){
                return responseHandler.returnSuccess(
                    httpStatus.OK,
                    "Assignments fetched successfully",
                    assignment
                );
            }
            else{
                return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR,"No assignments")
            }
            
        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    };

    checkSubmission = async (req) => {
        try {
            console.log('req12333', req)

            const subId = await this.userSubjectDao.findByWhere({ subjectName: req.subject_Id }, ['id']);
            const assignment=await this.userAssignmentDao.getCountByWhere({assign_Id:req.assign_Id,user_Id:req.user_Id,userSubject_Id:subId[0].dataValues.id});
            console.log('assignment', assignment)   
            // return;
            // if(assignment){
                return responseHandler.returnSuccess(
                    httpStatus.OK,
                    "Assignments fetched successfully",
                    assignment
                );
            // }
            // else{
            //     return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR,"No assignments")
            // }
            
        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    };

    getMarks = async (req) => {
        try {
            console.log('req12333', req)

            const subId = await this.userSubjectDao.findByWhere({ subjectName: req.subject_Id }, ['id']);
            const marks=await this.userAssignmentDao.findOneByWhere({assign_Id:req.assign_Id,user_Id:req.user_Id,userSubject_Id:subId[0].dataValues.id},['marks']);
            console.log('marks', marks?.dataValues?.marks)   
            // return;
            // if(marks){
                if(marks===null){
                    return responseHandler.returnSuccess(
                        httpStatus.OK,
                        "Marks fetched successfully",
                        marks
                    );
                }
                return responseHandler.returnSuccess(
                    httpStatus.OK,
                    "Marks fetched successfully",
                    marks
                );
            // }
            // else{
            //     return responseHandler.returnError(httpStatus.INTERNAL_SERVER_ERROR,"No marks")
            // }
            
        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    };
 
}



module.exports = UserAssignment;