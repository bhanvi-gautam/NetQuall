
const UserQuizDetailsDao = require("../dao/UserQuizDetailsDao");
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { response } = require('express');
const logger = require('../config/logger');
const httpStatus = require('http-status');
const QuizDao = require("../dao/QuizDao");

class UserQuizDetailsService {
    constructor() {
        this.userQuizDetailsDao = new UserQuizDetailsDao();
        this.quizDao=new QuizDao();
    }
    
    submitUserQuiz=async(req)=>{
        try {
            
            console.log('req', req)
            let uuid = uuidv4();
            const submitData={
                uuid:uuid,
                user_Id: req.userId,
                quiz_Id: req.quizId,
                score: req.finalScore
            }
            const submitQuiz=await this.userQuizDetailsDao.create(submitData);
            if(!submitQuiz){
                let message = "Submission Failed! Please Try again.";
                return responseHandler.returnError(httpStatus.BAD_REQUEST, message);
            }
            return responseHandler.returnSuccess(httpStatus.CREATED,"Submission Successful");
            
        } catch (error) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    }

    getScore=async(req)=>{
        try {
            console.log('req123432453', req)
            const getStudentScore= await this.userQuizDetailsDao.findByWhere({user_Id:req},['user_Id','quiz_Id','score'],['quiz_Id','ASC']);
            if(!getStudentScore){
                return responseHandler.returnError(httpStatus.BAD_REQUEST, 'Error fetching student Scores');
            }
            console.log('getStudentScore', getStudentScore)
            return responseHandler.returnSuccess(httpStatus.CREATED,"Scores Fetched",getStudentScore);

        } catch (error) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    }

    getStudentQuizData=async(studentId,subjectId)=>{
        try {
            
            const getStudentQuizData= await this.quizDao.getStudentQuizData(studentId,subjectId);
            // console.log('getStudentQuizData', getStudentQuizData)
            
            if(!getStudentQuizData){
                return responseHandler.returnError(httpStatus.BAD_REQUEST, 'Error fetching student Scores');
            }
            // console.log('getStudentQuizData', getStudentQuizData)
            return responseHandler.returnSuccess(httpStatus.CREATED,"Scores Fetched",getStudentQuizData);

        } catch (error) {
            logger.error(error);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    }
   
    
}



module.exports = UserQuizDetailsService;