const httpStatus = require('http-status');
// const express=require('express')
const cors = require('cors')
const utils = require('../utils/utils')
const fs = require('fs')
const Busboy = require("busboy")
const UserDao = require('../dao/UserDao');
const UserSubjectDao = require('../dao/userSubjectDao');
const UserSemesterDao = require('../dao/userSemesterDao');
const UserCourseDao = require('../dao/userCourseDao');
const UserTeacherDetailsDao = require('../dao/UserTeacherDetailsDao');
const UserAssignmentDao = require('../dao/UserAssignmentDao');
const QuizDao = require('../dao/QuizDao');
const QuizQuestionsDao = require('../dao/QuizQuestionsDao');
const QuizOptionsDao = require('../dao/QuizOptionsDao');
const responseHandler = require('../helper/responseHandler');
const { v4: uuidv4 } = require('uuid');
const { Op } = require('sequelize')
const { response } = require('express');
const logger = require('../config/logger');
class QuizService {
    constructor() {
        this.userDao = new UserDao();
        this.userCourseDao = new UserCourseDao();
        this.userSemesterDao = new UserSemesterDao();
        this.userSubjectDao = new UserSubjectDao();
        this.userTeacherDetailsDao = new UserTeacherDetailsDao();
        this.userAssignmentDao = new UserAssignmentDao();
        this.quizDao = new QuizDao();
        this.quizQuestionsDao = new QuizQuestionsDao();
        this.quizOptionsDao = new QuizOptionsDao();
    }

    createQuiz = async (req) => {
        try {
            let message ="Successfully Created Quiz";
            if (await this.quizDao.isQuizNameExists(req.quizName)) {
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Quiz Name already taken"
                );
            }
            const subject_Id = await this.userSubjectDao.findOneByWhere({ subjectName: req.subject }, ['id']);

            req.subject_Id = subject_Id.dataValues.id;
            let totalMarks=0;
            req.questions.map((data)=>{
                totalMarks+=Number(data.marks);
                let temp=[];
                for(let i=0;i<data.options.length;i++){
                    if(data.correctAnswer.includes(i)){
                        temp.push(1);
                    }
                    else{
                        temp.push(0);
                    }
                }
                data.correctAnswer=temp;
            })
            req.totalMarks=totalMarks;
            let uuid = uuidv4();
            this.quizDao.create({uuid:uuid,quizName:req.quizName,subject_Id:req.subject_Id,quiz_marks:req.totalMarks}).then((quizData)=>{
                console.log('data', quizData.dataValues.id);
                req.questions.map((data)=>{
                    uuid = uuidv4();
                    this.quizQuestionsDao.create({uuid:uuid,question:data.text,quiz_Id:quizData.dataValues.id,question_marks:data.marks,question_type:data.multiAnswer}).then((questionData)=>{
                        console.log('data', questionData.dataValues.id);

                        for(let i=0;i<data.options.length;i++){
                            uuid = uuidv4();
                            this.quizOptionsDao.create({uuid:uuid, option_text:data.options[i],is_correct:data.correctAnswer[i],question_Id:questionData.dataValues.id}).then((data)=>{

                            }).catch((error)=>{
                                return responseHandler.returnError(
                                    httpStatus.BAD_REQUEST,
                                    "Can't Create options!"
                                );
                            })
                        }
                    }).catch((error)=>{
                        return responseHandler.returnError(
                            httpStatus.BAD_REQUEST,
                            "Can't Create question!"
                        );
                    })
                })
                
            }).catch((error)=>{
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Can't Create Quiz!"
                );
            })

            return responseHandler.returnSuccess(httpStatus.CREATED, message);

        
        } catch (e) {
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    };

    getQuizzes=async (req)=>{
        try{
            console.log('req12222', req);
            let required_Id;
            if(req.subject){
                const subject_Id=await this.userSubjectDao.findOneByWhere({subjectName:req.subject},['id','subjectName']);
                 required_Id=subject_Id.dataValues.id;
                }else{
                const subject_Id=await this.userTeacherDetailsDao.findOneByWhere({userId:req},['teacher_Id','subject_Id'],['teacher_Id']);
                required_Id=subject_Id.dataValues.subject_Id;
            }
            // return;
            const getQuizzes=await this.quizDao.getQuizzes(required_Id);
            const getSubjectName=await this.userSubjectDao.findById(required_Id);
            if(!getQuizzes){
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "No Quiz exists"
                );
            }
            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quizzes fetched successfully',{data: getQuizzes, subjectName:getSubjectName.dataValues.subjectName});


        }catch(e){
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }

    };

    getStudentQuiz=async (req)=>{
        try{
            const subject_Id=await this.userTeacherDetailsDao.findOneByWhere({userId:req},['teacher_Id','subject_Id'],['teacher_Id']);
            console.log('subject_Id', subject_Id)
            return;
            const getQuizzes=await this.quizDao.getQuizzes(subject_Id.dataValues.subject_Id);
            const getSubjectName=await this.userSubjectDao.findById(subject_Id.dataValues.subject_Id);
            if(!getQuizzes){
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "No Quiz exists"
                );
            }
            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quizzes fetched successfully',{data: getQuizzes, subjectName:getSubjectName.dataValues.subjectName});


        }catch(e){
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }

    };


    getOneQuiz=async (req)=>{
        try{
            const getQuizzes=await this.quizDao.getOneQuiz(req);
            if(!getQuizzes){
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "No Quiz exists"
                );
            }
            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quizzes fetched successfully', getQuizzes);


        }catch(e){
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }

    };


    liveQuiz=async (req)=>{
        try{
            console.log('req', req);
            // return;
            const availability=await this.quizDao.updateById({is_available:!req.availability},req.id)
           
            if(!availability){
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Not Changed"
                );
            }
            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quizzes Availability status changed successfully');


        }catch(e){
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }

    };


    deleteQuiz=async(req)=>{
        try{
            const questionIds=await this.quizQuestionsDao.findByWhere({quiz_Id:req},['quiz_Id','id']);
            console.log('questionIds', questionIds)

            questionIds.map(async(data)=>{
                console.log('data.dataValues.id', data.dataValues.id)
                const forOptions=await this.quizOptionsDao.deleteByWhere({question_Id:data.dataValues.id});

                if(forOptions){
                    try {
                    await this.quizQuestionsDao.deleteByWhere({id:data.dataValues.id});
                        
                    } catch (error) {
                        console.log('error', error)
                    }
                }
                else{
                    return responseHandler.returnError(
                        httpStatus.BAD_REQUEST,
                        "Error deleting options"
                    ); 
                } 
            })
            const final=await this.quizDao.deleteByWhere({id:req});
            if(!final){
                return responseHandler.returnError(
                    httpStatus.BAD_REQUEST,
                    "Something went wrong!"
                );
            }

            return responseHandler.returnSuccess(httpStatus.CREATED, 'Quiz deleted successfully');


        }catch(e){
            logger.error(e);
            return responseHandler.returnError(
                httpStatus.BAD_REQUEST,
                "Something went wrong!"
            );
        }
    }
}
module.exports = QuizService;