const express = require('express');
const QuizController = require('../controllers/QuizController.js');
const UserValidator = require('../validator/UserValidator');

const router = express.Router();
const auth = require('../middlewares/auth');

const quizController = new QuizController();
const userValidator = new UserValidator();

router.post('/create-quiz', quizController.createQuiz);
router.post('/get-quiz', quizController.getQuizzes);
router.post('/live-quiz', quizController.liveQuiz);
router.post('/delete-quiz', quizController.deleteQuiz);
router.post('/get-one-quiz', quizController.getOneQuiz);
router.post('/get-student-quiz', quizController.getStudentQuiz);
router.post('/submit-user-quiz', quizController.submitUserQuiz);
router.post('/get-score',quizController.getScore)
router.post("/get-student-quiz-data",quizController.getStudentQuizData)

module.exports = router;
