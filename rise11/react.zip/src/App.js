import React from 'react'
import Register from './components/auth/Register'
import Login from './components/auth/Login'
import { useSelector } from 'react-redux'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Home from './components/todoList/Home'
import Landing from './components/Landing'

const App = () => {
  let token=useSelector((state)=>state.token.strValue)
 
  if(!token){
    token=localStorage.getItem('token')
 }
  return (
    <BrowserRouter>
    {!token ? (
      <>
        <Routes>
          <Route path="/" element={<Landing />} />
          <Route path="/login" element={<Login />} />
          <Route path= "/register" element= {<Register />} />
        </Routes>
      </>
    ) : (
      <>
        <div>
          {/* <AdminNavbar /> */}

          <Routes>
          <Route path="/" element={<Home />} />
          </Routes>
        </div>
      </>
    )}
  </BrowserRouter>
  )
}

export default App

