import React from 'react'
import { setToken } from '../rtk/app/slice';
import Button from 'react-bootstrap/Button';
import Form from 'react-bootstrap/Form';
import { useDispatch } from 'react-redux';
import { useLoginMutation } from '../rtk/AddSlice';
import { encryptData } from '../security/EncryDecrypt';

const Login = () =>{
    const dispatch = useDispatch();
  const [sendData, { isLoading, isSuccess, post }] = useLoginMutation();

  const handleSubmit=async(e)=>{
    e.preventDefault();
    const email = e.target.elements.formBasicEmail.value;
    const password = e.target.elements.formBasicPassword.value;
    console.log('email', email)
    console.log('password', password)

    const data = { email: email, password: password };
    const encryptedData = encryptData(data);
    await sendData({ data: encryptedData }).then((response)=>{
        dispatch(setToken(response.data.tokens.access.token));
        localStorage.setItem("token", response.data.tokens.access.token);
        const encryptedId = encryptData(response.data.data.id);
        localStorage.setItem("userId", encryptedId);
    });
    
  }

  
  return (
    <Form onSubmit={handleSubmit}>
      <Form.Group className="mb-3" controlId="formBasicEmail">
        <Form.Label>Email address</Form.Label>
        <Form.Control type="email" placeholder="Enter email" />
        <Form.Text className="text-muted">
          We'll never share your email with anyone else.
        </Form.Text>
      </Form.Group>

      <Form.Group className="mb-3" controlId="formBasicPassword">
        <Form.Label>Password</Form.Label>
        <Form.Control type="password" placeholder="Password" />
      </Form.Group>
      <Form.Group className="mb-3" controlId="formBasicCheckbox">
        <Form.Check type="checkbox" label="Check me out" />
      </Form.Group>
      <Button variant="primary" type="submit">
        Submit
      </Button>
    </Form>
  );
}

export default Login;
