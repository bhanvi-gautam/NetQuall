import React, { useEffect, useState } from 'react'
import { useGetPostsMutation } from '../rtk/AddSlice'
import TodoItem from './TodoItem';

const Todos = () => {
    const [getData,{isLoading,isSuccess,isError,post}]=useGetPostsMutation();
    const [posts,setPosts]=useState(post);
    const userId=localStorage.getItem('userId');

    const getTodos=async()=>{
        console.log('userId', userId)
         getData({id:userId}).unwrap().then((fetchTodos)=>{
            console.log('fetchTodos', fetchTodos.data);
            setPosts(fetchTodos.data);
         }).catch((error)=>{
            console.log(error);
         })
    }
    useEffect(()=>{
        getTodos();
    },[]);

  return (
    <div>
      {isSuccess && 
      <>
      
      {posts?.map((data,index)=>{
        console.log('data.id', data.id)
        return(
        <div key={index}>
            <TodoItem text={data.todo_text}  todoId={data.id}/>
       

        </div>
        )
      })}
      
      </>
      }
    </div>
  )
}

export default Todos
