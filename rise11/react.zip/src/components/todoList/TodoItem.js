import React from 'react'
import { useDeletePostMutation, useUpdatePostMutation } from '../rtk/AddSlice'
import {encryptData} from '../security/EncryDecrypt'

const TodoItem = ({text,todoId}) => {

  const [sendData]=useDeletePostMutation();
  const [updateData,{isLoading,isSuccess,post}]=useUpdatePostMutation();

  const handleDelete=async()=>{
    console.log('id', todoId)
    const encryptedId=encryptData(todoId);
    await sendData({id:encryptedId});
  }

  const handleUpdate=async()=>{
    console.log('id', todoId)
    const encryptedId=encryptData(todoId);
    await updateData({id:encryptedId});
  }
  return (
    <div>
      {text} 
      <button onClick={handleDelete}>delete</button>
      <button onClick={handleUpdate}>Update</button>
    </div>
  )
}

export default TodoItem
