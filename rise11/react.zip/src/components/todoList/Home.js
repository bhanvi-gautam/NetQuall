import React, { useState } from 'react'
import Form from 'react-bootstrap/Form';
import Todos from './Todos'
import InputGroup from 'react-bootstrap/InputGroup';
import { useAddNewPostMutation } from '../rtk/AddSlice';
import {decryptData, encryptData} from '../security/EncryDecrypt'

//only Adding 
const Home = () => {
    const [sendData]=useAddNewPostMutation();
    const [text, setText] = useState('');
    const userId=localStorage.getItem('userId');
    const user_Id=decryptData(userId);
    const handleSubmit = async (e) => {
        console.log('text', text);
        const payload={id:user_Id , text: text};
        console.log('payload', payload)
        await sendData({data:encryptData(payload)});

    }
    return (
        <div>
            <InputGroup className="mb-3">
                <InputGroup.Text id="inputGroup-sizing-default">
                    Write Todo 
                </InputGroup.Text>
                <Form.Control
                    aria-label="Default"
                    aria-describedby="inputGroup-sizing-default"
                    value={text}
                    onChange={(e) => setText(e.target.value)}
                />
            </InputGroup>
            <button onClick={handleSubmit}>Add</button>

            <Todos/>
        </div>
    )
}

export default Home

