#import flask module from flask class
#Import database from flaskSqlAcchemy
from flask import Flask, render_template,request,redirect, url_for,session
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime
import  json
from flask_mail import Mail, Message
app = Flask(__name__)
app.secret_key = 'Hello-Abhay-test'



#import config file
with open('config.json','r') as c:
    params = json.load(c)['params']

local_server = params['local_server']


#sent mail via flask
app.config.update(
    MAIL_SERVER = 'smtp.gmail.com',
    MAIL_PORT = '465',
    MAIL_USE_SSL = True,
    MAIL_USERNAME = params['gmail_user'],
    MAIL_PASSWORD = params['gmail_password']
)

mail = Mail(app)


if local_server:
    app.config['SQLALCHEMY_DATABASE_URI'] = params['local_uri']
else:
    app.config['SQLALCHEMY_DATABASE_URI'] = params['production_uri']
db = SQLAlchemy(app)


class Contacts(db.Model):
    """
     Sn,name,email,phone_num,mes,date
    """
    Sn = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    phone_num = db.Column(db.String(120), nullable=False)
    mes = db.Column(db.String(12), nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)  # Set default value to current time

class Post(db.Model):
    """
    sno: Serial number, unique identifier for each post
    title: Title of the post
    content: Content of the post
    date: Date and time when the post was created
    slug: URL-friendly version of the title, used for generating post URLs
    """

    sno = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    content = db.Column(db.Text, nullable=False)
    date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    slug = db.Column(db.String(200), nullable=False, unique=True)
    img_file = db.Column(db.String(12), nullable=False, unique=True)
    tagline = db.Column(db.String(11), nullable=False, unique=True)


@app.route("/api")
def hello():
    return render_template("index1.html")

@app.route("/api/webdev")
def abhay():
    name="abhay"
    return render_template("index2.html",name=name)

@app.route("/bootstrap")
def bootstrap():
    return  render_template("bootstrap.html")

@app.route("/")
def home():
    posts = Post.query.filter_by().all() [0:params["no_of_posts"]]
    return render_template("index.html",params=params,posts=posts)

@app.route("/about")
def about():
    return  render_template("about.html",params=params)

# Flask route for handling GET and POST requests to /contact
@app.route("/contact", methods=['GET', 'POST'])
def contact():
    if request.method == "POST":
        # Extract data from the form submission
        name = request.form.get("name")
        email = request.form.get("email")
        phone_num = request.form.get("phone_num")
        mes = request.form.get("mes")

        # Create a new entry in the database
        new_entry = Contacts(name=name, email=email, phone_num=phone_num, mes=mes)
        db.session.add(new_entry)
        db.session.commit()

        # Create a message object
        mail.send_message('New message from ' + name,
                          sender=email,
                          recipients=[params['gmail_user']],
                          body=mes + "\n" + phone_num
                          )
        # You can redirect or render another template if needed
        return render_template("contact.html", params=params)

    else:
        return render_template("contact.html",params=params)

@app.route("/post",methods=["GET"])
def post():
    posts = Post.query.all()
    return  render_template("post.html",params=params,posts=posts)

@app.route("/post/<string:post_slug>", methods=["GET"])
def post_route(post_slug):
    post = Post.query.filter_by(slug=post_slug).first()
    return render_template("post.html", params=params, post=post)

@app.route("/dashboard", methods=["GET", "POST"])
def dashboard():
    if ('username' in session and session["username"] == params['gmail_user']):
        posts = Post.query.all()
        return render_template("dashboard.html", params=params,posts=posts)
    if request.method == "POST":
        # Handle POST request
        # For example, process form data
        username = request.form.get("username")
        password = request.form.get("password")
        # Perform authentication, database operations, etc.
        if (username==params['gmail_user'] and password==params['gmail_password']):
            session["username"] = username
        posts = Post.query.all()
        #return redirect(url_for("dashboard"))
        return render_template("dashboard.html", params=params,posts=posts)

    else:
        # Render the signin.html template for GET request
        return render_template("signin.html", params=params)


#Edit Page
@app.route("/edit/<string:sno>", methods=["GET", "POST"])
def edit(sno):
    # Check if user is logged in
    date = datetime.now()
    if "username" in session and session['username'] == params['gmail_user']:
        if request.method == 'POST':
            title = request.form.get("title")
            content = request.form.get("content")
            slug = request.form.get("slug")
            tagline = request.form.get("tagline")
            img_file = request.form.get("img_file")

            if sno == '0':
                post = Post(title=title, content=content, slug=slug, tagline=tagline, img_file=img_file, date=date)
                db.session.add(post)
            else:
                post = Post.query.filter_by(sno=sno).first()
                if post:
                    post.title = title
                    post.content = content
                    post.slug = slug
                    post.tagline = tagline
                    post.img_file = img_file
                    post.date = date
            db.session.commit()
            return redirect('/edit/' + sno)  # Redirect to the same edit page after saving

        # This line should be outside the POST request block
        post = Post.query.filter_by(sno=sno).first()

        # Handle GET request
        return render_template('edit.html', params=params, post=post)  # Pass sno to the template for editing existing post
    else:
        return redirect('/')  # Redirect if user is not logged in


# @app.route("/uploder",method=['GET','POST'])
#   def uploader():
#       if "username" in session and session['username'] == params['gmail_user']:
#           if request.method == "POST" :
#               f = request.files['file1']


#When we change any letter and function in return function (debug=True) can track that
# Initialize SQLAlchemy instance

if __name__ == "__main__":
     app.run(debug=True)

