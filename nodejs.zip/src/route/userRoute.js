const express = require('express');
const UserController=require('../controllers/UserController')
const UserValidator = require('../validator/UserValidator');
// const auth = require('../middlewares/auth');


const router = express.Router();
const auth = require('../middlewares/auth');
const userController = new UserController();
const userValidator = new UserValidator();


router.post('/upload',userController.uploadImage);
// router.post('/search',userController.searching);
router.post('/requestFile',userController.requestFile);
router.post('/viewDetails',userController.viewDetail);
router.post('/deleteUser',userController.deleteUser);
router.post('/deleteProfile',userController.deleteProfile);
router.post('/getUser',userController.viewUser);
router.post('/update-user',userController.updateUser);
router.post('/email', userValidator.checkEmailValidator, userController.checkEmail);
router.post('/enable-disable-user',  userController.enableDisableUser);
router.post('/message',userController.sendMessage);
// router.post('/phone-number', userValidator.checkEmailValidator, authController.phone-number);
router.post('/register', userController.register);
// router.post('/login', userValidator.userLoginValidator, userController.login);
router.put(
    '/change-password',
    userValidator.changePasswordValidator,
    userController.changePassword,
);


module.exports=router;