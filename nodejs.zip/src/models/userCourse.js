const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userCourse extends Model {
        
        static associate(models) {
            // define association here
            // userCourse.belongsTo(models.user,{foreignKey: 'user_Id', targetKey: 'id' })
            userCourse.hasMany(models.user, {foreignKey: 'course_Id' , targetKey: 'id' })
            userCourse.hasMany(models.userSemester, {foreignKey: 'course_Id' , targetKey: 'id' })
        }
    }

    userCourse.init(
        {
            uuid: DataTypes.UUID,
            courseName: DataTypes.STRING,
            // courseCode: DataTypes.STRING,
            is_available: { type: DataTypes.INTEGER, defaultValue: '0' },

        },
        {
            sequelize,
            modelName: 'userCourse',
            underscored: false,
        },
    );
    return userCourse;
};