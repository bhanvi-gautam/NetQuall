const { Model } = require('sequelize');

module.exports = (sequelize, DataTypes) => {
    class userMigration extends Model {
        
        static associate(models) {
            // define association here
            userMigration.hasMany(models.user,{foreignKey: 'migration_Id', targetKey: 'id' })
            // userMigration.belongsTo(models.user, {foreignKey: 'user_Id' , targetKey: 'id' })
        }
    }

    userMigration.init(
        {
            uuid: DataTypes.UUID,
            old_course_name: DataTypes.STRING,
            new_course_name: DataTypes.STRING,


        },
        {
            sequelize,
            modelName: 'userMigration',
            underscored: false,
        },
    );
    return userMigration;
};